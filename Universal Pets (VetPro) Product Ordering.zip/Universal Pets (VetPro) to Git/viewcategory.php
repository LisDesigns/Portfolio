<?php 
include "includes/header.php";
include "../includes/dbconn.php";
$category=$_POST['category'];
$category = trim($category);
?>
<h1>View Category</h1>       

<?

$query  = "SELECT DISTINCT subcategory FROM `products_new` WHERE category ='".$category."' ORDER BY page DESC";
$z=0;
$x=0;
$x++;
$result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

if (mysql_num_rows($result) != 0){
$options;
?>


<form method="post" action="viewsubcategory.php">

<?
  echo "<input type='hidden' value='".$category."'/>";
  while($row = mysql_fetch_assoc($result)){
    $subcategory = $row['subcategory'];
    $subcategory = trim($subcategory);
    if (!empty($subcategory)) {

      $options .= '<option>'.$subcategory.'</option>';
      $z++;
    }
  }

  if (!empty($options)) {

      echo '<br/>Refine search by subcategory:<br/>';
      echo '<select name="subcategory" style="width:300px">';
      echo '<option selected>Please select</option>';
      echo $options;
      echo '</select><input type="submit" value="View"/></form>';

  }


?>

<?
}
?>

<br/><b>Currently showing category: <? echo $category; ?></b><br/>

<?

if ($z == 0){
  echo "<i><small>(There are no subcategories in this section.)</small></i><br/>";
} 
$category = trim($category);
$query  = "SELECT * FROM `products_new` WHERE `category`='".$category."'";

$result = mysql_query($query);

  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

  while($row = mysql_fetch_assoc($result)){
    $tableId=$row['tableId'];
    $productId=$row['productId'];
    $name=$row['name'];
    echo "<br/><a href='editproduct.php?tableId=".$tableId."'>".$name."</a><br/>";
  }
?>
