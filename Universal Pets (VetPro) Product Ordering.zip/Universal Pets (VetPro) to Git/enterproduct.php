
<?php

include "includes/header.php";
include "../includes/dbconn.php";


  $pages ='<select class="val" name="page_options" id="page_options" onchange="clearoption('."'page'".')"><option>Pages Available</option>';
  $query  = "SELECT DISTINCT page FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  while($row = mysql_fetch_assoc($result)){
    $page=$row['page'];
    $pages.="<option>".$page."</option>"; 
  }
  $pages.="</select>";


  $categories ='<select class="val" name="category_options" id="category_options" onchange="clearoption('."'category'".')"><option>Categories Available</option>';
  $query  = "SELECT DISTINCT category FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }


  while($row = mysql_fetch_assoc($result)){
    $category=$row['category'];
    $categories.="<option>".$category."</option>"; 
  }
  $categories.="</select>";

  $subcategories ='<select class="val" name="subcategory_options" id="subcategory_options" onchange="clearoption('."'subcategory'".')"><option>Subcategories Available</option>';
  $query  = "SELECT DISTINCT subcategory FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }


  while($row = mysql_fetch_assoc($result)){
    $subcategory=$row['subcategory'];
    $subcategories.="<option>".$subcategory."</option>"; 
  }
  $subcategories.="</select>";

?>
<h1>Add New Product</h1>

<form name="enterproduct" action="addnewproduct.php" method="post" enctype="multipart/form-data">
<table>

<tr><td class="tdh1">Order Page Name<br/><br/></td><td><? echo $pages; ?><br/><input type="text" class="val" name="page" id="page"></td></tr>
<tr><td class="tdh1">Category<br/><br/></td><td><? echo $categories; ?><br/><input type="text" class="val" name="category" id="category"></td></tr>
<tr><td class="tdh1">Subcategory<br/><br/></td><td><? echo $subcategories; ?><br/><input type="text" class="val" name="subcategory" id="subcategory"></td></tr>

<tr><td class="tdh1">Product Id<br/><br/></td><td><input type="text" class="val" name="productId"></td></tr>
<tr><td class="tdh1">Item Name<br/><br/></td><td><input type="text" class="val" name="itemName"></td></tr>
<tr><td class="tdh1">Size/Amount Per Package<br/><br/></td><td><input type="text" class="val" name="qty"></td></tr>
<tr><td class="tdh1">Price<br/><br/></td><td><input type="text" class="val" name="price"></td></tr>
<tr><td class="tdh1">On Special<br/><br/></td><td><select name="onspecial" id="onspecial"><option>No</option><option>Yes<option></select></td></tr>
<tr><td class="tdh1">Product Image<br/><br/></td><td><input type="file" name="file1" id="file1"></td></tr>
<tr><td class="tdh1"></td><td><input type="submit" class="val" value="Submit Product"></td></tr>
</table>
</form>

<?
include "includes/footer.php";
?>