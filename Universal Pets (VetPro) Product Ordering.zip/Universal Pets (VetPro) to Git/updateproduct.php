<?php

include "includes/header.php";

include "../includes/dbconn.php";

$page_options = $_POST["page_options"];
$category_options = $_POST["category_options"];
$subcategory_options = $_POST["subcategory_options"];
               
$page = $_POST["page"];
$category = $_POST["category"];
$subcategory = $_POST["subcategory"];


if($page_options != 'Pages Available'){
  $page = $page_options;
}
if($category_options != 'Categories Available'){
  $category = $category_options;
}
if($subcategory_options != 'Subcategories Available'){
  $subcategory = $subcategory_options;
} 

$productId = $_POST["productId"];
$name = $_POST["itemName"];
$qty = $_POST["qty"];
$price = $_POST["price"];
$onspecial = $_POST["onspecial"];
$tableId = $_POST["tableId"];


  $uploads = "../uploads/";
  $filename = $tableId.".jpg";
 
  $error ="";
  if (strlen($_FILES["file1"]["name"]) > 0) {
    //unlink($uploads.$filename);
    if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg") || ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {

      if ($_FILES["file1"]["error"] > 0) {
        $error = "Return Code: " . $_FILES["file1"]["error"] . "<br/>";
      } else {
        $_FILES["file1"]["name"]=$filename;
        move_uploaded_file($_FILES["file1"]["tmp_name"],$uploads.$filename);
      }
    }
  }    
  
   $image = $filename;


//mysql_query("INSERT INTO products_new (category, subcategory, productId, name, qty, price, page, onspecial, image) VALUES //('$category', '$subcategory', '$productId', '$itemname', '$qty', '$price', '$page','$onspecial','$image')");

$query  = "UPDATE `products_new` SET `category` = '".$category."', `subcategory` = '".$subcategory."', `productId` = '".$productId."', `name` = '".$name."', `qty` = '".$qty."', `price` = '".$price."', `page` = '".$page."', `onspecial` = '".$onspecial."', `image` = '".$image."' WHERE `tableId` = ".$tableId;
mysql_query($query);
echo "Product updated.";
?>


