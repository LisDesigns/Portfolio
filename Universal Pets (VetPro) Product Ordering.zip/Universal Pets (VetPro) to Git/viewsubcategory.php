<?php 
include "includes/header.php";
include "../includes/dbconn.php";
$category=$_POST['category'];
$subcategory=$_POST['subcategory'];
$category = trim($category);
$subcategory = trim($subcategory);
?>
<h1>View Subcategory</h1>       
Currently showing 
<? 

if ((!empty($category))) {
  echo "category: ".$category; 
}

if ((!empty($category)) && (!empty($category))) {
  echo " with";
}
 
if ((!empty($subcategory))) {
  echo " subcategory: ".$subcategory;
}

?>

<br/>

<?

$query  = "SELECT * FROM `products_new` WHERE category ='".$category."' AND subcategory ='".$subcategory."'";

$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

while($row = mysql_fetch_assoc($result)){
    $tableId=$row['tableId'];
    $productId=$row['productId'];
    $name=$row['name'];
    echo "<br/><a href='editproduct.php?tableId=".$tableId."'>".$name."</a><br/>";
}

$category = trim($category);
$query  = "SELECT * FROM `products_new` WHERE `subcategory`='".$subcategory."'";

$result = mysql_query($query);

  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

  while($row = mysql_fetch_assoc($result)){
    $tableId=$row['tableId'];
    $productId=$row['productId'];
    $name=$row['name'];
    echo "<br/><a href='editproduct.php?tableId=".$tableId."'>".$name."</a><br/>";
  }
?>


