<?php

include "includes/header.php";
include "../includes/dbconn.php";


?>

<input type="text" class="val" name="category" id="category" value="test" onmouseover="clearoption('category')">

