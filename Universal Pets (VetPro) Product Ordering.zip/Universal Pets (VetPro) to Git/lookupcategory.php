<?php

include "includes/header.php";
include "../includes/dbconn.php";

$query  = "SELECT DISTINCT category FROM `products_new` ORDER BY page DESC";

$x =0;
$x++;
$result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

?>
<h1>Find Product by Category</h1>

<form method="post" action="viewcategory.php">
<select name="category" style="width:300px">
<option selected>Please select</option>
<?
  while($row = mysql_fetch_assoc($result)){
    $category = $row['category'];
    echo '<option>'.$category.'</option>';
  }
?>

</select>



<input type="submit" value="View"/>
</form>