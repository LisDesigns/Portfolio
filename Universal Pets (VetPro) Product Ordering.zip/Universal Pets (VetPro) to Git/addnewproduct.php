<?php

include "includes/header.php";
include "../includes/dbconn.php";
               
$page = $_POST["page"];
$category = $_POST["category"];
$subcategory = $_POST["subcategory"];
$productId = $_POST["productId"];
$itemname = $_POST["itemName"];
$qty = $_POST["qty"];
$price = $_POST["price"];
$onspecial = $_POST["onspecial"];

$page_options = $_POST["page_options"];
$category_options = $_POST["category_options"];
$subcategory_options = $_POST["subcategory_options"];
               
if($page_options != 'Pages Available'){
  $page = $page_options;
}
if($category_options != 'Categories Available'){
  $category = $category_options;
}
if($subcategory_options != 'Subcategories Available'){
  $subcategory = $subcategory_options;
} 

// Upload new image
  $query  = "SELECT * FROM products_new WHERE tableId=(select MAX(tableId) from products_new)";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }
  while($row = mysql_fetch_assoc($result)){
    $tableId=$row['tableId'];
  }
  $tableId++;

  $uploads = "../uploads/";
  $filename = $tableId.".jpg";
 

  $error ="";
  if (strlen($_FILES["file1"]["name"]) > 0) {

    if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg") || ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {

      if ($_FILES["file1"]["error"] > 0) {
        $error = "Return Code: " . $_FILES["file1"]["error"] . "<br/>";
      } else {
        $_FILES["file1"]["name"]=$filename;
        move_uploaded_file($_FILES["file1"]["tmp_name"],$uploads.$_FILES["file1"]["name"]);
      }
    }
  }    
  
   $image = $filename;


mysql_query("INSERT INTO products_new (category, subcategory, productId, name, qty, price, page, onspecial, image) VALUES ('$category', '$subcategory', '$productId', '$itemname', '$qty', '$price', '$page','$onspecial','$image')");

echo "New item added.";
?>


