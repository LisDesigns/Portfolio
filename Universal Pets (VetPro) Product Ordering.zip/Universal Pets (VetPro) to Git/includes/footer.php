<script language="JavaScript1.2">

function clearoption(fldname) {
  document.getElementById(fldname).value="";
}


</script>