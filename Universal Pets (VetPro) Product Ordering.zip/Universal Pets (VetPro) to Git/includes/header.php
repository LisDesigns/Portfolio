<?php

?>
<html>
<head>
<style type="text/css">
body{background-color:rgb(240,240,240);font-family:arial; font-size:12px}  
h1{font-size:14px;}
td{font-size:12px;font-family:arial}
.val{width:180px}
.tdh1{width:180px;height:40px;vertical-align:top; padding-bottom:5px;}
#page_options{margin-bottom:2px;background-color:rgb(250,250,250);color:rgb(120,120,120)!important;border-style:solid; border-width:1px;border-color:gray}
#category_options{margin-bottom:2px;background-color:rgb(250,250,250);color:rgb(120,120,120)!important;border-style:solid; border-width:1px;border-color:gray}
#subcategory_options{margin-bottom:2px;background-color:rgb(250,250,250);color:rgb(120,120,120)!important;border-style:solid; border-width:1px;border-color:gray}
#onspecial{background-color:white!important;color:black;border-style:solid; border-width:1px;border-color:gray}
</style>


</head>
<body>
<br/>
<h1>Universal Pet Admin Centre</h1>
<a href="index.php">Register New Customer</a> &nbsp; <a href="enterproduct.php">Add New Product</a> &nbsp; <a href="lookupcategory.php">Find and Edit a Product</a>
<br/><br/><hr/><br/>