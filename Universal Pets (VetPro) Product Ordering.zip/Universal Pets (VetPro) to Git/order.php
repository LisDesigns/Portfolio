<?php

$vStore = $_SESSION['Store'];

$vEmail = $_SESSION['email'];

$vAddress = $_SESSION['Address'];

$vSuburb = $_SESSION['Suburb'];

$vPhone = $_SESSION['Phone'];

?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<title>Universal Pets P/L Super-Quick Retailer Ordering System.</title>

</head>

<link href="css/styles.css" rel="stylesheet" type="text/css" media="all" />
<body>
<div="container">

<font color="#CC0033" size="+1"><strong>***Universal Pet Supplies Pty Ltd Order form for Vet Product Buyers***</strong></font>

    <a href="../index.html">HOME</a>

<!--

<font color="#CC0033" size="+1"><strong>***First Draft of the standard ordering system for Pets Product Buyers...[NOT FOR PUBLIC VIEW]***</strong></font>

    <a href="Untitled-1.htm">SITE VERSION A</a> --> <BR>



<form action="FormToEmail.php" method="post" name="OrderPost">



<table align="center" width="950"  border="0" cellspacing="0" cellpadding="0"><tr align="center" valign="top"><td>

<div align="left">

<table width="300" cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding=5 cellpadding="5"  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Advantage.html" target="_blank">Advantage</a></font></b></td>

          <td width="45"><center>4's</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>Kitten up to 4kg </td>

          <td><div align="center"><input size="2" type="text" name="advkit4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advkit6"></div></td>

        </tr>

        <tr>

          <td>Cats over 4kg </td>

          <td><div align="center"><input size="2" type="text" name="advcat4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advcat6"></div></td>

        </tr>

        <tr>

          <td>Dogs up to 4kg </td>

          <td><div align="center"><input size="2" type="text" name="advsdog4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advsdog6"></div></td>

        </tr>

        <tr>

          <td>Dogs 4-10kg </td>

          <td><div align="center"><input size="2" type="text" name="advmdog4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advmdog6"></div></td>

        </tr>

        <tr>

          <td>Dogs 10-25kg </td>

          <td><div align="center"><input size="2" type="text" name="advldog4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advldog6"></div></td>

        </tr>

        <tr>

          <td>Dogs 25kg Plus</td>

          <td><div align="center"><input size="2" type="text" name="advxldog4"></div></td>

          <td><div align="center"><input size="2" type="text" name="advxldog6"></div></td>

        </tr>

          

</table><BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="frontline_spray.html" target="_blank">Frontline</font></b></td>

          <td width="45">Size</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td><span class="t">Flea And Tick Control</span> Spray</td>

          <td>100ml</td>

          <td><div align="center"><input size="2" type="text" name="fronspry100"></div></td>

        </tr>

        <tr>

          <td><span class="t">Flea And Tick Control</span> Spray</td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="fronspry250"></div></td>

        </tr>

        <tr>

          <td><span class="t">Flea And Tick Control</span> Spray</td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="fronspry500"></div></td>

        </tr>

      </table><BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Heartgard.html" target="_blank">Heartgard</font></b></td>

          <td width="45">&nbsp;</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td><span class="t">S/Dog (0-11kg) Blue Chew's</span></td>

          <td>6's</td>

          <td><div align="center"><input size="2" type="text" name="heartgardBlue"></div></td>

        </tr>

        <tr>

          <td><span class="t">M/Dog (12-22kg) Green Chew's </span></td>

          <td>6's</td>

          <td><div align="center"><input size="2" type="text" name="heartgardGreen"></div></td>

        </tr>

        <tr>

          <td><span class="t">L/Dog (23-45kg) Brown Chew's </span></td>

          <td>6's</td>

          <td><div align="center"><input size="2" type="text" name="heartgardBrown"></div></td>

        </tr>

      </table><BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Proheart.html" target="_blank">Proheart</font></b></td>

          <td width="45">&nbsp;</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td><span class="t">S/Dogs (up to 11kg) Blue </span></td>

          <td>6 Tabs </td>

          <td><div align="center"><input size="2" type="text" name="ProheartBlue"></div></td>

        </tr>

        <tr>

          <td><span class="t">M/Dogs (11-22kg) Green </span></td>

          <td>6 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="ProheartGreen"></div></td>

        </tr>

        <tr>

          <td><span class="t">L/Dogs (23-45kg) Red </span></td>

          <td>6 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="ProheartRed"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs (46-68kg) Yellow </td>

          <td>6 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="ProheartYellow"></div></td>

        </tr>

      </table><BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1">Dermcare - VET </font></b></td>

          <td width="45">Size</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td>Malaseb</td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="Malaseb250"></div></td>

        </tr>

        <tr>

          <td>Malaseb</td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="Malaseb500"></div></td>

        </tr>

        <tr>

          <td>Malaseb</td>

          <td>1 Litre </td>

          <td><div align="center"><input size="2" type="text" name="Malaseb1000"></div></td>

        </tr>

        <tr>

          <td>Pyohex Foam </td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="PyohexFoam250"></div></td>

        </tr>

        <tr>

          <td>Pyohex Lotion </td>

          <td>100ml</td>

          <td><div align="center"><input size="2" type="text" name="PyohexLotion100"></div></td>

        </tr>

        <tr>

          <td>Pyohex Lotion </td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="PyohexLotion500"></div></td>

        </tr>

        <tr>

          <td>Natural Shampoo </td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="NaturalShampoo250"></div></td>

        </tr>

        <tr>

          <td>Natural Shampoo</td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="NaturalShampoo500"></div></td>

        </tr>

        <tr>

          <td>Natural Shampoo</td>

          <td>1 Litre </td>

          <td><div align="center"><input size="2" type="text" name="NaturalShampoo1000"></div></td>

        </tr>

        <tr>

          <td>Natural Shampoo</td>

          <td>5 Litre </td>

          <td><div align="center"><input size="2" type="text" name="NaturalShampoo5000"></div></td>

        </tr>

        <tr>

          <td>Aloveen Shampoo </td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="AloveenShampoo250"></div></td>

        </tr>

        <tr>

          <td>Aloveen Shampoo</td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="AloveenShampoo500"></div></td>

        </tr>

        <tr>

          <td>Aloveen Shampoo</td>

          <td>1 Litre</td>

          <td><div align="center"><input size="2" type="text" name="AloveenShampoo1000"></div></td>

        </tr>

        <tr>

          <td>Aloveen Conditioner</td>

          <td>100ml</td>

          <td><div align="center"><input size="2" type="text" name="AloveenConditioner100"></div></td>

        </tr>

        <tr>

          <td>Aloveen Conditioner</td>

          <td>200ml</td>

          <td><div align="center"><input size="2" type="text" name="AloveenConditioner200"></div></td>

        </tr>

        <tr>

          <td>Aloveen Conditioner</td>

          <td>500ml</td>

          <td><div align="center"><input size="2" type="text" name="AloveenConditioner500"></div></td>

        </tr>

        <tr>

          <td>Aloveen Combo </td>

          <td>1 Pack </td>

          <td><div align="center"><input size="2" type="text" name="AloveenCombo"></div></td>

        </tr>

        <tr>

          <td>Permoxin</td>

          <td>250ml</td>

          <td><div align="center"><input size="2" type="text" name="Permoxin250"></div></td>

        </tr>

      </table><BR>

	  

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1">Nuheart 6's </font></b></td>

          <td width="45">6's</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td><span class="t">S/Dogs (up to 11kg) Blue </span></td>

          <td>Blue</td>

          <td><div align="center"><input size="2" type="text" name="NuheartBlue6"></div></td>

        </tr>

        <tr>

          <td><span class="t">M/Dogs (11-23kg) Green </span></td>

          <td>Green</td>

          <td><div align="center"><input size="2" type="text" name="NuheartGreen6"></div></td>

        </tr>

        <tr>

          <td><span class="t">L/Dogs (+23kg) Brown </span></td>

          <td>Brown</td>

          <td><div align="center"><input size="2" type="text" name="NuheartBrown6"></div></td>

        </tr>

      </table><BR>	  



</div>       

</td><td>

<div align="left">

	  

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Advantix.html" target="_blank">Advantix</font></b></td>

          <td width="45"><center>3's</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>S/Dog up to 4kg </td>

          <td><div align="center"><input size="2" type="text" name="Advantixsdog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="Advantixsdog6"></div></td>

        </tr>

        <tr>

          <td>M/Dogs 4-10kg </td>

          <td><div align="center"><input size="2" type="text" name="Advantixmdog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="Advantixmdog6"></div></td>

        </tr>

        <tr>

          <td>L/Dogs 10-25kg</td>

          <td><div align="center"><input size="2" type="text" name="Advantixldog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="Advantixldog6"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs 25kg Plus</td>

          <td><div align="center"><input size="2" type="text" name="Advantixxldog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="Advantixxldog3"></div></td>

        </tr>

          

</table><BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="frontline.html" target="_blank">Frontline Plus </font></b></td>

          <td width="45"><center>3's</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td><span class="t">Cat All Sizes</span></td>

          <td><div align="center"><input size="2" type="text" name="FronCat3"></div></td>

          <td><div align="center"><input size="2" type="text" name="FronCat6"></div></td>

        </tr>

        <tr>

          <td><span class="style54">S/Dogs up to 10kg</span></td>

          <td><div align="center"><input size="2" type="text" name="FronSDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="FronSDog6"></div></td>

        </tr>

        <tr>

          <td><span class="t">M/Dogs <span class="style54">10-20kg</span></span></td>

          <td><div align="center"><input size="2" type="text" name="FronMDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="FronMDog6"></div></td>

        </tr>

        <tr>

          <td><span class="t">L/Dogs <span class="style54">20-40kg</span></span></td>

          <td><div align="center"><input size="2" type="text" name="FronLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="FronLDog6"></div></td>

        </tr>

        <tr>

          <td><span class="t">XL/Dogs <span class="style54">40-60kg</span></span></td>

          <td><div align="center"><input size="2" type="text" name="FronXLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="FronXLDog6"></div></td>

        </tr>		

      </table>

<BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="189"><b><font size="+1">Drontal</font></b></td>

          <td width="58">Size</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td>Cat 4kg &amp; Applicator</td>

          <td>2 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontCat2Tab"></div></td>

        </tr>

        <tr>

          <td>Cat 4kg </td>

          <td>4 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontCat4Tab"></div></td>

        </tr>

        <tr>

          <td>Cat 4kg </td>

          <td>60 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontCat60Tab"></div></td>

        </tr>

        <tr>

          <td>Large Cats +6kg</td>

          <td>50 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontLCat50Tab"></div></td>

        </tr>

        <tr>

          <td>Dogs 3kg</td>

          <td>4 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontSDog4Tab"></div></td>

        </tr>

        <tr>

          <td>Dogs 3kg</td>

          <td>50 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontSDog50Tab"></div></td>

        </tr>

        <tr>

          <td>Dogs 10kg</td>

          <td>80 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontMDog80Chws"></div></td>

        </tr>

        <tr>

          <td>Dogs 10kg</td>

          <td>25 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontMDog25Chws"></div></td>

        </tr>

        <tr>

          <td>Dogs 10kg</td>

          <td>5 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontMDog5Chws"></div></td>

        </tr>

        <tr>

          <td>Dogs 10kg</td>

          <td>2 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontMDog2Chws"></div></td>

        </tr>

        <tr>

          <td>Dogs 10kg</td>

          <td>100 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="DrontMDog100Tabs"></div></td>

        </tr>

        <tr>

          <td>Dogs 35kg </td>

          <td>20 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontLDog20Chws"></div></td>

        </tr>

        <tr>

          <td>Dogs 35kg </td>

          <td>2 Chws</td>

          <td><div align="center"><input size="2" type="text" name="DrontLDog2Chws"></div></td>

        </tr>

        <tr>

          <td>Puppy Suspension </td>

          <td>30ml</td>

          <td><div align="center"><input size="2" type="text" name="PupSus30ml"></div></td>

        </tr>

				

      </table>

<BR>

      

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1">Collars, Tick &amp; Others</font></b></td>

          <td width="45">Size</td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td><span class="t">Preventic Collar </span></td>

          <td>6 Tabs </td>

          <td><div align="center"><input size="2" type="text" name="PrevCollar"></div></td>

        </tr>

        <tr>

          <td><span class="t">Kiltix Collar </span></td>

          <td>2.5</td>

          <td><div align="center"><input size="2" type="text" name="KilCollar"></div></td>

        </tr>

        <tr>

          <td><span class="t">Felex Plus Paste</span></td>

          <td>2.5gm</td>

          <td><div align="center"><input size="2" type="text" name="FelexPlusPaste"></div></td>

        </tr>		

        <tr>

          <td><span class="t">Capstar S/Dogs &amp; Cats (Blue) </span></td>

          <td>6 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="CapstarSDog"></div></td>

        </tr>

        <tr>

          <td>Capstar L/Dog (Green) </td>

          <td>6 Tabs</td>

          <td><div align="center"><input size="2" type="text" name="CapstarLDog"></div></td>

        </tr>

        <tr>

          <td>Sasha's Blend</td>

          <td>250gm</td>

          <td><div align="center"><input size="2" type="text" name="SashaBlend250"></div></td>

        </tr>

        <tr>

          <td>Divetalact</td>

          <td>375gm</td>

          <td><div align="center"><input size="2" type="text" name="Divetalact375"></div></td>

        </tr>

      </table><BR>	  

	  

<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1">Profender Cat </font></b></td>

          <td width="45"><center>Size</center></td>

          <td width="45"><center>QTY</center></td>

        </tr>

        <tr>

          <td>S/Cat (0-2.5kg)</td>

          <td><div align="center">40Tabs </div></td>

          <td><div align="center"><input size="2" type="text" name="ProfSCat40Tab"></div></td>

        </tr>

        <tr>

          <td>M/Cat (2.5-5kg)</td>

          <td><div align="center">40Tabs</div></td>

          <td><div align="center"><input size="2" type="text" name="ProfMCat40Tab"></div></td>

        </tr>

        <tr>

          <td>L/Cat (5-8kg)</td>

          <td><div align="center">40Tabs</div></td>

          <td><div align="center"><input size="2" type="text" name="ProfLCat40Tab"></div></td>

        </tr>

        <tr>

          <td>M/Cat (2-5kg)</td>

          <td><div align="center">2 Tabs</div></td>

          <td><div align="center"><input size="2" type="text" name="ProfMCat2Tab"></div></td>

        </tr>

        <tr>

          <td>L/Cat (5-8kg)</td>

          <td><div align="center">2 Tabs</div></td>

          <td><div align="center"><input size="2" type="text" name="ProfLCat2Tab"></div></td>

        </tr>

</table><BR>



</div>

</td><td>

<div align="left">



<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Advocate.html" target="_blank">Advocate</font></b></td>

          <td width="45"><center>3's</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>Kitten up to 4kg</td>

          <td><div align="center"><input size="2" type="text" name="AdvoKit3"></div></td>

          <td><div align="center"><input size="2" type="text" name="AdvoKit6"></div></td>

        </tr>

        <tr>

          <td>Cats over 4kg </td>

          <td><div align="center"><input size="2" type="text" name="AdvoCat3"></div></td>

          <td><div align="center"><input size="2" type="text" name="AdvoCat6"></div></td>

        </tr>

        <tr>

          <td>S/Dogs up to 4kg </td>

          <td><div align="center"><input size="2" type="text" name="AdvoSDog3"></div></td>

          <td><div align="center">N/A</div></td>

        </tr>

        <tr>

          <td>M/Dogs 4-10kg </td>

          <td><div align="center"><input size="2" type="text" name="AdvoMDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="AdvoMDog6"></div></td>

        </tr>

        <tr>

          <td>L/Dogs 10-25kg </td>

          <td><div align="center"><input size="2" type="text" name="AdvoLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="AdvoLDog3"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs +25kg </td>

          <td><div align="center"><input size="2" type="text" name="AdvoXLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="AdvoXLDog3"></div></td>

        </tr>

</table><BR>



<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Revolution.html" target="_blank">Revolution</font></b></td>

          <td width="45"><center>3's</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>Kitten &amp; Puppy</td>

          <td><div align="center"><input size="2" type="text" name="RevKit3"></div></td>

          <td><div align="center">N/A</div></td>

        </tr>

        <tr>

          <td>Cat All Sizes </td>

          <td><div align="center"><input size="2" type="text" name="RevCat3"></div></td>

          <td><div align="center"><input size="2" type="text" name="RevCat6"></div></td>

        </tr>

        <tr>

          <td>S/Dogs 2.6-5kg</td>

          <td><div align="center"><input size="2" type="text" name="RevSDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="RevSDog6"></div></td>

        </tr>

        <tr>

          <td>M/Dogs 5-10kg</td>

          <td><div align="center"><input size="2" type="text" name="RevMDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="RevMDog6"></div></td>

        </tr>

        <tr>

          <td>L/Dogs 10-20kg</td>

          <td><div align="center"><input size="2" type="text" name="RevLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="RevLDog6"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs 20-40kg</td>

          <td><div align="center"><input size="2" type="text" name="RevXLDog3"></div></td>

          <td><div align="center"><input size="2" type="text" name="RevXLDog6"></div></td>

        </tr>

        

</table>

<BR>



<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1"><a href="Interceptor.html" target="_blank">Interceptor Spectrum </font></b></td>

          <td width="45"><center>Colour</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>S/Dogs (up to 4kg) (Brown)</td>

          <td><div align="center">Brown</div></td>

          <td><div align="center"><input size="2" type="text" name="InterSpectBrown"></div></td>

        </tr>

        <tr>

          <td>M/Dogs (4-11kg) (Green)</td>

          <td><div align="center">Green</div></td>

          <td><div align="center"><input size="2" type="text" name="InterSpectGreen"></div></td>

        </tr>

        <tr>

          <td>L/Dogs (11-22kg) (Yellow)</td>

          <td><div align="center">Yellow</div></td>

          <td><div align="center"><input size="2" type="text" name="InterSpectYellow"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs (+22kg) (White)</td>

          <td><div align="center">White</div></td>

          <td><div align="center"><input size="2" type="text" name="InterSpectWhite"></div></td>

        </tr>

          

</table><BR>



<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="203"><b><font size="+1"><a href="Sentinel.html" target="_blank">Sentinal Spectrum</font></b></td>

          <td width="45"><center>Colour</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>S/Dogs (up to 4kg) (Brown)</td>

          <td><div align="center">Brown</div></td>

          <td><div align="center"><input size="2" type="text" name="SentSpectBrown"></div></td>

        </tr>

        <tr>

          <td>M/Dogs (4-11kg) (Green)</td>

          <td><div align="center">Green</div></td>

          <td><div align="center"><input size="2" type="text" name="SentSpectGreen"></div></td>

        </tr>

        <tr>

          <td>L/Dogs (11-22kg) (Yellow)</td>

          <td><div align="center">Yellow</div></td>

          <td><div align="center"><input size="2" type="text" name="SentSpectYellow"></div></td>

        </tr>

        <tr>

          <td>XL/Dogs (+22kg) (White)</td>

          <td><div align="center">White</div></td>

          <td><div align="center"><input size="2" type="text" name="SentSpectWhite"></div></td>

        </tr>

          

</table>

<BR>



<table width="300" cellpadding=5  border="1" cellspacing="0" cellpadding="0">

        <tr>

          <td width="210"><b><font size="+1">Troy</font></b></td>

          <td width="45"><center>Size</center></td>

          <td width="45"><center>6's</center></td>

        </tr>

        <tr>

          <td>Repel-X</td>

          <td><div align="center">125ml</div></td>

          <td><div align="center"><input size="2" type="text" name="RepelX-125ml"></div></td>

        </tr>

        <tr>

          <td>Repel-X</td>

          <td><div align="center">500ml</div></td>

          <td><div align="center"><input size="2" type="text" name="RepelX-500ml"></div></td>

        </tr>

        <tr>

          <td>Cat Allwormer </td>

          <td><div align="center">4's</div></td>

          <td><div align="center"><input size="2" type="text" name="TroyCatAllWormer4"></div></td>

        </tr>

          

</table>

<BR><BR><BR>



<table  bgcolor="#CCCCCC" width="300"  border="1" cellspacing="0" cellpadding="0">

        <tr><td colspan=2><b><font size="+1">Store Details:</font></b></td></tr>

        <tr>

          <td>Date</td>

          <td><div align="left"><textarea cols="25" rows="3" name="email" READONLY><?php echo date("M d, Y");?>

</textarea></div></td>

          </tr>	

        <tr>

          <td>Email: <!-- <font color="#CC0000">*</font>--> </td>

         <td><div align="left"><textarea cols="25" rows="3" name="email" READONLY><?php echo $vEmail; ?>

</textarea></div></td>

          </tr>	

        <tr>

          <td width="59" valign="top">Store Name:<!-- <font color="#CC0000">*</font>--></td>

          <td width="235"><div align="left"><textarea  cols="25" rows="3" name="Store_Name" READONLY><?php echo $vStore; ?>

</textarea></div></td>

          </tr>

        <tr>

          <td valign="top">Store Address:<!-- <font color="#CC0000">*</font>--></td>

          <td><div align="left"><textarea  cols="25" rows="3" name="Store_Address" READONLY><?php echo $vAddress ." ". $vSuburb; ?>

</textarea></div></td>

          </tr>

        <tr>

          <td valign="top">Phone #:<!-- <font color="#CC0000">*</font>--></td>

          <td><div align="left"><textarea cols="25" rows="3" name="Store_Phone" READONLY><?php echo $vPhone; ?>

</textarea></div></td>

          </tr>		  

        <tr>

          <td>Name:<font color="#CC0000">*</font></td>

          <td bgcolor="#FF9799"><div align="left"><input size="33" type="text" name="Ordered_By"></div></td>

<!-- $_SESSION['userName'] -->

        </tr>

        <tr>

          <td>Position:</td>

          <td bgcolor="#FF9799"><div align="left"><input size="33" type="text" name="My_Position"></div></td>

        </tr>

        <tr>

          <td>Notes:</td>

          <td><div align="left"><textarea  cols="25" rows="5" name="Notes"></textarea></div></td>

        </tr>

        <tr><td></td>

          <td colspan=2><center>

		  &nbsp;&nbsp;<a onClick="window.print();"><img src="_images/print_big.gif"></a>

<!--		  &nbsp;&nbsp;<a onClick="alert('Thank You. Your order has been sent.');"><img src="_images/buy_big.gif"></a> -->

		  &nbsp;&nbsp;<a href="mailto:sales@universalpet.com.au"><img src="_images/contact_big.gif"></a>	&nbsp;&nbsp;<a><input value="Send" input type="image" src="_images/buy_big.gif" ></a></center></td>



        </tr>

          

</table>

<BR>



</div>             

</td></tr></table>

 

 <table width="100%"  border="0" cellspacing="0" cellpadding="0">

  <tr>

    <td width="27%">

		&nbsp;&nbsp;<BR>

	    &nbsp;&nbsp;Universal Pet Supplies Pty Ltd<BR>

	    &nbsp;&nbsp;36 Mid Dural Rd<BR>

	    &nbsp;&nbsp;Galston NSW 2159<BR>

		&nbsp;&nbsp;Phone: (02) 8207 0111<BR>

		&nbsp;&nbsp;Fax: (02) 8207 0103<BR>

		&nbsp;&nbsp;Mob: 0401 223 369<BR>

		&nbsp;&nbsp;Email: <a href="mailto:sales@universalpet.com.au">sales [at] universalpet.com.au</a><BR>

		&nbsp;&nbsp;Web: <a href="http://www.universalpet.com.au">www.universalpet.com.au</a><BR>

	</td>

    <td width="73%">

		<font color="#CC0000">*</font> Denotes Required Field to be completed correctly for order to be valid.

		<BR><BR>

           This is an Order Form only for Authorised Retailers of Universal Pet Supplies Pty Ltd<BR>

           You may submit, print, email, phone in or mail this order.<BR>

         <ul>Order delivery policy:

		 <li>   For all orders placed/received before 1.30pm EST are dispatched that day for next day delivery.</li>

		 <li>   For all orders placed/received after 1.30pm EST will be dispatched first light of the very next day for same day delivery (Sydney Metro).</li>

        </ul>

		For further Terms and Conditions of sale or other general information please follow our links to our web site or Universal Pet Supplies can be contacted at the corresponding numbers.

		



	  </td>

  </tr>

</table>





      



<BR>

<div align="right">PAGE CREATED:April 30th 2008</div>



<SCRIPT LANGUAGE="JavaScript">

  var nd = new Date();

  var tmp;

  var time=nd.toString();

  tmp=time.search("UTC");

  time=time.substring(0,tmp-4);

  document.OrderPost.the_time.value=time;

  



	function disableEnterKey(e){

		if(e.keyCode == 13){

			Document.Event.keyCode=9; //return the tab key

			Event.cancelBubble = true;

		}

	}

   

  

</SCRIPT>



<script type="text/javascript">

//Stops the abritrary enter key from stopping the submission of the form.

function stopRKey(evt) {

  var evt = (evt) ? evt : ((event) ? event : null);

  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);

  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}

}



document.onkeypress = stopRKey;



</script>


</div>
</body>



</html>

