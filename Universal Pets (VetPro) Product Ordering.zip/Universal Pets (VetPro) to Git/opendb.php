<?php
include('config.php');
$conn=mysql_connect($dbhost,$dbuser,$dbpass) or die('Error connecting to Alumni DB');
mysql_select_db($dbname) or die('Database cannot be selected');
?>