<?php

include "includes/header.php";
?>
<body>

<h1>Register here</h1>
<form id="form1" name="form1" method="post" action="reg_submit.php">
<table>
<tr><td>Username:   </td><td><label>  <input type="text" name="user" id="user" />  </label></td></tr>
<tr><td>Password:     </td><td><label><input type="password" name="pass" id="pass" /></label></td></tr>
<tr><td>Store:   </td><td>  <input type="text" name="store" id="store" />  </label></td></tr>
<tr><td>Address:   <label></td><td>  <input type="text" name="address" id="address" />  </label></td></tr>
<tr><td>Suburb:   <label></td><td>  <input type="text" name="suburb" id="suburb" />  </label></td></tr>
<tr><td>Phone:   <label></td><td>  <input type="text" name="phone" id="phone" />  </label></td></tr>
<tr><td>Email:   <label></td><td>  <input type="text" name="email" id="email" /></label></td></tr>
<tr><td></td><td><label>    <input type="submit" name="submit" id="submit" value="Submit" />    </label></td></tr></form><p>&nbsp; </p></body>
</html>