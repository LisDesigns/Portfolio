<?
header("Pragma:no-cache");
include "includes/header.php";
include "../includes/dbconn.php";


  $pages ='<select class="val" name="page_options" id="page_options" onchange="clearoption('."'page'".')"><option>Pages Available</option>';
  $query  = "SELECT DISTINCT page FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  while($row = mysql_fetch_assoc($result)){
    $page=$row['page'];
    $pages.="<option>".$page."</option>"; 
  }
  $pages.="</select>";


  $categories ='<select class="val" name="category_options" id="category_options" onchange="clearoption('."'category'".')"><option>Categories Available</option>';
  $query  = "SELECT DISTINCT category FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }


  while($row = mysql_fetch_assoc($result)){
    $category=$row['category'];
    $categories.="<option>".$category."</option>"; 
  }
  $categories.="</select>";

  $subcategories ='<select class="val" name="subcategory_options" id="subcategory_options" onchange="clearoption('."'subcategory'".')"><option>Subcategories Available</option>';
  $query  = "SELECT DISTINCT subcategory FROM `products_new`";
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }


  while($row = mysql_fetch_assoc($result)){
    $subcategory=$row['subcategory'];
    $subcategories.="<option>".$subcategory."</option>"; 
  }
  $subcategories.="</select>";





$tableId = $_GET["tableId"];

$query  = "SELECT * FROM `products_new` WHERE `tableId`='".$tableId."'";
$x =0;
      $x++;
$result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

  while($row = mysql_fetch_assoc($result)){
    $lastcategory = $category;
    $lastsubcategory = $subcategory;
    $tableId=$row['tableId'];
    $productId=$row['productId'];
    $page=$row['page'];
    $category=$row['category'];
    $subcategory=$row['subcategory'];
    $qty=$row['qty'];
    $price=$row['price'];
    $name=$row['name'];
    $image=$row['image'];
    $onspecial=$row['onspecial'];
  }

?>

<h1>Edit Product</h1>
<form name="editproduct" action="updateproduct.php" method="post" enctype="multipart/form-data">

<input type="hidden" name="tableId" value="<? echo $tableId; ?>"/>
<table>
<tr><td class="tdh1">Order Page Name</td><td><? echo $pages; ?><br/><input type="text" class="val" name="page" value="<? echo $page; ?>"></td></tr>
<tr><td class="tdh1">Category</td><td><br/><? echo $categories; ?><br/><input type="text" class="val" name="category" value="<? echo $category; ?>"></td></tr>
<tr><td class="tdh1">Subcategory</td><td><? echo $subcategories; ?><br/><input type="text" class="val" name="subcategory" value="<? echo $subcategory; ?>"></td></tr>
<tr><td class="tdh1">Product Id</td><td><input type="text" class="val" name="productId" value="<? echo $productId; ?>"></td></tr>
<tr><td class="tdh1">Item Name</td><td><input type="text" class="val" name="itemName" value="<? echo $name; ?>"></td></tr>
<tr><td class="tdh1">Size/Amount Per Package</td><td><input type="text" class="val" name="qty" value="<? echo $qty; ?>"></td></tr>
<tr><td class="tdh1">Price</td><td><input type="text" class="val" name="price" value="<? echo $price; ?>"></td></tr>
<tr><td class="tdh1">On Special</td><td><select name="onspecial" id="onspecial"><option><? echo $onspecial; ?></option><option>No</option><option>Yes</option></select></td></tr>
<tr><td class="tdh1">Change Image</td><td><input type="file" name="file1" id="file1"></td></tr>
<tr><td class="tdh1"></td><td><input type="submit" class="val" value="Update Product"></td></tr>
</table>
</form>
<? 

$filename = "../uploads/".$tableId.".jpg";

if (file_exists($filename)) {
?>
<img src="<? echo $filename; ?>" alt=""/>
<?
}

include "includes/footer.php";
?>