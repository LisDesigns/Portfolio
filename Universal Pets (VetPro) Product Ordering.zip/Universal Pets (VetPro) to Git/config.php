<?php
$dbname='universa_ups1';
$dbpass='access12';
$dbuser='universa_pet';
$dbhost='localhost'; //99% of the time this remains same
?>