<?php
$user=$_POST['user'];
$pass=($_POST['pass']);
$store=($_POST['store']);
$address=($_POST['address']);
$suburb=($_POST['suburb']);
$phone=($_POST['phone']);
$email=($_POST['email']);

include('config.php');
include('opendb.php');
$query="INSERT INTO user_tbl (UserName, Password, Store, Address, Suburb, Phone, Email) VALUES ('$user', '$pass', '$store', '$address', '$suburb', '$phone', '$email')";
mysql_query($query) or die('Cannot Execute! Email to abhi@adeydas.com');
echo('Registration complete!');
include('closedb.php');
?>