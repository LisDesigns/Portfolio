<? 
  session_start();
  session_destroy();

  include "inc/header_logout.dat";
?>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>

<p style="margin-left:6px"/>You have been logged out.

<p style="margin-left:6px"/>Buh-bye, have a nice day.
<br/>

<?

include "inc/footer.dat";

?>






