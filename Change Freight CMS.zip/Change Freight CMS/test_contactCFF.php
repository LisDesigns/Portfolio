<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Freight Forwarding Australia</title>
<style type="text/css">
    div#footer{color:#c8e0fc;rgb(175,175,175); margin-top:8px;padding-bottom:0px; margin-bottom:0px; font-size:12px;       		font-weight:700; width:1003px; height:30px; line-height:30px;position:absolute; top:670px; left:0px;}
    div#container1{position:absolute; top:0px; left:-1px; width:1003px; height:680px;background-image:url(softblankbg2inside2.jpg)}
</style>
<?php include("header.html"); ?>
<h1><i>Contact CFF</i></h1>
<hr/>


<table style="border-collapse:collapse; width:700px">
<tr>
<td valign="top" align="left">

<?php
  include "cms/inc/contactpage.dat";
?>

</td>
<td valign="top" align="right" width="400">
  <br/>
  <iframe width="400" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://www.whereis.com/embed.htm?id=809F7D76A231F7"></iframe>
</td>
</tr>
</table>  

<?php include("footer.html"); ?>