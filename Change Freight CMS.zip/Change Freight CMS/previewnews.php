<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  include "inc/header_preview.dat";
?>


<h3>Preview Page</h3>
<form name="previewpage" action="savenews.php" method="post" enctype="multipart/form-data" style="display:inline;width:300px;">
<div style="width:400px;height:400px">
<?

  $pagename = $_POST['preview_pagename'];

  $text3 = $_POST['text3'];
  $text4 = $_POST['text4'];
  $text5 = $_POST['text5'];

  $text3 = substr($text3, 0, 175);    
  $text4 = substr($text4, 0, 175); 
  $text5 = substr($text5, 0, 175); 

  $str3 = preg_replace('/\\\"/', '"', $text3);
  $str4 = preg_replace('/\\\"/', '"', $text4);
  $str5 = preg_replace('/\\\"/', '"', $text5);

  $preview_pagename = "inc/".$pagename."dat";
  echo "News Box1:<br/>".$str3."<br/><br/>";
  echo "News Box2:<br/>".$str4."<br/><br/>";
  echo "News Box3:<br/>".$str5."<br/>";

  $openpage = fopen("inc/preview_newsbox1.dat", "w");
  fwrite($openpage, "$str3");
  fclose($openpage);

  $openpage = fopen("inc/preview_newsbox2.dat", "w");
  fwrite($openpage, "$str4");
  fclose($openpage);

  $openpage = fopen("inc/preview_newsbox3.dat", "w");
  fwrite($openpage, "$str5");
  fclose($openpage);

  echo "<input name='preview_pagename' type='hidden' value='$pagename'/>";

?>
</div>
<br/><br/><br/>
<img src="images/cancelchanges.jpg" onclick="previewpage_cancelchanges.submit()"/> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 

<input type="image" src="images/save.jpg" value="Save"/> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
</form>

<form name="previewpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="" name="mode"/>
</form>

<form name="previwpage_cancelchanges" action="editnewssection.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="preview" name="mode"/>
<input type="image" src="images/continueediting.jpg" onclick="previewpage_cancelchanges.submit()"/>
</form>

 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="../test_index.php" target="_blank"><img src="images/previewlive.jpg" border="0"></a>



<?

include "inc/footer2.dat";

?>
