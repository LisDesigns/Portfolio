<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

  <style type="text/css">
    body{margin:0px;font-family:arial}
    h4{font-size:14px;}
    div#container1{border:solid rgb(232,232,232) 1px; top:0px; width:1005px; height:614px;background-image:url(softblankbg2.jpg); text-align:left}

    img#logo{margin-top:;16px;border-style:none;}

    h3#tagline{margin-top:;0px; margin-left:180px;color:#71a2dc;font-size:16px}

    div#topmenu{color:rgb(245,245,245); margin-top:8px;padding-bottom:0px; margin-bottom:0px;font-size:13px;font-weight:700; margin-left:;310px;width:680px}

    div#sidemenu{display:block;height:152px; color:rgb(100,100,100); top:;237px; margin-left:70px; margin-top:24px; 
	font-size:13px; font-weight:900;line-height:;38px;  
    }
    div#footer{color:#c8e0fc;rgb(175,175,175);padding-bottom:0px; margin-bottom:0px; font-size:12px; font-weight:700; width:990px; margin-left:8px;}
    div#intro{font-size:12px; width:380px;margin-left:43px;
	padding:4px; color:#397bc5;}
    div#news{ color:#397bc5; 	margin-top:;240px; margin-left:;817px; font-size:12px; padding:4px}
    div#submenu{padding-left:2px;background-color:#397bc5;2d318a; color:white; font-family:arial;font-size:13px;
	font-weight:bold;width:124px; height:133px; visibility:hidden;top:214px;position:absolute;line-height:22px;
	cursor:pointer;}
    a.toplinks:link{color:rgb(245,245,245); text-decoration:none;}
    a.toplinks:visited{color:rgb(245,245,245); text-decoration:none;}
    a.toplinks:active{color:rgb(245,245,245); text-decoration:none;}
    a.toplinks:hover{color:#9edcfb;text-decoration:underline;}
    a.sidelinks:link{color:rgb(245,245,245); text-decoration:none;}
    a.sidelinks:visited{color:rgb(245,245,245); text-decoration:none;}
    a.sidelinks:active{color:rgb(245,245,245); text-decoration:none;}
    a.sidelinks:hover{color:#9edcfb;text-decoration:none;}
    a.footerlinks:link{color:#c8e0fc; text-decoration:none;}
    a.footerlinks:visited{color:#c8e0fc; text-decoration:none;}
    a.footerlinks:active{color:#c8e0fc; text-decoration:none;}
    a.footerlinks:hover{color:white; text-decoration:underline;}


  </style>

</head>
<body >
<center><script language="JavaScript1.2" type="text/javascript">    
    cntr = (screen.width/2);
    containerleft=((cntr-646)+"px");
   // document.getElementById("container1").style.left=containerleft;
 
    document.write('<div id="container1" style="left:'+containerleft+';margin-right:10px;">');
</script>
<noscript>
    <div id="container1">
</noscript>


<table border="0" width="1002" style="border-collapse:collapse">
 <tr>
 
  <td height="180" valign="top" align="center" colspan="2"><br/><br/>
  <h3 id="tagline"><i>Welcome to CFF &nbsp;&quot;the total advantage one world logistics solution&quot;</i></h3>
  </td>
  <td valign="top" align="center"><br/><a href="http://www.changefreight.com.au"><img src="softlogo.jpg" id="logo1" alt="Change Freight Forwarding" border="0"/></a></td>
 </tr>
 <tr>
  <td colspan="3" height="28" align="right" valign="top">

<div id="topmenu">
  <a href="index.php" class="toplinks">Home</a> &nbsp; &nbsp;
  <a href="aboutCFF.php" class="toplinks">About CFF</a> &nbsp; &nbsp;
  <a href="services.php" class="toplinks">Services</a>&nbsp; &nbsp; 
  <a href="track.php" class="toplinks">Track</a>&nbsp; &nbsp; 
  <a href="contactCFF.php" class="toplinks">Contact CFF</a>&nbsp; &nbsp; 
  <a href="help.php" class="toplinks">Help</a>&nbsp; &nbsp;
  <a href="careers.php" class="toplinks">Careers  at CFF</a>&nbsp; &nbsp; 
  <a href="partners.php" class="toplinks">Partners</a>&nbsp; &nbsp;<a href="sitemap.php" class="toplinks">Site Map</a>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

  </td>
 </tr>
 <tr>
  <td height="377" width="300" valign="top">
<div id="sidemenu">
 
  <div style="line-height:16px;height:16px!important;"><a href="requestaQuote.php" class="sidelinks" >Request a Quote</a></div>
  <br/><div style="line-height:26px;height:26px!important;"><a href="makeaBooking.php" class="sidelinks" >Make a Booking</a></div>
  <br/><div style="line-height:22px;height:22px!important;"><a href="openAccount.php" class="sidelinks" >Open an Account</a></div>
  <br/><div style="line-height:24px;height:24px!important;"><a href="payAccount.php" class="sidelinks" >Pay Account</a></div>
  <br/><div style="line-height:14px;height:14px!important;"><a href="logintoCFF.php" class="sidelinks" >Login to CFF</a></div>
  <br/><div style="line-height:28px;height:24px!important;padding-top:3px;"><a href="FAQ.php" class="sidelinks" >FAQ</a></div>
  <br/><div style="line-height:16px;height:16px!important;margin-top:3px"><a href="tools.php" class="sidelinks" >Tools</a></div>
</div>
 </td><td width="454" valign="top">
<div id="intro" >
<?php
  include "cms/inc/homepage.dat";
?>
</div>
  </td>
  <td width="264" valign="top">
<br/><br/><h4 style="color:#397bc5;"><i>News</i></h4>

<iframe id="news" src="test_scroll.php" frameborder="0" scrolling="yes" style="border-style:none; background-color:white; width:263px;height:129px">

</iframe>

  <h4 style="color:#397bc5;"><i>Track your Shipment</i></h4>
  <form style="display:inline">
  <input type="text" style="border-style:none;solid; border-width:1px; border-color:rgb(240,240,240);"/> <input type="button" value="Track" style="background-color:#397bc5;border-color:white; border-width:1px; color:rgb(240,240,240); font-weight:bold; font-size:12px"/>
  </form>
   </td>
  </tr>
  <tr>
   <td colspan="3" valign="top">
<div id="footer">
  &nbsp; &copy; &nbsp;Copyright 2009 Freight Forwarding Australia. All rights reserved. Website by <a href="http://www.lisdesigns.com.au" target="_blank" class="footerlinks">Lis Designs</a>.
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


  <a href="privacy.php" class="footerlinks" >Privacy Policy</a>&nbsp;&nbsp;
  <a href="tradingTerms.php" class="footerlinks" >Trading Terms</a>&nbsp;&nbsp;
  <a href="disclaimer.php" class="footerlinks" >Disclaimer</a>
</div>
</td>
</tr>
</table>

</div>
</center>

</body>
</html>