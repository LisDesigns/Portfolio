<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  include "inc/header_upload.dat";

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 200000))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    //echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    echo "<h3>Image Upload</h3>";

    echo "<b>Your image was uploaded successfully.</b><br/><br/>";
   echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    //echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";


    echo '<br/><form name="editpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
        <input type="hidden" value="" name="mode"/> Please click below to return home.  <br/><br/>
        <input type="image" src="images/admincentre.jpg" value="Admin Centre" onclick="editpage_cancelchanges.submit()"/> 
        </form><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><font color="#ededed">';    

    //if (file_exists("uploads/" . $_FILES["file"]["name"]))
    //  {
    //  echo '<b>Error:</b> '.$_FILES["file"]["name"] . " already exists. ";
    //  }
    //else
    //  {
      move_uploaded_file($_FILES["file"]["tmp_name"],"uploads/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "uploads/" . $_FILES["file"]["name"];
    //  }
    }
  }
else
  {
  echo "<b>Error:</b> Invalid file";
  }
?>


<?




include "inc/footer2.dat";

?>