<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  $pagename = $_POST['save_pagename'];
  $preview_pagename = "inc/preview_".$pagename.".dat";
  $save_pagename = "inc/".$pagename.".dat";

  $open_previewpage = file_get_contents($preview_pagename);
  $f=file_put_contents($save_pagename, $open_previewpage); 


  include "inc/header_preview.dat";
  $pagename .= ".php";
  echo '


<div style="height:490px">
<h3>Save</h3>
<b>Your page has been saved.</b> 
<br/><br/>

Please click here to <a href="../'.$pagename.'" target="_blank">view live</a>.
<br/><br/>

<form name="editpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="" name="mode"/>
</form>
<br/>
<br/>Return to <a class="editlinks" onclick="adminform.submit()">Admin Centre</a> &nbsp; &nbsp; &nbsp; &nbsp; 
</div>
';

include "inc/footer2.dat";

?>