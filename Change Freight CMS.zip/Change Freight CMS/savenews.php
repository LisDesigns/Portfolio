<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  // write these files into 3 separate strings

  $open_previewpage1 = file_get_contents("inc/preview_newsbox1.dat");
  $f1=file_put_contents("inc/newsbox1.dat", $open_previewpage1); 

  $open_previewpage2 = file_get_contents("inc/preview_newsbox2.dat");
  $f2=file_put_contents("inc/newsbox2.dat", $open_previewpage2); 

  $open_previewpage3 = file_get_contents("inc/preview_newsbox3.dat");
  $f3=file_put_contents("inc/newsbox3.dat", $open_previewpage3); 

  include "inc/header_preview.dat";


echo '<div style="height:490px">
<h3>Save</h3>
<b>Your page has been saved.</b> 
<br/><br/>

Please click here to <a href="http://www.changefreight.com.au/" target="_blank">view live</a>.
<br/><br/>

<form name="editpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="" name="mode"/>
</form>
<br/>
<br/>Return to <a class="editlinks" onclick="adminform.submit()">Admin Centre</a> &nbsp; &nbsp; &nbsp; &nbsp; 
</div>
';

include "inc/footer2.dat";

?>


