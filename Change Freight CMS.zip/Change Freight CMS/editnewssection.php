<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  if ($_POST['mode'] == "preview") {
    $pagecontent1 = "inc/preview_newsbox1.dat";
    $pagecontent2 = "inc/preview_newsbox2.dat";
    $pagecontent3 = "inc/preview_newsbox3.dat";
  } else {
    $pagecontent1 = "inc/newsbox1.dat";
    $pagecontent2 = "inc/newsbox2.dat";
    $pagecontent3 = "inc/newsbox3.dat";
  }

  include "inc/header2.dat";
?>

<script type="text/javascript" src="scripts/wysiwyg.js"></script>
<script type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script type="text/javascript">
  WYSIWYG.attach('textarea3', news); 
  WYSIWYG.attach('textarea4', news); 
  WYSIWYG.attach('textarea5', news); 
</script>


<h3>Edit News Section</h3>
<form name="editnewssection" action="previewnews.php" method="post" enctype="multipart/form-data" style="display:inline;">
<input type="hidden" value="newssection" name="pagename"/>
<b>News Box 1</b>
<textarea id="textarea3" name="text3" style="width:250px;height:134px;display:inline;"  maxlength="175">
<?
  include $pagecontent1;
?>
</textarea>
<br/><b>News Box 2</b>
<textarea id="textarea4" name="text4" style="width:250px;height:134px;display:inline;"  maxlength="175">
<?
  include $pagecontent2;
?>
</textarea>
<br/><b>News Box 3</b>
<textarea id="textarea5" name="text5" style="width:250px;height:134px;display:inline;"  maxlength="175">
<?
  include $pagecontent3;
?>
</textarea>
<input type="hidden" value="editnewssection" name="continueeditingpage"/>
<img src="images/cancelchanges.jpg" onclick="editpage_cancelchanges.submit()" class="textlinks" align="left"  style="display:inline"/>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <input type="image" src="images/preview.jpg" value="Preview" style="display:inline"/>
</form>

<form name="editpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
</form>

<?

include "inc/footer2.dat";

?>