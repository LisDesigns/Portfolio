<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  if ($_POST['mode'] == "preview") {
    $pagecontent = "inc/preview_contactpage.dat";
  } else {
    $pagecontent = "inc/contactpage.dat";
  }

  include "inc/header2.dat";
?>



<script type="text/javascript" src="scripts/wysiwyg.js"></script>
<script type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script type="text/javascript">
  WYSIWYG.attach('textarea2', contact);
</script>


<h3>Edit Contact Page</h3>
<form name="editcontactpageform" action="preview.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="contactCFF" name="pagename"/>
<textarea id="textarea2" name="text2" style="width:303px;height:321px;">
<?
  include $pagecontent;
?>
</textarea>
<input type="hidden" value="editcontactpage" name="continueeditingpage" style="display:inline"/>
<img src="images/cancelchanges.jpg" onclick="editpage_cancelchanges.submit()" class="textlinks" align="left"  style="display:inline"/> &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp;  <input type="image" src="images/preview.jpg" value="Preview" style="display:inline"/>
</form>
<br/><br/>
<form name="editpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="" name="mode"/>
</form>

<?

include "inc/footer2.dat";

?>