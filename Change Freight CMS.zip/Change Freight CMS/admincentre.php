<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  include "inc/header.dat";

?>
<center>


<br/>

<div style="width:370px">
<h3>Admin Centre</h3>
<div style="display:block;width:370px;height:152px;padding-top:10px;background-image:url(images/editpagesbg.jpg)">
<br/><br/>
<form action="editpractisepage.php" method="post" style="display:inline;" name="practiseform">
<input type="hidden" value="" name="mode"/>
<input type="image" src="images/practiseicon.jpg" name="practise" value="Edit Practise Page" border="0" style="display:inline"/>
</form> &nbsp; &nbsp;
<form action="edithomepage.php" method="post" style="display:inline;" name="homeform">
<input type="hidden" value="" name="mode"/>
<input type="image" src="images/homeicon.jpg" name="home" value="Edit Home Page"  border="0"/>
</form> &nbsp; &nbsp;
<form action="editnewssection.php" method="post" style="display:inline;" name="newsform">
<input type="hidden" value="" name="mode"/>
<input type="image" src="images/newsicon.jpg" name="news" value="Edit News Section"  border="0"/>
</form> &nbsp; &nbsp;
<form action="editcontactpage.php" method="post" style="display:inline;" name="editform">
<input type="hidden" value="" name="mode"/>
<input type="image" src="images/contacticon.jpg" name="contact" value="Edit Contact Page"  border="0"/>
</form>
<br/><a class="textlinks" onclick="practiseform.submit()">Practise</a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="textlinks" onclick="homeform.submit()">Home</span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span class="textlinks" onclick="newsform.submit()">News</span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="textlinks" onclick="contactform.submit()">Contact</span>
</div>
<br/>
<br/><br/>
<div style="display:block;text-align:center;width:367px!important;height:148px;padding-top:10px;padding-bottom:4px;background-image:url(images/uploadimagesbg.jpg)">
<br/><br/>
<form name="uploadImages" action="upload.php" method="post" enctype="multipart/form-data" style="display:block; margin-left:30px;">
<br/>
<div style="width:250px;text-align:left">Select Image</div>
<br/><input type="file" name="file" id="file" style="width:250px" onchange="uploadImages.submit()"/> 
</form>
</div>

</div>
<?

include "inc/footer.dat";

?>