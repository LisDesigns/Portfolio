/********************************************************************
 * openWYSIWYG settings file Copyright (c) 2006 openWebWare.com
 * Contact us at devs@openwebware.com
 * This copyright notice MUST stay intact for use.
 *
 * $Id: wysiwyg-settings.js,v 1.4 2007/01/22 23:05:57 xhaggi Exp $
 ********************************************************************/

/*
 * Full featured setup used the openImageLibrary addon
 */
var full = new WYSIWYG.Settings();
//full.ImagesDir = "images/";
//full.PopupsDir = "popups/";
//full.CSSFile = "styles/wysiwyg.css";
full.Width = "85%"; 
full.Height = "250px";
// customize toolbar buttons
full.addToolbarElement("font", 3, 1); 
full.addToolbarElement("fontsize", 3, 2);
full.addToolbarElement("headings", 3, 3);
// openImageLibrary addon implementation
full.ImagePopupFile = "addons/imagelibrary/insert_image.php";
full.ImagePopupWidth = 600;
full.ImagePopupHeight = 245;

/*
 * Practise Page
 */
var practise = new WYSIWYG.Settings();
practise.Width = "392px";
practise.Height = "300px";
practise.DefaultStyle = "font-family: Arial; font-size: 12px; background-color: #FFFFFF";
practise.Toolbar[0] = new Array(                        
			"bold", 
			"italic", 
			"underline", 
			"strikethrough",
			"seperator", 
			"forecolor", 
			"backcolor", 
			"seperator",
			"justifyfull", 
			"justifyleft", 
			"justifycenter", 
			"justifyright", 
			"seperator", 
			"unorderedlist", 
			"orderedlist",
			"outdent", 
			"indent");
practise.Toolbar[1] = new Array(
			"cut", 
			"copy", 
			"paste",
			"removeformat",
			"seperator", 
			"undo", 
			"redo", 
			"seperator", 
			"inserttable", 
			"insertimage", 
			"createlink", 
			"seperator",  
			"print",
			"viewSource",
			"maximize",
			"seperator", 
                        "subscript", 
			"superscript");
practise.Toolbar[2] = new Array(
                        "font",
	                "fontsize",
                        "headings",
                        "help");
practise.StatusBarEnabled = false;
// openImageLibrary addon implementation
practise.ImagePopupFile = "addons/imagelibrary/insert_image.php";
practise.ImagePopupWidth = 600;
practise.ImagePopupHeight = 245;

/*
 * Home Page Introduction
 */
var home = new WYSIWYG.Settings();
home.Width = "392px";
home.Height = "374px";
home.DefaultStyle = "font-family: Arial; font-size: 12px; background-color: #FFFFFF";
home.Toolbar[0] = new Array(                        
			"bold", 
			"italic", 
			"underline", 
			"strikethrough",
			"seperator", 
			"forecolor", 
			"backcolor", 
			"seperator",
			"justifyfull", 
			"justifyleft", 
			"justifycenter", 
			"justifyright", 
			"seperator", 
			"unorderedlist", 
			"orderedlist",
			"outdent", 
			"indent");
home.Toolbar[1] = new Array(
			"cut", 
			"copy", 
			"paste",
			"removeformat",
			"seperator", 
			"undo", 
			"redo", 
			"seperator", 
			"inserttable", 
			"insertimage", 
			"createlink", 
			"seperator",  
			"print",
			"viewSource",
			"maximize",
			"seperator", 
                        "subscript", 
			"superscript");
home.Toolbar[2] = new Array(
                        "font",
	                "fontsize",
                        "headings",
                        "help");	
home.StatusBarEnabled = false;
// openImageLibrary addon implementation
home.ImagePopupFile = "addons/imagelibrary/insert_image.php";
home.ImagePopupWidth = 600;
home.ImagePopupHeight = 245;


/*
 * News Section
 */
var news = new WYSIWYG.Settings();
news.Width = "250px";
news.Height = "134px";
news.DefaultStyle = "font-family: Arial; font-size: 12px; background-color: #FFFFFF";
news.Toolbar[0] = new Array("fontsize", "bold", "italic", "underline","createlink");
news.Toolbar[1] = ""; // disable toolbar 2
news.StatusBarEnabled = false;

/*
 * Contact Page
 */
var contact = new WYSIWYG.Settings();
contact.Width = "303px";
contact.Height = "321px";
contact.DefaultStyle = "font-family: Arial; font-size: 12px; background-color: #FFFFFF";
contact.Toolbar[0] = new Array(                        
			"bold", 
			"italic", 
			"underline", 
			"strikethrough",
			"seperator", 
			"forecolor", 
			"backcolor", 
			"seperator",
			"justifyfull", 
			"justifyleft", 
			"justifycenter", 
			"justifyright", 
			"seperator", 
			"unorderedlist", 
			"orderedlist",
			"outdent", 
			"indent");
contact.Toolbar[1] = new Array(
			"cut", 
			"copy", 
			"paste",
			"removeformat",
			"seperator", 
			"undo", 
			"redo", 
			"seperator", 
			"inserttable", 
			"insertimage", 
			"createlink", 
			"seperator",  
			"print",
			"viewSource",
			"maximize",
			"seperator", 
                        "subscript", 
			"superscript");
contact.Toolbar[2] = new Array(
                        "font",
	                "fontsize",
                        "headings",
                        "help");
contact.StatusBarEnabled = false;
// openImageLibrary addon implementation
contact.ImagePopupFile = "addons/imagelibrary/insert_image.php";
contact.ImagePopupWidth = 600;
contact.ImagePopupHeight = 245;



