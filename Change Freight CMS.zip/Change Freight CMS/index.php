<?

include "inc/header1.dat";

?>

<div style="text-align:left; width:200px;">

<br/><br/><br/><br/><br/>
<img src="images/CFFlogo3.jpg"/>
<br/><br/>
<?php

echo $errorMessage;

 ?>
<div style="width:205px;margin-right:0px;border:1px none rgb(200,200,200); text-align:left">
<form action="login.php" method="post" style="display:inline">
Username:
<br/><input type="text" name="username" style="width:202px"/>
<br/> 
Password:
<br/><input type="password" name="password" style="width:202px"/>
<p align="right"/><input type="submit" name="submit" value="LOGIN" class="cmsbuttons" align="right" style="background-color:black;#53b848;333991; font-weight:bold;font-size:10px;font-family:verdana;color:white;padding:2px;width:60px;"/>
</form>
</div>
</div>



<?

include "inc/footer1.dat";

?>








