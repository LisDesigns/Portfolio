<?php 

  session_start();

  $user = "hubert";
  $pass = "mypass";

  if (($_SESSION["user"] != $user) || ($_SESSION["pass"] != $pass)) {
    header( "Location: http://www.changefreight.com.au/cms/" );
  }

  include "inc/header_preview.dat";

?>

<h3>Preview Page</h3>
<form name="previewpage" action="save.php" method="post" enctype="multipart/form-data" style="display:inline">

<?

  $pagename = $_POST['pagename'];
  $text2 = $_POST['text2'];
  $str = preg_replace('/\\\"/', '"', $text2);
  $preview_pagename = "inc/preview_".$pagename.'.dat';
  echo '<div style="width:500px;height:390px">'.$str.'</div>';
  //echo "<br/><br/>$preview_pagename";
  $openpage = fopen("$preview_pagename", "w");
  fwrite($openpage, $str);
  fclose($openpage);
  echo "<input name='save_pagename' type='hidden' value='$pagename'/>";
  $continueeditingpage = $_POST["continueeditingpage"];
  $continueeditingpage = $continueeditingpage.".php"; 
?>


<br/><br/><br/>
<img src="images/cancelchanges.jpg" onclick="previewpage_cancelchanges.submit()"/> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 

<input type="image" src="images/save.jpg" value="Save"/> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
</form>

<form name="previewpage_cancelchanges" action="admincentre.php" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="" name="mode"/>
</form>

<form name="previwpage_cancelchanges" action="<? echo $continueeditingpage; ?>" method="post" enctype="multipart/form-data" style="display:inline">
<input type="hidden" value="preview" name="mode"/>
<input type="image" src="images/continueediting.jpg" onclick="previewpage_cancelchanges.submit()"/>
</form>

 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="<? echo "..//test_".$pagename.'.php'; ?>" target="_blank"><img src="images/previewlive.jpg" border="0"></a>

<?

include "inc/footer2.dat";

?>



