
<?php
  $open_page1 = file_get_contents("cms/inc/newsbox1.dat");
  $open_page2 = file_get_contents("cms/inc/newsbox2.dat");
  $open_page3 = file_get_contents("cms/inc/newsbox3.dat");

function mynl2br($text) { 
   return strtr($text, array("\r\n" => '<br />', "\r" => '<br />', "\n" => '<br />')); 
} 

  $open_page1 = mynl2br($open_page1);
  $open_page2 = mynl2br($open_page2);
  $open_page3 = mynl2br($open_page3);
?>
<html>
<head>
<style type="text/css">
a{color:#397bc5;}
.boxes{color:#397bc5; font-family:arial; font-size:12px; padding:4px; border-style:none; left:0px; position:absolute;}
    body{
scrollbar-face-color: rgb(250,250,252);#ecf4fe;#c8e0fc;#300; 
scrollbar-shadow-color: rgb(250,250,252);#ecf4fe;white; 
scrollbar-highlight-color: rgb(250,250,252);#ecf4fe;white; 
scrollbar-3dlight-color: rgb(250,250,252);#ecf4fe;white; 
scrollbar-darkshadow-color: rgb(250,250,252);#ecf4fe;white; 
scrollbar-track-color: rgb(250,250,252);#ecf4fe;#c8e0fc;#300; 
scrollbar-arrow-color: #a7c6e8;#397bc5;blue;white; 
   }

</style>
</head>
<body>
<div id="news">

<div id="box1" class="boxes" style="width:222px; height:89px;overflow:hidden; border-style:none;border-color:rgb(45,45,245);border-width:1px; top:-30px;"></div>
<div id="box2" class="boxes" style="width:222px; height:89px;overflow:hidden; border-style:none;border-color:rgb(45,245,45);border-width:1px; top:-30px;"></div>
<div id="box3" class="boxes" style="width:222px; height:89px;overflow:hidden; border-style:none;border-color:rgb(245,45,45);border-width:1px; top:-30px;"></div>

<script language="JavaScript1.2">

  info1 = 'echo open_page1';
  info2 = 'echo open_page2';
  info3 = 'echo open_page3';

  info1 = '<?php echo $open_page1 ?>';


  info2 = '<?php echo $open_page2 ?>';

  info3 = '<?php
  echo $open_page3;

?>';


  b1 = document.getElementById("box1");
  b2 = document.getElementById("box2");
  b3 = document.getElementById("box3");

  b1.innerHTML = info1;
  b2.innerHTML = info2;
  b3.innerHTML = info3;

  i1 = 0;
  x1 = -240;
  s1 = 30;
  c = 0;

  i2 = 100;
  x2 = -240;
  s2 = 30;

  i3 = 200;
  x3 = -240;
  s3 = 30;

  function moveUp1() {
    if ((i1 > x1) && (c <=6)){
      i1 -= 1;
      s1 += 200;
      if (i1 == -100){
  	i1 = 200;
  	moveUp1();
      }
      document.getElementById("box1").style.top=i1;
      t1 = self.setInterval("moveUp1()",s1);
   }
  }

  function moveUp2() {
    if ((i2 > x2) && (c <=6)){
      i2 -= 1;
      s2 += 200;
      if (i2 == -100) {
  	i2 = 200;
  	moveUp2();
      }
      document.getElementById("box2").style.top=i2;
      t2 = self.setInterval("moveUp2()",s2);
   }
  }

  function moveUp3() {
    if ((i3 > x3) && (c <=6)){
      if (i3 == -100) {
 	i3 = 200;
  	moveUp3();
        c++;
      }
      i3 -= 1;
      s3 += 200;
      document.getElementById("box3").style.top=i3;
      t3 = self.setInterval("moveUp3()",s3);
   }
  }
  
  moveUp1();
  moveUp2();
  moveUp3();

</script>

</body>
</html>