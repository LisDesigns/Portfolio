<?php

  $user = "hubert";
  $pass = "mypass";

  $username = $_POST["username"];
  $password = $_POST["password"];

  if (($user == $username) && ($pass == $password)) {
    session_start();
    $_SESSION["user"] = $user;
    $_SESSION["pass"] = $pass;
    include "admincentre.php";   
  } else {
    $errorMessage = "<b>Error: your username and/or password did not match.</b><br/><br/>";
    include "index.php";
  }

?>