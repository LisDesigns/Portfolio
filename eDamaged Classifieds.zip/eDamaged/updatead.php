<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }

//*******Get Values*******
$advertid=$_POST["advertid"];
$itemname=$_POST["itemname"];
$transmission=$_POST["transmission"];
$category=$_POST["category"];
$airconditioning=$_POST["airconditioning"];
$make=$_POST["make"];
$newused=$_POST["newused"];
$model=$_POST["model"];
$vehicledescription=$_POST["vehicledescription"];
$price=$_POST["price"];
$year=$_POST["year"];
$damage=$_POST["damage"];
$colour=$_POST["colour"];
$damagedescription=$_POST["damagedescription"];
$kilometres=$_POST["kilometres"];
$type=$_POST["type"];
$file1=$_POST["file1"];
$file2=$_POST["file2"];
$file3=$_POST["file3"];
$file4=$_POST["file4"];
$file5=$_POST["file5"];
$file6=$_POST["file6"];
$remove1=$_POST["remove1"];
$remove2=$_POST["remove2"];
$remove3=$_POST["remove3"];
$remove4=$_POST["remove4"];
$remove5=$_POST["remove5"];
$remove6=$_POST["remove6"];
$vehiclefeature1=$_POST["vehiclefeature1"];
$vehiclefeature2=$_POST["vehiclefeature2"];
$vehiclefeature3=$_POST["vehiclefeature3"];
$vehiclefeature4=$_POST["vehiclefeature4"];
$vehiclefeature5=$_POST["vehiclefeature5"];
$vehiclefeature6=$_POST["vehiclefeature6"];
$vehiclefeature7=$_POST["vehiclefeature7"];
$vehiclefeature8=$_POST["vehiclefeature8"];
$vehiclefeature9=$_POST["vehiclefeature9"];
$vehiclefeature10=$_POST["vehiclefeature10"];

//*******Submit to Database*******

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

mysql_query("UPDATE `adverts` SET `itemName` = '$itemname',`category`='$category',`make`='$make',`model`='$model',`price`='$price',`year`='$year',`colour`='$colour',`kilometres`='$kilometres',`transmission`='$transmission',`airConditioning`='$airconditioning',`newUsed`='$newused',`vehicleDescription`='$vehicledescription',`typeOfDamage`='$damage', `damageDescription`='$damagedescription', `type`='$type' WHERE advertsId = ".$advertid);

mysql_query("UPDATE `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('1', '$advertsId', '$vehiclefeature1')");

mysql_query("UPDATE `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('2', '$advertsId', '$vehiclefeature2')");

mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature1' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 1");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature2' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 2");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature3' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 3");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature4' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 4");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature5' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 5");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature6' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 6");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature7' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 7");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature8' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 8");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature9' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 9");
mysql_query("UPDATE vehicleFeatures SET vehicleFeature = '$vehiclefeature10' WHERE advertsId=".$advertid." AND vehiclesFeaturesId = 10");

mysql_close($connection);
$error ="";

if ((strlen($file1) == 0) && (strlen($remove1) == 6)) {
if (file_exists("uploads/adid".$advertid.img1.".jpg")) { 
  unlink("uploads/adid".$advertid.img1.".jpg");
}
}

if ((strlen($file2) == 0) && (strlen($remove2) == 6)) {
if (file_exists("uploads/adid".$advertid.img2.".jpg")) { 
  unlink("uploads/adid".$advertid.img2.".jpg");
}
}

if ((strlen($file3) == 0) && (strlen($remove3) == 6)) {
if (file_exists("uploads/adid".$advertid.img3.".jpg")) { 
  unlink("uploads/adid".$advertid.img3.".jpg");
}
}

if ((strlen($file4) == 0) && (strlen($remove4) == 6)) {
if (file_exists("uploads/adid".$advertid.img4.".jpg")) { 
  unlink("uploads/adid".$advertid.img4.".jpg");
}}

if ((strlen($file5) == 0) && (strlen($remove5) == 6)) {
if (file_exists("uploads/adid".$advertid.img5.".jpg")) { 
  unlink("uploads/adid".$advertid.img5.".jpg");
}}

if ((strlen($file6) == 0) && (strlen($remove6) == 6)) {
if (file_exists("uploads/adid".$advertid.img6.".jpg")) { 
  unlink("uploads/adid".$advertid.img6.".jpg");
}}

$file1 = "uploads/adid".$advertid.img1.".jpg";
$file2 = "uploads/adid".$advertid.img2.".jpg";
$file3 = "uploads/adid".$advertid.img3.".jpg";
$file4 = "uploads/adid".$advertid.img4.".jpg";
$file5 = "uploads/adid".$advertid.img5.".jpg";
$file6 = "uploads/adid".$advertid.img6.".jpg";

if (strlen($_FILES["file2"]["name"]) > 0) {
if (file_exists($file2)) { 
  unlink($file2);
}
if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg")|| ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {
  if ($_FILES["file1"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file1"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file1"]["tmp_name"],"uploads/adid".$advertid."img1.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}



if (strlen($_FILES["file2"]["name"]) > 0) {
if (file_exists($file2)) { 
  unlink($file2);
}
if ((($_FILES["file2"]["type"] == "image/gif") || ($_FILES["file2"]["type"] == "image/jpeg")|| ($_FILES["file2"]["type"] == "image/pjpeg")) && ($_FILES["file2"]["size"] < 200000000000)) {
  if ($_FILES["file2"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file2"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file2"]["tmp_name"],"uploads/adid".$advertid."img2.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
} 

if (strlen($_FILES["file3"]["name"]) > 0) {
if (file_exists($file3)) { 
  unlink($file3);
}
if ((($_FILES["file3"]["type"] == "image/gif") || ($_FILES["file3"]["type"] == "image/jpeg")|| ($_FILES["file3"]["type"] == "image/pjpeg")) && ($_FILES["file3"]["size"] < 200000000000)) {
  if ($_FILES["file3"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file3"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file3"]["tmp_name"],"uploads/adid".$advertid."img3.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
} 

if (strlen($_FILES["file4"]["name"]) > 0) {
if (file_exists($file4)) { 
  unlink($file4);
}
if ((($_FILES["file4"]["type"] == "image/gif") || ($_FILES["file4"]["type"] == "image/jpeg")|| ($_FILES["file4"]["type"] == "image/pjpeg")) && ($_FILES["file4"]["size"] < 200000000000)) {
  if ($_FILES["file4"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file4"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file4"]["tmp_name"],"uploads/adid".$advertid."img4.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file5"]["name"]) > 0) {
if (file_exists($file5)) { 
  unlink($file5);
}
if ((($_FILES["file5"]["type"] == "image/gif") || ($_FILES["file5"]["type"] == "image/jpeg")|| ($_FILES["file5"]["type"] == "image/pjpeg")) && ($_FILES["file5"]["size"] < 200000000000)) {
  if ($_FILES["file5"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file5"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file5"]["tmp_name"],"uploads/adid".$advertid."img5.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file6"]["name"]) > 0) {
if (file_exists($file6)) { 
  unlink($file6);
}
if ((($_FILES["file6"]["type"] == "image/gif") || ($_FILES["file6"]["type"] == "image/jpeg")|| ($_FILES["file6"]["type"] == "image/pjpeg")) && ($_FILES["file6"]["size"] < 200000000000)) {
  if ($_FILES["file6"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file6"]["error"] . "<br />";
  } else {
    move_uploaded_file($_FILES["file6"]["tmp_name"],"uploads/adid".$advertid."img6.jpg");
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}


if (strlen($error) > 0) {
  $subtitle ="Error";
  $message = $error;
} else {
  $subtitle ="Thank you";
  $message ="Your ad has been updated.";
}

include "blank.php";

?>