<?
   session_start();
   include "header.php";
   $pagenum = $_GET["page"];
   if ($pagenum == "") {
     $pagenum = 1;
   }
?>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box7.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Jetski Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="jet skis" name="category"/>
        <table>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option><option>Damaged</option></select></td></tr>
        <tr><td><b>Damage</b>:</td><td><select name="damage"><option>Any</option><option>Hail</option><option>Fire</option><option>Water</option><option>Exterior</option><option>Interior</option><option>Mechanical</option><option>Other</option></select></td></tr>
        <tr><td><b>Location</b>:</td><td><select name="location"><option>Any</option><option>NSW</option><option>ACT</option><option>QLD</option><option>VIC</option><option>TAS</option><option>WA</option><option>NT</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearch.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search"  class="box7buttons"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box7.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postad.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>

    </div>

  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
      <div style="height:170px;width:500px;display:block;overflow:hidden;<? if($pagenum > 1){ echo "display:none";} ?>">
      <a href="#"><img src="photos/jetskis.JPG" alt="" align="left" border="0" style="padding-right:;10px;width:260px"/></a>
     

      <h1 style="display:inline;padding-left:10px">Welcome to eDamaged</h1>
      <br/>
   
      <p style="width:260px;padding-left:10px;display:inline-block">Thankyou for visiting. We are currently developing our website. Please come back soon. <br/><br/><br/><br/><br/><br/><br/><br/>
      </p>
      </div>
<br/><b>Browse Latest Jet Skis</b><br/><br/>
<?php

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

$query  = "SELECT * FROM adverts WHERE category = 'Jet Skis' ORDER BY advertsId DESC";
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
$num_rows = mysql_num_rows($result);
 

$i=0;
       while($row = mysql_fetch_assoc($result)) {
         $i++;
         if ($pagenum == 1) {
if (($i>=0) && ($i<5)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
             if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
             } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
             }
              echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }


         if ($pagenum == 2) {
if (($i>=5) && ($i<11)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 3) {
if (($i>=11) && ($i<17)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 4) {
if (($i>=17) && ($i<23)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 5) {
if (($i>=23) && ($i<29)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 6) {
if (($i>=29) && ($i<35)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 7) {
if (($i>=35) && ($i<41)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 8) {
if (($i>=41) && ($i<47)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 9) {
if (($i>=47) && ($i<53)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }


         if ($pagenum == 10) {
if (($i>=53) && ($i<62)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }
       }

       if ($i>0) {
         $pages = '<br/>Page <a href="jetskis.php?page=1">1</a> ';
       }
       if ($i>4) {
         $pages .= ' <a href="jetskis.php?page=2">2</a> ';
       }
       if ($i>10) {
         $pages .= ' <a href="jetskis.php?page=3">3</a> ';
       }
       if ($i>16) {
         $pages .= ' <a href="jetskis.php?page=4">4</a> ';
       }
       if ($i>22) {
         $pages .= ' <a href="jetskis.php?page=5">5</a> ';
       }
       if ($i>28) {
         $pages .= ' <a href="jetskis.php?page=6">6</a> ';
       }
       if ($i>34) {
         $pages .= ' <a href="jetskis.php?page=7">7</a> ';
       }
       if ($i>40) {
         $pages .= ' <a href="jetskis.php?page=8">8</a> ';
       }
       if ($i>46) {
         $pages .= ' <a href="jetskis.php?page=9">9</a> ';
       }
       if ($i>52) {
         $pages .= ' <a href="jetskis.php?page=10">10</a> ';
       }

       echo $pages;

       mysql_close($connection);

      ?>
    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:290px"></td>
  <td id="rightbg1" style="height:290px"></td>
</tr>
</tr>
<?
include "footer.php";
?>