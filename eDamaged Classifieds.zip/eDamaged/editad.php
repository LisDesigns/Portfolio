<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];

   //if (!$_SESSION["user"]) {
     //header("location:login.php");
   //}

$advertid = $_GET['id'];

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());
$query = "SELECT category FROM `adverts` WHERE advertsId=".$advertid;
$result = mysql_query($query);
$result1 = $result;

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

$i=0;
while($row = mysql_fetch_assoc($result)) {
  $category=$row['category'];
}

if (strtolower($category) == "cars") {
  include "editadcars.php";
} else if (strtolower($category) == "trucks") {
  include "editadtrucks.php";
} else if (strtolower($category) == "bikes") {
  include "editadbikes.php";
} else if (strtolower($category) == "caravans") {
  include "editadcaravans.php";
} else if (strtolower($category) == "classic") {
  include "editadclassic.php";
} else if (strtolower($category) == "parts") {
  include "editadparts.php";
} else if (strtolower($category) == "tools") {
  include "editadtools.php";
} else  {
  include "editad.php";
} 

?>