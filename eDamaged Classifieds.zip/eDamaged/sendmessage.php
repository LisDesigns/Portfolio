<?php 

$sellerid = $_POST["sellerid"];
$itemname = $_POST["itemname"];
$subject = 'eDamaged Item Enquiry';
$firstname = $_POST["firstname"];
$email = $_POST["email"];

$message = "\n\r"."Item Name: ".$_POST["itemname"]."\n\r";
$message .= "Message: ".$_POST["message"]."\n\r";
$message .= "From: ".$firstname."\n\r";
$message .= "Email: ".$email."\n\r";

if ($sellerid == 13) {
$subject = 'eDamaged Enquiry';
$message = "Message: ".$_POST["message"]."\n\r";
$message .= "From: ".$firstname."\n\r";
$message .= "Email: ".$email."\n\r";
}

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());
    
$query  = "SELECT email FROM registration WHERE registrationId = '.$sellerid.'";
$result = mysql_query($query);

while($row = mysql_fetch_assoc($result))
{
$sendtoemail = $row['email'];
}


$to      = $sendtoemail;
//$to      = 'lisa@lisdesigns.com.au';

$headers = 'From: '.$email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();




mail($to, $subject, $message, $headers);

  $subtitle ="Thank you";
  $message ="Your message has been sent.";


include "blank.php";


?>