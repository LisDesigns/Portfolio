
  // Onload:
  function init_form() {
   // document.getElementById("submitDiv").innerHTML = "<input type='button' value='Submit' onclick='validateForm()' />";
  }
  //init_form();

  // Declare variables
  var firstName, lastName, emailAddress, comments;
  var errorMessage, englishPattern, emailPattern;
  var engStr, emaStr;
  firstName = "";
  lastName = "";
  emailAddress = "";
  comments = "";
  ErrorMessage = "";
  engStr = " ";
  emaStr = " ";
  englishPattern = new RegExp(/\<|\>/gi);

  // Get and retieve values
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
  } 

  function checkEnglish(englishStr) {
    // remove <> characters
    englishPattern = new RegExp(/\<|\>/gi);
    engStr = englishStr.replace(englishPattern, " ");
    return engStr;
  }  

  function getFieldValues() {
    // Get field values.
    Username = register.elements[0].value;
    Password = register.elements[1].value;
    FirstName = register.elements[2].value;
    LastName = register.elements[3].value;
    Company = register.elements[4].value;
    Address = register.elements[5].value;
    Suburb = register.elements[6].value;
    State = register.elements[7].value;
    PostCode = register.elements[8].value;
    PhoneNumber = register.elements[9].value;
    Mobile = register.elements[10].value;
    Email = register.elements[11].value;

    // Trim fields
    Username = Username.trim();
    Password = Password.trim();
    FirstName = FirstName.trim();
    LastName = LastName.trim();
    Company = Company.trim();
    Address = Address.trim();
    Suburb = Suburb.trim();
    //State = State.trim();
    PostCode = PostCode.trim();
    PhoneNumber = PhoneNumber.trim();
    Mobile = Mobile.trim();
    Email = Email.trim();

    // Remove unsafe characters
    Username = checkEnglish(Username);
    Password = checkEnglish(Password);
    FirstName = checkEnglish(FirstName);
    LastName = checkEnglish(LastName);
    Company = checkEnglish(Company);
    Address = checkEnglish(Address);
    Suburb = checkEnglish(Suburb);
    //State = checkEnglish(State);
    PostCode = checkEnglish(PostCode);
    PhoneNumber = checkEnglish(PhoneNumber);
    Mobile = checkEnglish(Mobile);
    Email = checkEnglish(Email);

    register.elements[0].value = Username;
    register.elements[1].value = Password;
    register.elements[2].value = FirstName;
    register.elements[3].value = LastName;
    register.elements[4].value = Company;
    register.elements[5].value = Address;
    register.elements[6].value = Suburb;
    register.elements[7].value = State;
    register.elements[8].value = PostCode;
    register.elements[9].value = PhoneNumber;
    register.elements[10].value = Mobile;
    register.elements[11].value = Email;

  }

  function validateEmail(emailStr) {
    emailPattern = new RegExp(/^\S+@\S+\.\S+$/gi);

    return emailPattern.test(emailStr);   // true or false will be returned 
  }

  function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    return digitPattern.test(digitStr);   // true or false will be returned 
  }

function checkValues() {

n = 0;
getFieldValues();
if ((Username.length == 0) || 
    (Password.length == 0) || 
    (FirstName.length == 0) || 
    (LastName.length == 0) || 
    (Address.length == 0) || 
    (Suburb.length == 0) || 
    (State.value == "Please select") || 
    (PostCode.length == 0) || 
    (PhoneNumber.length == 0) || 
    (Email.length == 0)) {

    ErrorMessage = "Please enter a value for all fields marked with an asterisk(*).";

    n = 1;
} else if (checkUsername(Username)) {
    n = 2;
    ErrorMessage = "Error: that username already exists. Please try a different one.";
} else {
   if (!(validateEmail(Email))) {
    n = 3;
    ErrorMessage = "Please enter a valid email address.";
   }

}

if (n == 0) {
   register.submit();
} else {
   alert(ErrorMessage);
}


}

function checkDigits(item) {
    testnum = register.elements[item].value;
    if (!validateDigits(testnum)) {
      ErrorMessage = "Please enter only numbers in the post code, phone and mobile fields.";
      alert(ErrorMessage);
      return register.elements[item].value="";
    }
}




