<?php

//**********Get Values************

   $Title = $_REQUEST['title'];
   $FirstName = $_REQUEST['firstname'];
   $LastName = $_REQUEST['lastname'];
   $Company = $_REQUEST['company'];
   $Position = $_REQUEST['position'];
   $Address = $_REQUEST['address'];
   $Suburb = $_REQUEST['suburb'];
   $State = $_REQUEST['state'];
   $PostCode = $_REQUEST['postcode'];
   $Country = $_REQUEST['country'];
   $PhoneCode = $_REQUEST['phone_code'];
   $PhoneNumber = $_REQUEST['phone'];
   $Mobile = $_REQUEST['mobile'];
   $FaxCode = $_REQUEST['fax_code'];
   $FaxNumber = $_REQUEST['fax'];
   $Email = $_REQUEST['email'];
   $PreferredContactMethod = $_REQUEST['contact'];
   $Comments = $_REQUEST['comments']; 

   function getCheckedValue($PreferredContactMethod,$Choice) {
     if ($Choice == $PreferredContactMethod){
       echo "checked";
     }
   }

   // Declare Variables
   $errorMessage = "";
   $str = "";

//********Create Methods***********

  function removeUnsafeChars($str) {
    $str = preg_replace('/\x3C|\x3E/', ' ', $str);
    return $str;
  }

  function trimValues($str) {
    $str = preg_replace('/^\s+|\s+$/', '', $str);
    return $str;
  }

  function validateEmail($str) {
    $str = preg_replace('/^\S+\x40\S+\.\S+$/', '', $str);  
    // If email is valid, false will be returned.
    if (strlen($str) == 0) {
      return false;
    } else {
      return true;
    }
  }

  function checkDigits($str) {

    // Remove spaces.
    $str = preg_replace('/\s/', '', $str);
    // Check for non-digits:
    $str = preg_replace('/\d/', '', $str);

    if (strlen($str) > 0) {
      return true;
    } else {
      return false;
    }
  }

//*********Format Values***********

   $Title = removeUnsafeChars($Title);
   $FirstName = removeUnsafeChars($FirstName);
   $LastName = removeUnsafeChars($LastName);
   $Company = removeUnsafeChars($Company);
   $Position = removeUnsafeChars($Position);
   $Address = removeUnsafeChars($Address);
   $Suburb = removeUnsafeChars($Suburb);
   $State = removeUnsafeChars($State);
   $PostCode = removeUnsafeChars($PostCode);
   $Country = removeUnsafeChars($Country);
   $PhoneCode = removeUnsafeChars($PhoneCode);
   $PhoneNumber = removeUnsafeChars($PhoneNumber);
   $Mobile = removeUnsafeChars($Mobile);
   $FaxCode = removeUnsafeChars($FaxCode);
   $FaxNumber = removeUnsafeChars($FaxNumber);
   $Email = removeUnsafeChars($Email);
   $PreferredContactMethod = removeUnsafeChars($PreferredContactMethod);
   $Comments = removeUnsafeChars($Comments);

   $Title = trimValues($Title);
   $FirstName = trimValues($FirstName);
   $LastName = trimValues($LastName);
   $Company = trimValues($Company);
   $Position = trimValues($Position);
   $Address = trimValues($Address);
   $Suburb = trimValues($Suburb);
   $State = trimValues($State);
   $PostCode = trimValues($PostCode);
   $Country = trimValues($Country);
   $PhoneCode = trimValues($PhoneCode);
   $PhoneNumber = trimValues($PhoneNumber);
   $Mobile = trimValues($Mobile);
   $FaxCode = trimValues($FaxCode);
   $FaxNumber = trimValues($FaxNumber);
   $Email = trimValues($Email);
   $PreferredContactMethod = trimValues($PreferredContactMethod);
   $Comments = trimValues($Comments);

   $ValidateEmail = validateEmail($Email);
   $ValidatePhoneCode = checkDigits($PhoneCode);
   $ValidatePhoneNumber = checkDigits($PhoneNumber);
   $ValidateMobile = checkDigits($Mobile);
   $ValidateFaxCode = checkDigits($FaxCode);
   $ValidateFaxNumber = checkDigits($FaxNumber);

   $Fax = "(".$FaxCode.") ".$FaxNumber;
   $Phone = "(".$PhoneCode.") ".$PhoneNumber;

   $Title_slashed = addslashes($Title);
   $FirstName_slashed = addslashes($FirstName);
   $LastName_slashed = addslashes($LastName);
   $Company_slashed = addslashes($Company);
   $Position_slashed = addslashes($Position);
   $Address_slashed = addslashes($Address);
   $Suburb_slashed = addslashes($Suburb);
   $State_slashed = addslashes($State);
   $Country_slashed = addslashes($Country);
   $Email_slashed = addslashes($Email);
   $Comments_slashed = addslashes($Comments);

//********Validate Values***********

   if (empty($Title) || empty($FirstName) || empty($LastName) || empty($Address) || 
       empty($Suburb) || empty($State) || empty($PostCode) || empty($Country) || 
       empty($PhoneNumber) || empty($Email)) {
         $errorMessage .= " &#45; Please enter all fields marked with an asterisk(*).<br/>";
   } 

   if ($ValidateEmail) {
     $errorMessage .= " &#45; Please enter a valid email address.<br/>";
   } 

   if (($ValidatePhoneCode && (strlen($ValidatePhoneCode) > 0)) || 
   ($ValidatePhoneNumber && (strlen($ValidatePhoneNumber) > 0)) ||
   ($ValidateMobile && (strlen($ValidateMobile) >0)) ||
   ($ValidateFaxCode && (strlen($ValidateFaxCode) > 0)) || 
   ($ValidateFaxNumber && (strlen($ValidateFaxNumber) > 0)) ||
   ($ValidatePostCode && (strlen($ValidatePostCode) > 0))){
     $errorMessage .= " &#45; Please enter only numbers in the phone, mobile, fax and post code fields.<br/>";
   } 

   if ($errorMessage != "") {
     include "blankpage.php";
   } else {

   //echo $errorMessage;

   // if valid - proceed
   // if not valid, rewrite page, by using include.

//*******Submit to Database*******

  // Connect to database
  $username = "chang";
  $password = "$#@(33)fro";
  $databaseName = "chang_db";
  $connection = mysql_connect("mysql4.ilisys.com.au",$username,$password);
  if (!$connection) {
    die('Could not connect: ' . mysql_error());
  }
  mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());
  // Insert new account (row) into the RegistrationDatabase.
  mysql_query("INSERT INTO REGISTRATIONS (Title, FirstName, LastName, Company, Position, Address, Suburb, State, PostCode, Country, PhoneCode, PhoneNumber, Mobile, FaxCode, FaxNumber, Email, PreferredContactMethod, Comments)
               VALUES ('$Title_slashed', '$FirstName_slashed', '$LastName_slashed', '$Company_slashed', '$Position_slashed', '$Address_slashed', '$Suburb_slashed', '$State_slashed', '$PostCode', '$Country_slashed', '$PhoneCode', '$PhoneNumber', '$Mobile', '$FaxCode', '$FaxNumber', '$Email_slashed', '$PreferredContactMethod', '$Comments_slashed')");
  // Close connection
  mysql_close($connection);
  
//***********Send Email***********

  $message = "New account registration details:\n\n".
                    "Title: ".$Title."\n".
                    "First Name: ".$FirstName."\n".
                    "Last Name: ".$LastName."\n".
                    "Company: ".$Company."\n".
                    "Position: ".$Position."\n".
                    "Address: ".$Address."\n".
                    "Suburb: ".$Suburb."\n".
                    "State: ".$State."\n".
                    "Post Code: ".$PostCode."\n".
                    "Country: ".$Country."\n".
                    "Phone: ".$Phone."\n".
                    "Mobile: ".$Mobile."\n".
                    "Fax: ".$Fax."\n".
                    "Email: ".$Email."\n".
                    "Preferred Contact Method: ".$PreferredContactMethod."\n".
                    "Comments: ".$Comments;

  //mail("lisa@lisdesigns.com.au", "CFF - Open Account", $message, "From: ".$Email);

  mail("enquiries@changefreight.com.au", "CFF - Open Account", $message, "From: ".$Email);

  header( "Location: http://www.changefreight.com.au/thankyou.php" );

  }

?>
