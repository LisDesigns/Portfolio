<?
   session_start();
   include "header.php";

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}


mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());
$query = "SELECT * FROM registration";

//, memberusername
$result = mysql_query($query);

$i = 0;
$memberusernamelist = "";

while($row = mysql_fetch_assoc($result)) {

  $memberusernamelist .= $row['memberusername'].">";
  $i++;

}
?>

</script>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="all" name="category"/>
        <table>
        <tr><td><b>Colour</b>:</td><td><select name="colour"><option>Any</option><option>Black</option><option>Blue</option><option>Red</option><option>Green</option><option>Other</option></select></td></tr>
        <tr><td><b>Transmission</b>:</td><td><select name="transmission"><option>Any</option><option>Automatic</option><option>Manual</option></select></td></tr>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearch.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search" class="buttons" style="width:70px"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postad.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>

    </div>

  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
    
      <h1 style="display:inline;padding-left:0px">Register</h1>
      <br/>
   
   <div id="errorMessageDiv" style="color:red; font-weight:normal;"></div>
   <form name="register" method="post" action="createaccount.php">
        Save time. Pay securely without sharing your financial information.<br/><br/>
    <table>
      <tr><td width="130"><font color="gray">*</font> Username:</td><td><input type="text" name="memberusername"/></td></tr>
      <tr><td><font color="gray">*</font> Password:</td><td><input type="text" name="memberpassword"/></td></tr>
      <tr><td><font color="gray">*</font> First Name:</td><td><input type="text" name="firstname"/></td></tr>
      <tr><td><font color="gray">*</font> Last Name:</td><td><input type="text" name="lastname"/></td></tr>
      <tr><td> &nbsp;&nbsp; Company: </td><td><input type="text" name="company"/></td></tr>
      <tr><td><font color="gray">*</font> Address:</td><td><input type="text" name="address"/></td></tr>
      <tr><td><font color="gray">*</font> Suburb:</td><td><input type="text" name="suburb"/></td></tr>
      <tr><td><font color="gray">*</font> State:</td><td><select name="state"><option>Any</option><option>NSW</option><option>ACT</option><option>QLD</option><option>VIC</option><option>TAS</option><option>WA</option><option>NT</option></select></td></tr>
      <tr><td><font color="gray">*</font> Post Code:</td><td><input type="text" name="postcode" onkeyup="checkDigits(8)"/></td></tr>
      <tr><td><font color="gray">*</font> Phone:</td><td><input type="text" name="phone" onkeyup="checkDigits(9)"/></td></tr>
      <tr><td> &nbsp;&nbsp; Mobile: </td><td><input type="text" name="mobile" onkeyup="checkDigits(10)"/></td></tr>
      <tr><td><font color="gray">*</font> Email: </td><td><input type="text" name="email"/></td></tr>
      <tr><td>Joining Fee:</td><td><input type="text" name="L_AMT0" size="5" maxlength="32" value="20.00" style="border:solid 1px rgb(220,220,220)"/></td></tr>
<input type="hidden" size="30" maxlength="32" name="L_NAME0" value="Joining Fee" />
        <input type="hidden" size="3" maxlength="32" name="L_QTY0" value="1" /> 
        <input name="currencyCodeType" type="hidden" value="AUD"/>

      <tr><td><br/><input type="reset" value="Clear" class="buttons" style="width:60px"/></td><td align="left">
      <br/><div id="submitDiv" style="text-align:right;"><input type="button" value="Register" class="buttons" onclick="checkValues()" style="width:60px"/></div></td></tr>

    </table>
      <br/>  
	<br/><!--<input type="image" name="submit" src="https://www.paypal.com/en_US/i/btn/btn_xpressCheckout.gif" />-->
   </form>
<script language="JavaScript1.2">

function checkUsername(newusername) {

x = 0;
i = <? echo $i; ?>;
list = "<? echo $memberusernamelist; ?>";

newlist = list.split(">");

for (x = 0; x < newlist.length; x++) {
  if (newlist[x] == newusername) {

    register.elements[0].value = "";
 
    return true;
  } 
}


}
   <script language="JavaScript1.2" type="text/javascript" src="scripts/validateForm.js"></script>
   </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:80px"></td>
  <td id="rightbg1" style="height:80px"></td>
</tr>
</tr>
<?
include "footer.php";
?>