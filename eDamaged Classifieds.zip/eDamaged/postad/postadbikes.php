<?
   session_start();

   $_SESSION["user"];
   $_SESSION["pass"];
   $_SESSION["memberid"];
   $_SESSION["paid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }

   if ($_SESSION["paid"] != "paid"){
     $subtitle = "Error";
     $message = "Registration payment is required before posting ads.";
     include "blank.php";   
   }
   include "header.php";

?>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box5.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Bike Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="bikes" name="category"/>
        <table>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option><option>Damaged</option></select></td></tr>
        <tr><td><b>Damage</b>:</td><td><select name="damage"><option>Any</option><option>Hail</option><option>Fire</option><option>Water</option><option>Exterior</option><option>Mechanical</option><option>Other</option></select></td></tr>
        <tr><td><b>Location</b>:</td><td><select name="location"><option>Any</option><option>NSW</option><option>ACT</option><option>QLD</option><option>VIC</option><option>TAS</option><option>WA</option><option>NT</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearchbikes.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search" class="box5buttons" ></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box5.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postadbikes.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>
    </div>


  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
          
      <h1 style="display:inline;padding-left:0px">Post an Ad</h1>
      <br/>

      <br/><font color=#3a557e><i>Please make sure to select a category.</i></font>

   <div id="errorMessageDiv" style="color:red; font-weight:normal;"></div>
   <form name="postad" method="post" action="publishad.php" enctype="multipart/form-data">
    <table>
      <tr><td width="130">Item Name: <font color="gray">*</font></td><td><input type="text" name="itemname"/></td><td width="130"></td><td></td></tr>
      <tr><td width="130">Category:</td><td><input name="category" value="Bikes" readonly class="categories" /></td><td width="130">Type:</td><td><select name="airconditioning" ><option>Please select</option><option>Road</option><option>Off Road</option><option>ATV</option><option>Scooter</option><option>Other</option></select></td></tr>

      <tr><td width="130">Make: </td><td><input type="text" name="make"/></td><td width="130">Condition: </td><td><select name="newused"><option>Please select</option><option>New</option><option>Used</option><option>Damaged</option></select></td></tr>

     <tr><td width="130">Model: </td><td><input type="text" name="model"/></td><td width="130">Bike Description: </td><td rowspan="2"><textarea name="vehicledescription"></textarea></td></tr>
      <tr><td width="130">Price: </td><td><input type="text" name="price" onkeyup="validateDigits(this.value)"/></td></td></tr>
      <tr><td width="130">Year: </td><td><input type="text" name="year"/></td><td width="130">Type of Damage: </td><td><select name="damage"><option>Please select</option><option>Hail</option><option>Fire</option><option>Water</option><option>Exterior</option><option>Interior</option><option>Mechanical</option><option>Other</option></select></tr>
      <tr><td width="130">Colour: </td><td><input type="text" name="colour"/></td><td width="130" rowspan="2">Damage Description: </td><td rowspan="2"><textarea name="damagedescription"></textarea></td></tr>
      <tr><td width="130">Kilometres: </td><td><input type="text" name="kilometres"/></td></tr>

      <tr><td colspan="4"><h1 style="display:inline;padding-left:0px"><br/>Upload Images<br/><br/></h1></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px"><input type="file" name="file1" id="file1" style="width:241px;text-align:left!important"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px"><input type="file" name="file4" id="file4" style="width:241px;text-align:left!important"/></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px"><input type="file" name="file2" id="file2" style="width:241px;text-align:left!important"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px"><input type="file" name="file5" id="file5" style="width:241px;text-align:left!important"/></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px"><input type="file" name="file3" id="file3" style="width:241px;text-align:left!important"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px"><input type="file" name="file6" id="file6" style="width:241px;text-align:left!important"/></td></tr>

      <tr><td colspan="4"><h1 style="display:inline;padding-left:0px"><br/>Vehicle Features<br/><br/></h1><div style="margin-left:21px">Please list the main features of your vehicle.<br/><br/></div></td></tr>
      
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature1" style="width:241px;"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature6" style="width:241px;"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature2" style="width:241px;"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature7" style="width:241px;"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature3" style="width:241px;"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature8" style="width:241px;"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature4" style="width:241px;"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature9" style="width:241px;"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature5" style="width:241px;"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature10" style="width:241px;"/></td></tr>

       <tr><td><br/><input type="reset" value="Clear" style="width:60px" class="buttons"/></td><td align="right" colspan="3" style="text-align:right!important">
          <br/><div id="submitDiv" style="text-align:right!important; width:401px"><input type="submit" value="Post Advert" style="width:110px" class="buttons"/></div></td></tr>
    </table>

    </form>
<script language="JavaScript 1.2" type="text/javascript">

 function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    // true or false will be returned 
    if (!digitPattern.test(digitStr)) {
      alert("Please enter only numbers in the price field.");
      document.postad.price.value="";
    }
 }

</script>

    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:230px"></td>
  <td id="rightbg1" style="height:230px"></td>
</tr>
</tr>
<?
include "footer.php";
?>