<tr><td id="footer" colspan="4">
&copy Copyright 2010 eDamaged. All rights reserved.&nbsp;<a href="privacy.php">Privacy</a>&nbsp;<a href="terms.php">Terms</a>&nbsp;<a href="disclaimer.php">Disclaimer</a>&nbsp;<a href="contactus.php">Contact Us</a>&nbsp;<a href="sitemap.php">Site Map</a>&nbsp; 
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp;   &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; Created by <a href="http://www.lisdesigns.com.au" id="lisdesigns" >Lis Designs</a></td>

</tr>
</table>
</center>
</div>
</body>
</html>