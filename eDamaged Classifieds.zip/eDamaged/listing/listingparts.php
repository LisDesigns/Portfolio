<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];


   include "header.php";
?>


<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="all" name="category"/>
        <table>
        <tr><td><b>Colour</b>:</td><td><select name="colour"><option>Any</option><option>Black</option><option>Blue</option><option>Red</option><option>Green</option><option>Other</option></select></td></tr>
        <tr><td><b>Transmission</b>:</td><td><select name="transmission"><option>Any</option><option>Automatic</option><option>Manual</option></select></td></tr>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearch.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search" style="background-color:#29476f; color:rgb(220,220,220); font-family:verdana; font-size:10px; font-weight:bold; width:70px"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postad.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>

    </div>

  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
          
      <h1 style="display:inline;padding-left:0px">Vehicle Information</h1>
      <br/>

      <?php

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

       $id = $_GET['id'];

       // $query = mysql_query("SELECT * FROM advertImages MAX(advertsId)");
       // $result = mysql_query($query);
       // $row = mysql_fetch_assoc($result);
       // echo $advertsId = $row['advertsId'];
// WHERE category = 'Cars'


        $query  = "SELECT * FROM adverts WHERE advertsId = ".$id;
        //$query  = "SELECT * FROM adverts WHERE advertsId = 85";
        $result = mysql_query($query);
 
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
       while($row = mysql_fetch_assoc($result))
       {
$advertsid = $row['advertsId'];

$registrationid = $row['registrationId'];
$itemname = $row['itemName'];

$file1 = "uploads/adid".$row['advertsId'].img1.".jpg";
$file2 = "uploads/adid".$row['advertsId'].img2.".jpg";
$file3 = "uploads/adid".$row['advertsId'].img3.".jpg";
$file4 = "uploads/adid".$row['advertsId'].img4.".jpg";
$file5 = "uploads/adid".$row['advertsId'].img5.".jpg";
$file6 = "uploads/adid".$row['advertsId'].img6.".jpg";
       
echo "<table style='float:left;'><tr><td>Id:</td><td style='width:200px'>".$row['advertsId']."</td></tr>";
        echo "<tr><td>Item Name:</td><td>".$row['itemName']."</td></tr>";
        echo "<tr><td>Category:</td><td>".$row['category']."</td></tr>";
        if ($row['type']=="Please select") {
          $type = "";
        }
        echo "<tr><td>Type:</td><td>".$type."</td></tr>";
        if ($row['model']=="Please select") {
          $model = "";
        }
        echo "<tr><td>For:</td><td>".$model."</td></tr>";
        echo "<tr><td>Brand:</td><td>".$row['make']."</td></tr>";
        echo "<tr><td>Price:</td><td>".$row['price']."</td></tr>";
        echo "<tr><td>Purchased (Year):</td><td>".$row['year']."</td></tr>";
        if ($row['newUsed']=="Please select") {
          $newused = "";
        }
        echo "<tr><td>Condition:</td><td>".$newused."</td></tr>";
        if ($row['typeOfDamage']=="Please select") {
          $typeOfDamage = "";
        }
        echo "<tr><td>Type of Damage:</td><td>".$typeOfDamage."</td></tr>";
        echo "<tr><td colspan='2'>";
        echo "</td></tr>";
        echo "<tr><td colspan='2'><br/><br/><b>Vehicle Description</b></td></tr>";
        echo "<tr><td colspan='2'><textarea class='listtext' readonly scrolling='auto'>".$row['vehicleDescription']."</textarea></td></tr>";
        echo "<tr><td colspan='2'><br/><br/><b>Damage Description</b></td></tr>";
        echo "<tr><td colspan='2'><textarea class='listtext' readonly auto>".$row['damageDescription']."</textarea></td></tr>";
        echo "<tr><td colspan='2'><br/><br/><b>Vehicle Features</b></td></tr>";
}

      



/*

Item Name:
Category:
Type:
For:
Brand:
Price:
Condition:
Item Description:
Type of Damage:
Damage Description:

*/



        $query  = "SELECT * FROM vehicleFeatures WHERE advertsId = ".$id;
        $result = mysql_query($query);
        while($row = mysql_fetch_assoc($result))
        {
        $i++;
        if (($i<=10) && (strlen($row['vehicleFeature']) > 0)) {
          echo "<tr><td colspan='2'><font color='#3a557e'>&#8226;</font>".$row['vehicleFeature']."</td></tr>";
          }
        }
        

echo '<table style="float:right;width:110px;overflow:hidden"><tr><td colspan="2">';
if (file_exists($file1)) { 
  echo '<div style="width:200px;height:200px;overflow:hidden;border-style:solid;border-color:rgb(200,200,200);border-width:1px;"><img src="'.$file1.'" name="largeimage" id="largeimage" width="200" border="0" style="display:inline;border-color:rgb(200,200,200)"/></div>';
} else {
 echo '<img src="uploads/blank.png" width="200" height="200" border="1" align="right" style="border-color:rgb(200,200,200);cursor:pointer"/>';
}

echo '</td></tr><tr><td colspan="2"><br/><b align="left"><br/>More Images</b><small><br/><br/></small>';

if (file_exists($file2)) {   
  echo '<img src="'.$file2.'" onclick="swapImage('."'".$file2."'".')" width="92" height="92" border="1"  align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo '<img src="uploads/blank.png" width="92" height="92" border="1"  align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
}

if (file_exists($file3)) { 
  echo '<img src="'.$file3.'" onclick="swapImage('."'".$file3."'".')" width="92" border="1" height="92" align="left"  style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo '<img src="uploads/blank.png" width="92" height="92" border="1"  align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
}


echo "<br/><br/><br/><br/><br/><br/><br/><br/>";


if (file_exists($file4)) { 
  echo '<img src="'.$file4.'" onclick="swapImage('."'".$file4."'".')" width="92" height="92" border="1" align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo '<img src="uploads/blank.png" width="92" height="92" border="1"  align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
}
if (file_exists($file5)) { 
  echo '<img src="'.$file5.'" onclick="swapImage('."'".$file5."'".')" width="92" height="92" border="1" align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo '<img src="uploads/blank.png" width="92" height="92" border="1"  align="left"  style="border-color:rgb(200,200,200);cursor:pointer"/>';
}


echo "<br/><br/><br/><br/><br/><br/><br/><br/>";
if (file_exists($file6)) { 

  echo '<img src="'.$file6.'" onclick="swapImage('."'".$file6."'".')" width="92" height="92" border="1" align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo '<img src="uploads/blank.png" width="92" height="92" border="1"  align="left" style="border-color:rgb(200,200,200);cursor:pointer"/>';
}
if (file_exists($file1)) {   
  echo ' &nbsp;<img src="'.$file1.'" onclick="swapImage('."'".$file1."'".')" width="92" height="92" border="1"  style="border-color:rgb(200,200,200);cursor:pointer"/>';
} else {
  echo ' &nbsp;<img src="uploads/blank.png" width="92" height="92" border="1"  style="border-color:rgb(200,200,200);cursor:pointer"/>';
}
/**/
echo "</td></tr>";
        echo '<tr><td colspan="2"><br/><h1>Contact Seller</h1></td></tr>';
        echo '<tr><td>
<form action="sendmessage.php" method="post" style="display:inline">
<input type="hidden" name="itemname" value="'.$itemname.'"/>
<input type="hidden" name="sellerid" value="'.$registrationid.'"/>
Name:</td><td style="text-align:right"><input type="text" name="firstname" style="width:150px"></td></tr>
<tr><td>Email:</td><td style="text-align:right"><input name="email" type="text" style="width:150px"></td></tr>
<tr><td>Message:</td><td style="text-align:right"><textarea style="width:150px" name="message"></textarea></td></tr>
<tr><td colspan="2" style="text-align:right"><input type="submit" style="width:100px;" value="Send" class="buttons"/>';
echo "</td></tr></table></form>";



        //echo "Seller Id: ".$row['registrationId']."<br/>";

        //echo "Email Id: ".$row['registrationId']."<br/>";

        mysql_close($connection);

      ?>   
      <br/>


    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:400px"></td>
  <td id="rightbg1" style="height:400px"></td>
</tr>
<script language="JavaScript1.2">
function swapImage(imagename) {
  document.images['largeimage'].src=imagename;
}

</script>
<?
include "footer.php";
?>