<html>
<link href="sdk.css" rel="stylesheet" type="text/css"/>
  <table class="api" width=400>
	        	<?php 
    		foreach($resArray as $key => $value) {
    			
    			//echo "<tr><td> $key:</td><td>$value</td>";
    			}	
       			?>
  </table>
</html>