<?php
/***********************************************************
SetExpressCheckout.php

This is the main web page for the Express Checkout sample.
The page allows the user to enter amount and currency type.
It also accept input variable paymentType which becomes the
value of the PAYMENTACTION parameter.

When the user clicks the Submit button, ReviewOrder.php is
called.

Called by index.html.

Calls ReviewOrder.php.

***********************************************************/
// clearing the session before starting new API Call
session_unset();

	$paymentType = $_GET['paymentType'];
        $paymentType = "sale";
?>


<html>
<head>
    <title>PayPal NVP SDK - Simplified Shopping Cart Page for a Spiritual Store</title>
    <link href="sdk.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <center>
	<form action="ReviewOrder.php" method="POST">
	<input type=hidden name=paymentType value='<?php echo $paymentType?>' >



    <table class="api">
        <tr>
			   <td colspan="2" class="header">
				   Step 1: SetExpressCheckout
			   </td>
        </tr>

        <tr>
           <td colspan="2">
                <center></br>
                You must be logged into <a href="https://developer.paypal.com" id="PayPalDeveloperCentralLink"  target="_blank">Developer
                    Central</br> </a> </br>
                </center>
            </td>
        </tr>
        </table>
		<table>
        <th>Shopping cart Products:</th>
        <tr>


<input type="hidden" size="30" maxlength="32" name="L_NAME0" value="Joining Fee" />
<input type="hidden" size="3" maxlength="32" name="L_QTY0" value="1" /> </td>
<b>Joining Fee:</b> <input type="text" name="L_AMT0" size="5" maxlength="32" value="20.00" />
<input name="currencyCodeType" type="hidden" value="AUD"/>

			</tr>

   	<!--
			 <tr>
			
			<tr>
			 <td class="field">
					Currency: <br /> </td>
				<td>
           
    </td>
	    </tr>
	    <tr>
	    	<td class="field">
	    		Ship To:
	    	</td>
	    	<td>&nbsp;</td>
	    </tr>	
	 
        <tr>
			<td class="field">
				 Name:</td>
			<td>
				<input type="text" size="30" maxlength="32" name="PERSONNAME" value="" /></td>
		</tr>
		<tr>
			<td class="field">
				Street:</td>
			<td>
				<input type="text" size="30" maxlength="32" name="SHIPTOSTREET" value="" /></td>
		</tr>
		<tr>
			<td class="field">
				City:</td>
			<td>
				<input type="text" size="30" maxlength="32" name="SHIPTOCITY" value="" /></td>
		</tr>
		<tr>
			<td class="field">
				State:</td>
			<td>
				<input type="text" size="30" maxlength="32" name="SHIPTOSTATE" value="" /></td>
		</tr>

				<input type="hidden" size="30" maxlength="32" name="SHIPTOCOUNTRYCODE" value="AU" />
	
		<tr>
			<td class="field">
				Zip Code:</td>
			<td>
				<input type="text" size="30" maxlength="32" name="SHIPTOZIP" value="" /></td>
		            </tr>
-->
	<tr>
		<td>
			<input type="image" name="submit" src="https://www.paypal.com/en_US/i/btn/btn_xpressCheckout.gif" />

		</td>
		<td colspan=6>
                <br />
                <br />
               
                Save time. Pay securely without sharing your financial information.
            </td>

	</tr>
    </table>
    </center>
    <a class="home" id="CallsLink" href="index.html">Home</a>
</body>
</html>
