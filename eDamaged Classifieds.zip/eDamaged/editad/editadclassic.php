<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }

$advertid = $_GET['id'];



$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

$query = "SELECT * FROM `adverts` WHERE advertsId=".$advertid;

$result = mysql_query($query);

$result1 = $result;

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

$i=0;
while($row = mysql_fetch_assoc($result)) {
  $i++;
  $itemname=$row['itemName'];
  $transmission=$row['transmission'];
  $category=$row['category'];
  $airconditioning=$row['airConditioning'];
  $make=$row["make"];
  $newused=$row["newUsed"];
  $model=$row["model"];
  $vehicledescription=$row["vehicleDescription"];
  $price=$row["price"];
  $year=$row["year"];
  $damage=$row["typeOfDamage"];
  $colour=$row["colour"];
  $damagedescription=$row["damageDescription"];
  $kilometres=$row["kilometres"];

}


$file1 = "uploads/adid".$advertid.img1.".jpg";
$file2 = "uploads/adid".$advertid.img2.".jpg";
$file3 = "uploads/adid".$advertid.img3.".jpg";
$file4 = "uploads/adid".$advertid.img4.".jpg";
$file5 = "uploads/adid".$advertid.img5.".jpg";
$file6 = "uploads/adid".$advertid.img6.".jpg";


if (!file_exists($file1)) { 
  $file1 = "uploads/blank.png";
}

if (!file_exists($file2)) { 
  $file2 = "uploads/blank.png";
}

if (!file_exists($file3)) { 
  $file3 = "uploads/blank.png";
}

if (!file_exists($file4)) { 
  $file4 = "uploads/blank.png";
}

if (!file_exists($file5)) { 
  $file5 = "uploads/blank.png";
}

if (!file_exists($file6)) { 
  $file6 = "uploads/blank.png";
}

//$query = "SELECT * FROM `adverts` WHERE advertsId =".$advertid;

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=1 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature1=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=2 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature2=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=3 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature3=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=4 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature4=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=5 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature5=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=6 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature6=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=7 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature7=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=8 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature8=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=9 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature9=$row["vehicleFeature"];
}

$query = "SELECT * FROM `vehicleFeatures` WHERE vehiclesFeaturesId=10 AND advertsId=".$advertid;
$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} 
while($row = mysql_fetch_assoc($result)) {
  $vehiclefeature10=$row["vehicleFeature"];
}


//}

   include "header.php";
?>
<script language="JavaScript1.2">
function clearForm() {

  document.editad.elements[4].value ="";
  document.editad.elements[5].value ="";
  document.editad.elements[6].value ="";
  document.editad.elements[7].value ="";
  document.editad.elements[8].value ="";
  document.editad.elements[9].value ="";
  document.editad.elements[10].value ="";
  document.editad.elements[11].value ="";
  document.editad.elements[12].value ="";
  document.editad.elements[13].value ="";
  document.editad.elements[14].value ="";
  document.editad.elements[15].value ="";
  document.editad.elements[16].value ="";
  document.editad.elements[17].value ="";
  document.editad.elements[18].value ="";
  document.editad.elements[19].value ="";
  document.editad.elements[20].value ="";
  document.editad.elements[21].value ="";
  document.editad.elements[22].value ="";
  document.editad.elements[23].value ="";
  document.editad.elements[24].value ="";
  document.editad.elements[25].value ="";
  document.editad.elements[26].value ="";
}
</script>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box6.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Classic/Restored Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="classic" name="category"/>
        <table>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option><option>Damaged</option></select></td></tr>
        <tr><td><b>Damage</b>:</td><td><select name="damage"><option>Please select</option><option>Hail</option><option>Fire</option><option>Water</option><option>Exterior</option><option>Interior</option><option>Mechanical</option><option>Other</option></select></td></tr>
        <tr><td><b>Location</b>:</td><td><select name="location"><option>Any</option><option>NSW</option><option>ACT</option><option>QLD</option><option>VIC</option><option>TAS</option><option>WA</option><option>NT</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearchclassic.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search"  class="box6buttons"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box6.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postadclassic.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>
    </div>


  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
          
      <h1 style="display:inline;padding-left:0px">Edit Ad</h1>
      <br/>
   
      <br/>

<script language="Javascript1.2">
function change1() {
  document.getElementById("box1").innerHTML = '<input type="file" name="file1" id="file1" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove1" value="remove"/>';
}
function change2() {
  document.getElementById("box2").innerHTML = '<input type="file" name="file2" id="file2" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove2" value="remove"/>';
}
function change3() {
  document.getElementById("box3").innerHTML = '<input type="file" name="file3" id="file3" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove3" value="remove"/>';
}
function change4() {
  document.getElementById("box4").innerHTML = '<input type="file" name="file4" id="file4" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove4" value="remove"/>';
}
function change5() {
  document.getElementById("box5").innerHTML = '<input type="file" name="file5" id="file5" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove5" value="remove"/>';
}
function change6() {
  document.getElementById("box6").innerHTML = '<input type="file" name="file6" id="file6" style="width:241px;text-align:left!important;"/><input type="hidden" name="remove6" value="remove"/>';
}
</script>


   <div id="errorMessageDiv" style="color:red; font-weight:normal;"></div>
   <form name="editad" method="post" action="updatead.php" enctype="multipart/form-data">
<input type="hidden" name="advertid" value="<? echo $_GET["id"]; ?>">
    <table>

      <tr><td width="130">Item Name: <font color="gray">*</font></td>
          <td><input type="text" name="itemname" value="<? echo $itemname; ?>"/></td>
          <td width="130">Transmission: </td>
      <td><select name="transmission"><option><? echo $transmission; ?></option><option>Automatic</option><option>Manual</option></select></td></tr>
      <tr><td width="130">Category:</td><td><input name="category" value="Classic and Restored" readonly class="categories" /></select></td>
          <td width="130">Air Conditioning: </td>
          <td><input type="radio" class="radiobuttons" name="airconditioning" value="Yes"> Yes &nbsp;<input type="radio" name="airconditioning" class="radiobuttons" value="No"> No</td></tr>
      <tr><td width="130">Make: </td>
          <td><input type="text" name="make" value="<? echo $make; ?>"/></td>
          <td width="130">Condition: </td>
          <td><select name="newused"><option>Please select</option><option>New</option><option>Used</option><option>Damaged</option></select></td></tr>
      <tr><td width="130">Model: </td>
          <td><input type="text" name="model" value="<? echo $model; ?>"/></td><td width="130">Vehicle Description: </td>
          <td rowspan="2"><textarea name="vehicledescription"><? echo $vehicledescription; ?></textarea></td></tr>
      <tr><td width="130">Year: </td>
          <td><input type="text" name="year" value="<? echo $year; ?>"/></td></tr>
      <tr><td width="130">Price: </td>
          <td><input type="text" name="price" value="<? echo $price; ?>" onkeyup="validateDigits(this.value)"/></td><td width="130">Type of Damage: </td><td><select name="damage"><option>Please select</option><option>Hail</option><option>Fire</option><option>Water</option><option>Exterior</option><option>Interior</option><option>Mechanical</option><option>Other</option></select></tr>
      <tr><td width="130">Colour: </td>
          <td><input type="text" name="colour" value="<? echo $colour; ?>"/></td>
          <td width="130" rowspan="2">Damage Description: </td>
          <td rowspan="2"><textarea name="damagedescription"><? echo $damagedescription; ?></textarea></td></tr>
      <tr><td width="130">Kilometres: </td>
          <td><input type="text" name="kilometres" value="<? echo $kilometres; ?>"/></td></tr>
<!--

<input type="radio" class="radiobuttons" name="airconditioning" value="Yes" <? if ($airconditioning == "Yes") { echo "checked"; } ?> > Yes &nbsp;<input type="radio" name="airconditioning" class="radiobuttons" value="No" <? if ($airconditioning == "No") { echo "checked"; } ?> > No</td></tr>
<input type="radio" class="radiobuttons" name="newused" value="New" <? if ($newused == "New") { echo "checked"; } ?>> New <input type="radio" name="newused" class="radiobuttons" value="Used" <? if ($newused == "Used") { echo "checked"; } ?> > Used</td></tr>
<input type="text" name="damage" value="<? echo $damage; ?>"/>


-->
      <tr><td colspan="4"><h1 style="display:inline;padding-left:0px"><br/>Upload Images<br/><br/></h1><div style="margin-left:21px">To upload a new image (or to delete an image), click on the image you'd like to change.<br/><br/></div></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px" id="box1"><img src="<? echo $file1; ?>" name="file1" id="file1" onclick="change1();" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px" id="box4"><img src="<? echo $file4; ?>" name="file4" id="file4" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid" onclick="change4();" /></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px" id="box2"><img src="<? echo $file2; ?>" name="file2" id="file2" onclick="change2();" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px" id="box5"><img src="<? echo $file5; ?>" name="file5" id="file5" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid" onclick="change5();" /></td></tr>
      <tr><td colspan="2" style="text-align:left!important;padding-left:21px" id="box3"><img src="<? echo $file3; ?>" name="file3" id="file3" onclick="change3();" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid"/></td><td colspan="2"  style="text-align:left!important;padding-left:21px" id="box6"><img src="<? echo $file6; ?>" name="file6" id="file6" style="width:80px;height:80px;text-align:left!important;cursor:pointer;border-color:rgb(220,220,220);border-width:1px;border-style:solid" onclick="change6();" /></td></tr>

      <tr><td colspan="4"><h1 style="display:inline;padding-left:0px"><br/>Vehicle Features<br/><br/></h1><div style="margin-left:21px">Please list the main features of your vehicle.<br/><br/></div></td></tr>
      
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature1" style="width:241px;" value="<? echo $vehiclefeature1; ?>"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature6" style="width:241px;" value="<? echo $vehiclefeature6; ?>"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature2" style="width:241px;" value="<? echo $vehiclefeature2; ?>"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature7" style="width:241px;" value="<? echo $vehiclefeature7; ?>"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature3" style="width:241px;" value="<? echo $vehiclefeature3; ?>"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature8" style="width:241px;" value="<? echo $vehiclefeature8; ?>"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature4" style="width:241px;" value="<? echo $vehiclefeature4; ?>"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature9" style="width:241px;" value="<? echo $vehiclefeature9; ?>"/></td></tr>
      <tr><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature5" style="width:241px;" value="<? echo $vehiclefeature5; ?>"/></td><td align="right" colspan="2" style="text-align:left!important;padding-left:21px"><input type="text" name="vehiclefeature10" style="width:241px;" value="<? echo $vehiclefeature10; ?>"/></td></tr>

       <tr><td><br/><input type="button" onclick="clearForm()" value="Clear" style="width:60px" class="buttons"/></td><td align="right" colspan="3" style="text-align:right!important">
          <br/><div id="submitDiv" style="text-align:right!important; width:401px"><input type="submit" value="Post Advert" style="width:110px" class="buttons"/></div></td></tr>
    </table>

    </form>
<script language="JavaScript 1.2" type="text/javascript">

 function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    // true or false will be returned 
    if (!digitPattern.test(digitStr)) {
      alert("Please enter only numbers in the price field.");
      document.postad.price.value="";
    }
 }

</script>

    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:420px"></td>
  <td id="rightbg1" style="height:420px"></td>
</tr>
<?
include "footer.php";
?>