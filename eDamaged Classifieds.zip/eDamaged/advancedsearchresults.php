<?
   session_start();
   include "header.php";
   $pagenum = $_POST["page"];
   if ($pagenum == "") {
     $pagenum = 1;
   }
?>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="all" name="category"/>
        <table>
        <tr><td><b>Colour</b>:</td><td><select name="colour"><option>Any</option><option>Black</option><option>Blue</option><option>Red</option><option>Green</option><option>Other</option></select></td></tr>
        <tr><td><b>Transmission</b>:</td><td><select name="transmission"><option>Any</option><option>Automatic</option><option>Manual</option></select></td></tr>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearch.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search" style="background-color:#29476f; color:rgb(220,220,220); font-family:verdana; font-size:10px; font-weight:bold; width:70px"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postad.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>

    </div>

  </td>
  <td id="content2" rowspan="2">



<?
$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

$colour = $_POST["colour"];
$transmission = $_POST["transmission"];
$price  = $_POST["price"];
$condition = $_POST["condition"];
$keywords = $_POST["keywords"];
$make = $_POST["make"];
$model = $_POST["model"];
$year = $_POST["year"];
$kilometres = $_POST["kilometres"];
$damage = $_POST["damage"];
$airconditioning= $_POST["airconditioning"];


//echo $colour . " " . $transmission . " " . $price . " " . $condition . " " . $keywords."<br/><br/>";

//print_r(explode(' ', $keywords, 3));


// Conditions
$c=0;
//$query = "SELECT adverts.*, vehicleFeatures.* FROM adverts RIGHT JOIN vehicleFeatures ON (adverts.advertsId = vehicleFeatures.advertsId) WHERE category = 'Cars'";

if ($category == "All") {
  $query = "SELECT * FROM adverts";
} else {
  $query = "SELECT * FROM adverts WHERE category = '".strtolower($category)."'";
}

if ($colour != "Any") {
  $c++;
  $query .= " AND colour = '".$colour."'";
}

if ($transmission != "Any") {
  $c++;
  $query .= " AND transmission = '".$transmission."'";
}


if ($condition != "Any") {
  $c++;
  $query .= " AND newUsed = '".$newused."'";
}


if ($make != "Any") {
  $c++;
  $query .= " AND make = '".$make."'";
}

if ($model != "") {
  $c++;
  $query .= " AND model = '".$model."'";
}

if ($year != "") {
  $c++;
  $query .= " AND year = '".$year."'";
}

if ($kilometres != "") {
  $c++;
  $query .= " AND kilometres = '".$kilometres."'";
}

if ($airconditioning != "Any") {
  $c++;
  $query .= " AND airConditioning = '".$airconditioning."'";
}

if ($damage != "Any") {
  $c++;
  $query .= " AND typeOfDamage = '".$damage."'";
}

if ($price != "Any") {
  $c++;
  //$query .= "  price < '".$price."'";
/*
 // if ($price == "Any") {
    $query .= " AND price >= 0";
  //}

  if ($price == "$2001-$5000") {
    $query .= " AND price >= 2001 AND price <= 5000";
  }

  if ($price == "$5001-$10000") {
    $query .= " AND price >= 5001 AND price <= 10000";
  }

  if ($price == "$10001-$15000") {
    $query .= " AND price >= 10001 AND price <= 15000";
  }

  if ($price == "$15001-$25000") {
    $query .= " AND price >= 15001 AND price <= 25000";
  }

  if ($price == "$25001+") {
    $query .= " AND price >= 25001";
  }
*/
}


$keywords = trim($keywords);
if ($keywords!=""){
/*

// Keywords
$keyword = explode(' ', $keywords, 3);

$keywordquery .= " AND (";

$keyword[0] = trim($keyword[0]);
if(!(($keyword[0] == "")|| empty($keyword[0]))) {
  $keywordquery  .= " itemName LIKE '%".$keyword[0]."%'";
  //echo '"k0:'.$keyword[0].'"';
}

$keyword[1] = trim($keyword[1]);
if(!(($keyword[1] == "") || empty($keyword[1]))) {
  $keywordquery .= "OR itemName LIKE '%".$keyword[1]."%'";
  //echo '"k1:'.$keyword[1].'"';
}

$keyword[2] = trim($keyword[2]);
if(!(($keyword[2] == "") || empty($keyword[2]))) {
  $keywordquery .= "OR itemName LIKE '%".$keyword[2]."%'";
  //echo '"k2:'.$keyword[2].'"';
}

$keywordquery .= ')';

if (strlen($keywordquery) > 8) {
  $query .= $keywordquery;
} 



$keywordquery .= " OR (";

$keyword[0] = trim($keyword[0]);
if(!(($keyword[0] == "")|| empty($keyword[0]))) {
  $keywordquery  .= " vehicleDescription LIKE '".$keyword[0]."'";
  //echo '"k0:'.$keyword[0].'"';
}

$keyword[1] = trim($keyword[1]);
if(!(($keyword[1] == "") || empty($keyword[1]))) {
  $keywordquery .= "OR vehicleDescription LIKE '".$keyword[1]."'";
  //echo '"k1:'.$keyword[1].'"';
}

$keyword[2] = trim($keyword[2]);
if(!(($keyword[2] == "") || empty($keyword[2]))) {
  $keywordquery .= "OR vehicleDescription LIKE '".$keyword[2]."'";
  //echo '"k2:'.$keyword[2].'"';
}

$keywordquery .= ')';

if (strlen($keywordquery) > 8) {
  $query .= $keywordquery;
} 


$keywordquery .= " OR (";

$keyword[0] = trim($keyword[0]);
if(!(($keyword[0] == "")|| empty($keyword[0]))) {
  $keywordquery  .= " typeOfDamage LIKE '".$keyword[0]."'";
  //echo '"k0:'.$keyword[0].'"';
}

$keyword[1] = trim($keyword[1]);
if(!(($keyword[1] == "") || empty($keyword[1]))) {
  $keywordquery .= "OR typeOfDamage LIKE '".$keyword[1]."'";
  //echo '"k1:'.$keyword[1].'"';
}

$keyword[2] = trim($keyword[2]);
if(!(($keyword[2] == "") || empty($keyword[2]))) {
  $keywordquery .= "OR typeOfDamage LIKE '".$keyword[2]."'";
  //echo '"k2:'.$keyword[2].'"';
}

$keywordquery .= ')';

if (strlen($keywordquery) > 8) {
  $query .= $keywordquery;
} 

$keywordquery .= " OR (";

$keyword[0] = trim($keyword[0]);
if(!(($keyword[0] == "")|| empty($keyword[0]))) {
  $keywordquery  .= " damageDescription LIKE '".$keyword[0]."'";
  //echo '"k0:'.$keyword[0].'"';
}

$keyword[1] = trim($keyword[1]);
if(!(($keyword[1] == "") || empty($keyword[1]))) {
  $keywordquery .= "OR damageDescription LIKE '".$keyword[1]."'";
  //echo '"k1:'.$keyword[1].'"';
}

$keyword[2] = trim($keyword[2]);
if(!(($keyword[2] == "") || empty($keyword[2]))) {
  $keywordquery .= "OR damageDescription LIKE '".$keyword[2]."'";
  //echo '"k2:'.$keyword[2].'"';
}

$keywordquery .= ')';

if (strlen($keywordquery) > 8) {
  $query .= $keywordquery;
} 



//$query .= "))";
*/
}



  $result = mysql_query($query);
 
if (!$result) {
  echo "Could not successfully run query ($sql) from DB: " . mysql_error();
  exit;
}

$num_rows = mysql_num_rows($result);

$i=0;

echo "<br/><b>Search Results</b><br/><br/>";

echo '<form name="searchresults" action="advancedsearchresults.php" method="post">';
echo '<input type="hidden" name="category" value="'.$category.'">';
echo '<input type="hidden" name="colour" value="'.$colour.'">';
echo '<input type="hidden" name="transmission" value="'.$transmission.'">';
echo '<input type="hidden" name="price" value="'.$price.'">';
echo '<input type="hidden" name="condition" value="'.$condition.'">';
echo '<input type="hidden" name="make" value="'.$make.'" />';
echo '<input type="hidden" name="model" value="'.$model.'" />';
echo '<input type="hidden" name="year" value="'.$year.'" />';
echo '<input type="hidden" name="airconditioning" value="'.$airconditioning.'" />';
echo '<input type="hidden" name="damage" value="'.$damage.'" />';
echo '<input type="hidden" name="kilometres" value="'.$kilometres.'" />';
echo '<input type="hidden" name="keywords" value="'.$keywords.'">';
echo '<input type="hidden" name="page" value="'.$pagenum.'">';


       while($row = mysql_fetch_assoc($result)) {
         $i++;
         if ($pagenum == 1) {
         //if ($i>=0) {
         if (($i>=0) && ($i<7)) {
//             echo $pagenum;
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
             if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
             } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
             }
              echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }




         if ($pagenum == 2) {

         if (($i>=7) && ($i<14)) {

             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
          }
         }

}

         if ($pagenum == 3) {
if (($i>=14) && ($i<21)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 4) {
if (($i>=17) && ($i<25)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 5) {
if (($i>=23) && ($i<31)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 6) {
if (($i>=29) && ($i<37)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 7) {
if (($i>=35) && ($i<43)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 8) {
if (($i>=41) && ($i<49)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }

         if ($pagenum == 9) {
if (($i>=47) && ($i<55)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }


         if ($pagenum == 10) {
if (($i>=53) && ($i<61)) {
             echo "<div style='display:block; width:530px; height:90px; overflow:hidden;margin-top:10px'>";
             echo "<a href='listing.php?id=".$row['advertsId']."'>"; 
             $_FILES["file1"]["name"] = "uploads/adid".$row['advertsId']."img1.jpg";
 
            if (file_exists($_FILES["file1"]["name"])) {
               echo "<img src='uploads/adid".$row['advertsId']."img1.jpg' class='thumbs'/>";
            } else {
               echo "<img src='images/blank.png' class='thumbs'/>";
            }
            echo $row['itemName']."</a><br/>".ShortenText($row['vehicleDescription'])."<br/><br/></div>";
           }
         }
//       }

echo '</form>';

echo '<script language="javascript1.2" type="text/javascript">';
echo '


function choosepage(pagenumber) {

  searchresults.page.value = pagenumber;
  searchresults.submit();

}


';
echo '</script>';



       if ($i>0) {
         $pages = '<br/>Page <a href="#" onclick="choosepage(1)">1</a> ';
       }
       if ($i>6) {
         $pages .= ' <a href="#" onclick="choosepage(2)">2</a> ';
       }
       if ($i>12) {
         $pages .= ' <a href="#" onclick="choosepage(3)">3</a> ';
       }
       if ($i>18) {
         $pages .= ' <a href="#" onclick="choosepage(4)">4</a> ';
       }
       if ($i>24) {
         $pages .= ' <a href="#" onclick="choosepage(5)">5</a> ';
       }
       if ($i>29) {
         $pages .= ' <a href="#" onclick="choosepage(6)">6</a> ';
       }
       if ($i>35) {
         $pages .= ' <a href="#" onclick="choosepage(7)">7</a> ';
       }
       if ($i>41) {
         $pages .= ' <a href="#" onclick="choosepage(8)">8</a> ';
       }
       if ($i>47) {
         $pages .= ' <a href="#" onclick="choosepage(9)">9</a> ';
       }
       if ($i>53) {
         $pages .= ' <a href="#" onclick="choosepage(10)">10</a> ';
       }

if ($i == 0) {
 echo "Your search returned no results.";
} else {
       echo $pages;
}


        mysql_close($connection);
      ?>


    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1" style="height:290px"></td>
  <td id="rightbg1" style="height:290px"></td>
</tr>
<?
include "footer.php";
?>