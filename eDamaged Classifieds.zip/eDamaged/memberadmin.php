<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];
    $_SESSION["paid"];


$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());


$loginusername = $_POST["loginusername"];
$loginpassword = $_POST["loginpassword"];



$query  = "SELECT * FROM registration WHERE memberusername = '".$loginusername."' AND memberpassword = '".$loginpassword."'";
$result = mysql_query($query);
 
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
$i=0;
       while($row = mysql_fetch_assoc($result))
       {
        $i++;
        $memberid = $row['registrationId'];
        //echo $memberid." ";
       }


$query = "SELECT * FROM registration WHERE paidJoiningFee = 'paid' AND registrationId='$memberid'";

$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
$x=0;

while($row = mysql_fetch_assoc($result)) {
   $x++;
}
if ($i>=1) {
 $_SESSION["paid"] = "paid";
} 



if($i >= 1) {

    $_SESSION["user"] = $loginusername;
    $_SESSION["pass"] = $loginpassword;
    $_SESSION["memberid"] = $memberid;

    if($_REQUEST["viewaction"]=="edit"){
      header("location: editads.php");
    } else if($_REQUEST["viewaction"]=="delete"){
      header("location: deleteads.php");
    } else if($_REQUEST["viewaction"]=="profile"){
      header("location: editprofile.php");
    } else if($_REQUEST["viewaction"]=="post"){
      header("location: postad.php");
    } else {
      header("location: viewads.php");
    }
    //include("viewads.php");

} else  {
    $error = "<font color='#CC0000'>Error: The username and/or password entered was incorrect.</font>";
    include("login.php");
}

mysql_close($connection);

?>