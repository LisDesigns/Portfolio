<html>
<head>  
<title>eDamaged</title>
<meta name="description" content=""/>
<meta name="abstract" content=""/>
<meta name="keywords" content=""/>
<meta name="author" content="eDamaged"/>
<meta name="identifier-url" content="http://www.eDamaged.com.au"/>
<meta name="copyright" content="Copyright 2010 eDamaged. All rights reserved."/>
<meta name="distribution" content="global"/> 
<meta name="resource-type" content="document"/>
<meta name="googlebot" content="all"/>
<meta name="ROBOTS" content="all"/>
<meta name="owner" content="eDamaged"/>
<meta name="revisit-after" content="4 Days"/>
<meta name="rating" content="Safe For Kids"/>
<link rel="icon" type="image/x-icon" href="http://www.edamaged.com.au/favicon1.ico" />
<link rel="stylesheet" type="text/css" href="styles/main.css" />
<?
    function ShortenText($text) {

        // Change to the number of characters you want to display
        $chars = 250;

        $text = $text." ";
        $text = substr($text,0,$chars);
        $text = substr($text,0,strrpos($text,' '));
        $text = $text."...";

        return $text;

    }
?>