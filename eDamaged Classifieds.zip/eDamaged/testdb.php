<?php

session_start();

$_SESSION["user"];
$_SESSION["pass"];
$_SESSION["memberid"];
$_SESSION["paid"];

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

$query = "SELECT * FROM registration WHERE paidJoiningFee = 'paid' AMD registrationId='$memberid'";

$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
$i=0;

while($row = mysql_fetch_assoc($result)) {
   $i++;
}
if ($i>=1) {
 $_SESSION["paid"] = "paid";
} 


mysql_close($connection);
echo "done";


?>