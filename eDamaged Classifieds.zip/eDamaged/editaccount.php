<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }

//*******Get Values*******

$memberusername = $_POST['memberusername'];
$memberpassword = $_POST['memberpassword'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$company = $_POST['company'];
$address = $_POST['address'];
$suburb = $_POST['suburb'];
$state = $_POST['state'];
$postcode = $_POST['postcode'];
$phonenumber = $_POST['phone'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];

//*******Submit to Database*******

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

mysql_query("UPDATE `registration` SET `memberusername` = '$memberusername', `memberpassword` = '$memberpassword', `firstName` = '$firstname', `lastName` = '$lastname',  `company` = '$company',  `address` = '$address',  `suburb` = '$suburb',  `state` = '$state',  `postCode` = '$postcode',  `phone` = '$phonenumber',  `mobile` = '$mobile',  `email` = '$email' WHERE `registrationId` =".$_SESSION["memberid"]);

mysql_close($connection);

$subtitle ="Thank you";

$message ="Your profile has been updated.";

include "blank.php";

?>