<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $memberid = $_SESSION["memberid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }

//*******Get Values*******

$itemname=$_POST["itemname"];
$transmission=$_POST["transmission"];
$category=$_POST["category"];
$airconditioning=$_POST["airconditioning"];
$make=$_POST["make"];
$newused=$_POST["newused"];
$model=$_POST["model"];
$vehicledescription=$_POST["vehicledescription"];
$price=$_POST["price"];
$year=$_POST["year"];
$damage=$_POST["damage"];
$colour=$_POST["colour"];
$damagedescription=$_POST["damagedescription"];
$kilometres=$_POST["kilometres"];
$type=$_POST["type"];
$file1=$_POST["file1"];
$file2=$_POST["file2"];
$file3=$_POST["file3"];
$file4=$_POST["file4"];
$file5=$_POST["file5"];
$file6=$_POST["file6"];
$vehiclefeature1=$_POST["vehiclefeature1"];
$vehiclefeature2=$_POST["vehiclefeature2"];
$vehiclefeature3=$_POST["vehiclefeature3"];
$vehiclefeature4=$_POST["vehiclefeature4"];
$vehiclefeature5=$_POST["vehiclefeature5"];
$vehiclefeature6=$_POST["vehiclefeature6"];
$vehiclefeature7=$_POST["vehiclefeature7"];
$vehiclefeature8=$_POST["vehiclefeature8"];
$vehiclefeature9=$_POST["vehiclefeature9"];
$vehiclefeature10=$_POST["vehiclefeature10"];



//*******Submit to Database*******

$username = "edamaged";
$password = "cc887bcd";
$databaseName = "edamaged_main";
$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());
//$airconditioning="test1";
//$newused="test1";
mysql_query("INSERT INTO adverts (registrationId, itemName, category, make, model, price, year, colour, kilometres, transmission, airConditioning, newUsed, vehicleDescription, typeOfDamage, damageDescription, type)
               VALUES ('$memberid','$itemname','$category','$make','$model','$price','$year','$colour','$kilometres','$transmission','$airconditioning','$newused','$vehicledescription','$damage','$damagedescription', '$type')");

$query = "SELECT * FROM `adverts` WHERE advertsId=(select MAX(advertsId) from adverts)";

$result = mysql_query($query);


if (!$result) {
    //echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

$i=0;
while($row = mysql_fetch_assoc($result))
  {
    $i++;
    $advertsId = $row['advertsId'];
    ////echo $advertsId." ";
  }


mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('1', '$advertsId', '$vehiclefeature1')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('2', '$advertsId', '$vehiclefeature2')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('3', '$advertsId', '$vehiclefeature3')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('4', '$advertsId', '$vehiclefeature4')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('5', '$advertsId', '$vehiclefeature5')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('6', '$advertsId', '$vehiclefeature6')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('7', '$advertsId', '$vehiclefeature7')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('8', '$advertsId', '$vehiclefeature8')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('9', '$advertsId', '$vehiclefeature9')");

mysql_query("INSERT INTO `vehicleFeatures` (`vehiclesFeaturesId` ,`advertsId` ,`vehicleFeature`)
VALUES ('10', '$advertsId', '$vehiclefeature10')");

$query = "SELECT state FROM `registration` WHERE  registrationId='$memberid'";
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

$i=0;
while($row = mysql_fetch_assoc($result))
  {
    $i++;
    $state = $row['state'];
  }

mysql_query("UPDATE adverts SET location='$state' WHERE registrationId='$memberid'");



mysql_close($connection);



$error ="";
if (strlen($_FILES["file1"]["name"]) > 0) {
if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg")|| ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {
  if ($_FILES["file1"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file1"]["error"] . "<br />";
  } else {
      $_FILES["file1"]["name"]="adid".$advertsId."img1.jpg";
      move_uploaded_file($_FILES["file1"]["tmp_name"],
      "uploads/" . $_FILES["file1"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file2"]["name"]) > 0) {
if ((($_FILES["file2"]["type"] == "image/gif") || ($_FILES["file2"]["type"] == "image/jpeg")|| ($_FILES["file2"]["type"] == "image/pjpeg")) && ($_FILES["file2"]["size"] < 200000000000)) {
  if ($_FILES["file2"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file2"]["error"] . "<br />";
  } else {
      $_FILES["file2"]["name"]="adid".$advertsId."img2.jpg";
      move_uploaded_file($_FILES["file2"]["tmp_name"],
      "uploads/" . $_FILES["file2"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file3"]["name"]) > 0) {
if ((($_FILES["file3"]["type"] == "image/gif") || ($_FILES["file3"]["type"] == "image/jpeg")|| ($_FILES["file3"]["type"] == "image/pjpeg")) && ($_FILES["file3"]["size"] < 200000000000)) {
  if ($_FILES["file3"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file3"]["error"] . "<br />";
  } else {
      $_FILES["file3"]["name"]="adid".$advertsId."img3.jpg";
      move_uploaded_file($_FILES["file3"]["tmp_name"],
      "uploads/" . $_FILES["file3"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file4"]["name"]) > 0) {
if ((($_FILES["file4"]["type"] == "image/gif") || ($_FILES["file4"]["type"] == "image/jpeg")|| ($_FILES["file4"]["type"] == "image/pjpeg")) && ($_FILES["file4"]["size"] < 200000000000)) {
  if ($_FILES["file4"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file4"]["error"] . "<br />";
  } else {
      $_FILES["file4"]["name"]="adid".$advertsId."img4.jpg";
      move_uploaded_file($_FILES["file4"]["tmp_name"],
      "uploads/" . $_FILES["file4"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file5"]["name"]) > 0) {
if ((($_FILES["file5"]["type"] == "image/gif") || ($_FILES["file5"]["type"] == "image/jpeg")|| ($_FILES["file5"]["type"] == "image/pjpeg")) && ($_FILES["file5"]["size"] < 200000000000)) {
  if ($_FILES["file5"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file5"]["error"] . "<br />";
  } else {
      $_FILES["file5"]["name"]="adid".$advertsId."img5.jpg";
      move_uploaded_file($_FILES["file5"]["tmp_name"],
      "uploads/" . $_FILES["file5"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}

if (strlen($_FILES["file6"]["name"]) > 0) {
if ((($_FILES["file6"]["type"] == "image/gif") || ($_FILES["file6"]["type"] == "image/jpeg")|| ($_FILES["file6"]["type"] == "image/pjpeg")) && ($_FILES["file6"]["size"] < 200000000000)) {
  if ($_FILES["file6"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file6"]["error"] . "<br />";
  } else {
      $_FILES["file6"]["name"]="adid".$advertsId."img6.jpg";
      move_uploaded_file($_FILES["file6"]["tmp_name"],
      "uploads/" . $_FILES["file6"]["name"]);
  }
} else {
   $error = "Invalid file: Please upload only image files with .jpg extension.";
}
}



if (strlen($error) > 0) {
  $subtitle ="Error";
  $message = $error;
} else {
  $subtitle ="Thank you";
  $message ="Your ad has been posted.";
}

include "blank.php";

?>