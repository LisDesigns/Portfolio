<?
   session_start();
   include "header.php";
?>
<style type="text/css">
</style>
</head>
<body>
<div id="wrapper">
<center>
<table id="main">
<tr><td id="header" colspan="4"><a href="index.php"><img src="images/logo.jpg" alt="eDamaged" border="0" id="logo"/></a>
  <div id="menu"><center>
    <? include "menu.php"; ?>    </center>
  </div>
  </td>
</tr>
<tr>
  <td id="leftbg"></td>
  <td id="content1" rowspan="2">
    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px;overflow:hidden">
      <b style="color:white;">eDamaged Search</b>
      <form style="display:inline-block;margin-left:8px;margin-top:13px;" action="search.php" method="post">
        <input type="hidden" value="all" name="category"/>
        <table>
        <tr><td><b>Colour</b>:</td><td><select name="colour"><option>Any</option><option>Black</option><option>Blue</option><option>Red</option><option>Green</option><option>Other</option></select></td></tr>
        <tr><td><b>Transmission</b>:</td><td><select name="transmission"><option>Any</option><option>Automatic</option><option>Manual</option></select></td></tr>
        <tr><td><b>Price</b>:</td><td><select name="price"><option>Any</option><option>$1-$2000</option><option>$2001-$5000</option><option>$5001-$10000</option><option>$10001-$15000</option><option>$15001-$25000</option><option>$25001+</option></select></td></tr>
        <tr><td><b>Condition</b>:</td><td><select name="condition"><option>Any</option><option>New</option><option>Used</option></select></td></tr>
        <tr><td><b>Keywords</b>:</td><td><input type="text" name="keywords"/></td></tr>
        <tr><td><small style="display:block;padding-top:5px"><a href="advancedsearch.php">Advanced Search</a></small></td><td style="text-align:right!important"><input type="submit" value="Search" style="background-color:#29476f; color:rgb(220,220,220); font-family:verdana; font-size:10px; font-weight:bold; width:70px"></td></tr>
        </table>
      </form>
    </div>

    <div style="background-image:url(images/box.png);width:276px;height:184px;padding-left:9px; padding-top:8px">
      <b style="color:white">eDamaged Members</b>
      <br/><br/><br/>
      <table style="margin-left:8px">
      <tr><td width="100" style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt=""/><? 
      if (!$_SESSION["user"]) { echo '<a href="login.php" class="membericons">Login</a><br/><img src="images/icon3.png" alt=""/><a href="register.php" class="membericons">Register</a>'; 
      } else { echo '<a href="logout.php" class="membericons">Logout</a><br/><img src="images/icon3.png" alt=""/><a href="editprofile.php" class="membericons">Edit Profile</a>';
      } ?>
      <br/><img src="images/icon3.png" alt=""/><a href="postad.php"  class="membericons">Post an Ad</a>
      </td>
      <td style="vertical-align:middle!important;line-height:20px">
      <img src="images/icon3.png" alt="" /><a href="editads.php"  class="membericons">Edit an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="deleteads.php" class="membericons">Delete an Ad</a>
      <br/><img src="images/icon3.png" alt=""/><a href="viewads.php" class="membericons">View your Ads</a>
      </td>
      </tr>
      </table>

    </div>

  </td>
  <td id="content2" rowspan="2">

    <div id="featuredcar">
     
     
      <h1 style="display:inline-block;padding-left:0px">Contact Us</h1>
      <br/>
   <table>
<form action="sendmessage.php" method="post" style="display:inline">
<input type="hidden" name="itemname" value="Contact Us Form"/>
<input type="hidden" name="sellerid" value="13"/>
<tr><td>Name:</td><td style="text-align:right"><input type="text" name="firstname" style="width:150px"></td></tr>
<tr><td>Email:</td><td style="text-align:right"><input name="email" type="text" style="width:150px"></td></tr>
<tr><td>Message:</td><td style="text-align:right"><textarea style="width:150px" name="message"></textarea></td></tr>
<tr><td colspan="2" style="text-align:right"><input type="submit" style="width:100px;" value="Send" class="buttons"/>
</td></tr></table></form>
 <br/><br/><br/><br/><br/><br/><br/><br/>
     

    </div>

  </td><td id="rightbg"></td>
<tr>
  <td id="leftbg1"></td>
  <td id="rightbg1"></td>
</tr>
</tr>
<?
include "footer.php";
?>