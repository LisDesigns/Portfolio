<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Freight Forwarding Australia</title>
<style type="text/css">
    div#footer{color:#c8e0fc;rgb(175,175,175); margin-top:8px;padding-bottom:0px; margin-bottom:0px; font-size:12px;
       		font-weight:700; width:1003px; height:30px; line-height:30px;position:absolute; top:1116px; left:0px;}
    div#container1{position:absolute; top:0px; left:-1px; width:1003px; height:1126px;background-image:url(softblankbg2inside2.jpg)}
    table{border-collapse:collapse}
</style>
<?php include("header.html"); ?>
<h1><i>Make a Booking</i></h1>
<hr/>

   <div id="errorMessageDiv" style="color:red; font-weight:bold;"></div>
   <form name="makeabooking" method="post" action="processBooking.php">
<table>
   <tr><td width="300" valign="top" align="left">

   <h2>Sender Information</h2>
   <table>
     <tr><td width="130">&#42; Title: </td><td><input type="text" name="title"/></td></tr>
     <tr><td>&#42; First Name: </td><td><input type="text" name="firstname"/></td></tr>
     <tr><td>&#42; Last Name: </td><td><input type="text" name="lastname"/></td></tr>
     <tr><td>&nbsp; Company: </td><td><input type="text" name="company"/></td></tr>
     <tr><td>&#42; Address: </td><td><input type="text" name="address"/></td></tr>
     <tr><td>&#42; Suburb: </td><td><input type="text" name="suburb"/></td></tr>
     <tr><td>&#42; State: </td><td><input type="text" name="state"/></td></tr>
     <tr><td>&#42; Post Code: </td><td><input type="text" name="postcode"/></td></tr>
     <tr><td>&#42; Country: </td><td><input type="text" name="country"/></td></tr>
     <tr><td>&#42; Phone: </td><td>
         <input type="text" name="phone"/></td></tr>
     <tr><td>&nbsp; Mobile: </td><td><input type="text" name="mobile"/></td></tr>
     <tr><td>&nbsp; Fax: </td><td><input type="text" name="fax"/></td></tr>
     <tr><td>&#42; Email: </td><td><input type="text" name="email"/></td></tr>
   </table>

   </td><td valign="top" align="left" width="300">

   <h2>Destination Information</h2>
   <table>
     <tr><td width="130">&#42; Title: </td><td><input type="text" name="desttitle"/></td></tr>
     <tr><td>&#42; First Name: </td><td><input type="text" name="destfirstname"/></td></tr>
     <tr><td>&#42; Last Name: </td><td><input type="text" name="destlastname"/></td></tr>
     <tr><td>&nbsp; Company: </td><td><input type="text" name="destcompany"/></td></tr>
     <tr><td>&#42; Address: </td><td><input type="text" name="destaddress"/></td></tr>
     <tr><td>&#42; Suburb: </td><td><input type="text" name="destsuburb"/></td></tr>
     <tr><td>&#42; State: </td><td><input type="text" name="deststate"/></td></tr>
     <tr><td>&#42; Post Code: </td><td><input type="text" name="destpostcode"/></td></tr>
     <tr><td>&#42; Country: </td><td><input type="text" name="destcountry"/></td></tr>
     <tr><td>&#42; Phone: </td><td><input type="text" name="destphone"/></td></tr>
     <tr><td>&nbsp; Mobile: </td><td><input type="text" name="destmobile"/></td></tr>
     <tr><td>&nbsp; Fax: </td><td><input type="text" name="destfax"/></td></tr>
     <tr><td>&#42; Email: </td><td><input type="text" name="destemail"/></td></tr>
     </table>
   </td></tr>

   <tr><td valign="top" align="left" colspan="2">
     <br/>

   <h2>Shipment Information</h2>

<table width="300"><tr><td valign="top">
   <table align="left">
     <tr><td width="130">&#42; Cargo To Be Shipped:</td><td><input type="text" name="cargodescription"/></td></tr>
     <tr><td>&#42; Quantity:</td><td><input type="text" name="quantity"/></td></tr>
     <tr><td>&#42; Weight:</td><td><input type="text" name="weight"/></td></tr>
     <tr><td valign="top">&#42; Container:</td><td>
        <select name="containersize" style="width:143">
	<option>Please select size</option>
	<option>20ft GP</option>
	<option>20ft Open Top</option>
	<option>40ft GP</option>
	<option>40ft High Cube</option>
	<option>40ft Open Top</option>
	</select>
     <tr><td>&#42; Weight Bridge Ticket:</td><td><input type="radio" name="weightbridge" value="Yes"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No"/>No</td></tr>
     <tr><td>&#42; Door Facing:</td><td><input type="radio" name="doorfacing" value="Front"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back"/>Back</td></tr>
   </table>
</td><td valign="top" align="left">
   <table >
      <tr><td width="120">&#42; Declared Value:</td><td><input type="text" name="declaredvalue"/></td></tr>
      <tr><td>&#42; Insurance Required:</td><td><input type="radio" name="insurance" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"/>No</td></tr>
      <tr><td>&#42; Dangerous Goods:</td><td><input type="radio" name="dangerousgoods" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No"/>No</td></tr>
      <tr><td>&#42; Quoted Freight Charge:</td><td valign="bottom"><input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$</td></tr>
      <tr><td>&#42; Delivery Date:</td><td><input type="text" name="deliverydate"/></td></tr>
      <tr><td>&#42; Delivery Time:</td><td><input type="text" name="deliverytime"/></td></tr>
   </table>

</td></tr>
  
   <tr><td colspan="2">
   <br/><br/>Details/Special Instructions:</td></tr>
   <tr><td colspan="2"><textarea name="instructions" style="width:582px; height:70px; font-family:arial"></textarea></td></tr>
   <tr><td><br/><input type="reset" value="Clear" style="width:60px"/></td><td align="right">
       <br/><div id="submitDiv" style="text-align:right; width:211px"><input type="submit" value="Submit Booking" style="width:110px; margin-right:6px"/></div></td></tr>
  </td></tr>
</table> 

   </td></tr>
   </table>
   </form>
<script language="JavaScript1.2" type="text/javascript" src="validateForm.js"></script>
<?php include("footer.html"); ?>