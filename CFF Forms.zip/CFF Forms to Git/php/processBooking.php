<?php

//**********Get Values************

   // Sender

   $Title = $_REQUEST['title'];
   $FirstName = $_REQUEST['firstname'];
   $LastName = $_REQUEST['lastname'];
   $Company = $_REQUEST['company'];
   $Position = $_REQUEST['position'];
   $Address = $_REQUEST['address'];
   $Suburb = $_REQUEST['suburb'];
   $State = $_REQUEST['state'];
   $PostCode = $_REQUEST['postcode'];
   $Country = $_REQUEST['country'];
   $PhoneNumber = $_REQUEST['phone'];
   $Mobile = $_REQUEST['mobile'];
   $FaxNumber = $_REQUEST['fax'];
   $Email = $_REQUEST['email'];

   // Destination

   $DestTitle = $_REQUEST['desttitle'];
   $DestFirstName = $_REQUEST['destfirstname'];
   $DestLastName = $_REQUEST['destlastname'];
   $DestCompany = $_REQUEST['destcompany'];
   $DestPosition = $_REQUEST['destposition'];
   $DestAddress = $_REQUEST['destaddress'];
   $DestSuburb = $_REQUEST['destsuburb'];
   $DestState = $_REQUEST['deststate'];
   $DestPostCode = $_REQUEST['destpostcode'];
   $DestCountry = $_REQUEST['destcountry'];
   $DestPhoneNumber = $_REQUEST['destphone'];
   $DestMobile = $_REQUEST['destmobile'];
   $DestFaxNumber = $_REQUEST['destfax'];
   $DestEmail = $_REQUEST['destemail'];

   // Shipping Information

   $Cargodescription = $_REQUEST['cargodescription'];
   $Quantity = $_REQUEST['quantity'];
   $Weight = $_REQUEST['weight'];
   $Containersize = $_REQUEST['containersize'];
   $Weightbridge = $_REQUEST['weightbridge'];
   $Doorfacing = $_REQUEST['doorfacing'];
   $Declaredvalue = $_REQUEST['declaredvalue'];
   $Insurance = $_REQUEST['insurance'];
   $Dangerousgoods = $_REQUEST['dangerousgoods'];
   $Currency = $_REQUEST['currency'];
   $Deliverytime = $_REQUEST['deliverytime'];
   $Deliverydate = $_REQUEST['deliverydate'];
   $Instructions = $_REQUEST['instructions']; 

   include("validateForm.php");
   
    //*********Format Values***********
/*
   $Title = removeUnsafeChars($Title);
   $Title = trimValues($Title);
   $ValidateEmail = validateEmail($Email);
   $ValidatePhoneCode = checkDigits($PhoneCode);
   $Fax = "(".$FaxCode.") ".$FaxNumber;
   $Phone = "(".$PhoneCode.") ".$PhoneNumber;
   $Title_slashed = addslashes($Title);
*/
   
   $Title = removeUnsafeChars($Title);
   $FirstName = removeUnsafeChars($FirstName);
   $LastName = removeUnsafeChars($LastName);
   $Company = removeUnsafeChars($Company);
   $Position = removeUnsafeChars($Position);
   $Address = removeUnsafeChars($Address);
   $Suburb = removeUnsafeChars($Suburb);
   $State = removeUnsafeChars($State);
   $PostCode = removeUnsafeChars($PostCode);
   $Country = removeUnsafeChars($Country);
   $PhoneNumber = removeUnsafeChars($PhoneNumber);
   $Mobile = removeUnsafeChars($Mobile);
   $FaxNumber = removeUnsafeChars($FaxNumber);
   $Email = removeUnsafeChars($Email);
   
   // Destination

   $DestTitle = removeUnsafeChars($DestTitle];
   $DestFirstName = removeUnsafeChars($DestFirstName);
   $DestLastName = removeUnsafeChars($DestLastName);
   $DestCompany = removeUnsafeChars($DestCompany);
   $DestPosition = removeUnsafeChars($DestPosition);
   $DestAddress = removeUnsafeChars($DestAddress);
   $DestSuburb = removeUnsafeChars($DestSuburb);
   $DestState = removeUnsafeChars($DestState);
   $DestPostCode = removeUnsafeChars($DestPostCode);
   $DestCountry = removeUnsafeChars($DestCountry);
   $DestPhoneNumber = removeUnsafeChars($DestPhoneNumber);
   $DestMobile = removeUnsafeChars($DestMobile);
   $DestFaxNumber = removeUnsafeChars($DestFaxNumber);
   $DestEmail = removeUnsafeChars($DestEmail);

   // Shipping Information

   $Cargodescription = removeUnsafeChars($Cargodescription);
   $Quantity = removeUnsafeChars($Quantity);
   $Weight = removeUnsafeChars($Weight);
   $Containersize = removeUnsafeChars($Containersize);
   $Weightbridge = removeUnsafeChars($Weightbridge);
   $Doorfacing = removeUnsafeChars($Doorfacing);
   $Declaredvalue = removeUnsafeChars($Declaredvalue);
   $Insurance = removeUnsafeChars($Insurance);
   $Dangerousgoods = removeUnsafeChars($Dangerousgoods);
   $Currency = removeUnsafeChars($Currency);
   $Deliverytime = removeUnsafeChars($Deliverytime);
   $Deliverydate = removeUnsafeChars($Deliverydate);
   $Instructions = removeUnsafeChars($Instructions); 
      
   $Title = trimValues($Title);
   $FirstName = trimValues($FirstName);
   $LastName = trimValues($LastName);
   $Company = trimValues($Company);
   $Position = trimValues($Position);
   $Address = trimValues($Address);
   $Suburb = trimValues($Suburb);
   $State = trimValues($State);
   $PostCode = trimValues($PostCode);
   $Country = trimValues($Country);
   $PhoneNumber = trimValues($PhoneNumber);
   $Mobile = trimValues($Mobile);
   $FaxNumber = trimValues($FaxNumber);
   $Email = trimValues($Email);
   
   // Destination

   $DestTitle = trimValues($DestTitle);
   $DestFirstName = trimValues($DestFirstName);
   $DestLastName = trimValues($DestLastName);
   $DestCompany = trimValues($DestCompany);
   $DestPosition = trimValues($DestPosition);
   $DestAddress = trimValues($DestAddress);
   $DestSuburb = trimValues($DestSuburb);
   $DestState = trimValues($DestState);
   $DestPostCode = trimValues($DestPostCode);
   $DestCountry = trimValues($DestCountry);
   $DestPhoneNumber = trimValues($DestPhoneNumber);
   $DestMobile = trimValues($DestMobile);
   $DestFaxNumber = trimValues($DestFaxNumber);
   $DestEmail = trimValues($DestEmail);

   // Shipping Information

   $Cargodescription = trimValues($Cargodescription);
   $Quantity = trimValues($Quantity);
   $Weight = trimValues($Weight);
   $Containersize = trimValues($Containersize);
   $Weightbridge = trimValues($Weightbridge);
   $Doorfacing = trimValues($Doorfacing);
   $Declaredvalue = trimValues($Declaredvalue);
   $Insurance = trimValues($Insurance);
   $Dangerousgoods = trimValues($Dangerousgoods);
   $Currency = trimValues($Currency);
   $Deliverytime = trimValues($Deliverytime);
   $Deliverydate = trimValues($Deliverydate);
   $Instructions = trimValues($Instructions); 
   
   $PostCode = checkDigits($PostCode);
   $PhoneNumber = checkDigits($PhoneNumber);
   $Mobile = checkDigits($Mobile);
   $FaxNumber = checkDigits($FaxNumber);
   $Email = checkDigits($Email);
   
   //********Validate Values***********

   if (empty($Title) || empty($FirstName) || empty($LastName) || empty($Address) || 
       empty($Suburb) || empty($State) || empty($PostCode) || empty($Country) || 
       empty($PhoneNumber) || empty($Email)) {
         $errorMessage .= " &#45; Please enter all fields marked with an asterisk(*).<br/>";
   } 

   if ($ValidateEmail) {
     $errorMessage .= " &#45; Please enter a valid email address.<br/>";
   } 

   if (($ValidatePhoneCode && (strlen($ValidatePhoneCode) > 0)) || 
   ($ValidatePhoneNumber && (strlen($ValidatePhoneNumber) > 0)) ||
   ($ValidateMobile && (strlen($ValidateMobile) >0)) ||
   ($ValidateFaxCode && (strlen($ValidateFaxCode) > 0)) || 
   ($ValidateFaxNumber && (strlen($ValidateFaxNumber) > 0)) ||
   ($ValidatePostCode && (strlen($ValidatePostCode) > 0))){
     $errorMessage .= " &#45; Please enter only numbers in the phone, mobile, fax and post code fields.<br/>";
   } 
      
   if ($errorMessage != "") {
     include "blankpage.php";
   } else {

   //echo $errorMessage;
   // if valid - proceed
   // if not valid, rewrite page, by using include.  
   
//***********Send Email***********

   $message = "NEW CFF BOOKING\n\n".
                    "Sender Information\n\n".
                    "Title: ".$Title."\n".
                    "First Name: ".$FirstName."\n".
                    "Last Name: ".$LastName."\n".
                    "Company: ".$Company."\n".
                    "Address: ".$Address."\n".
                    "Suburb: ".$Suburb."\n".
                    "State: ".$State."\n".
                    "Post Code: ".$PostCode."\n".
                    "Country: ".$Country."\n".
                    "Phone: ".$PhoneNumber."\n".
                    "Mobile: ".$Mobile."\n".
                    "Fax: ".$FaxNumber."\n".
                    "Email: ".$Email."\n".
                    "\nDestination Information\n\n".
                    "Title: ".$DestTitle."\n".
                    "First Name: ".$DestFirstName."\n".
                    "Last Name: ".$DestLastName."\n".
                    "Company: ".$DestCompany."\n".
                    "Address: ".$DestAddress."\n".
                    "Suburb: ".$DestSuburb."\n".
                    "State: ".$DestState."\n".
                    "Post Code: ".$DestPostCode."\n".
                    "Country: ".$DestCountry."\n".
                    "Phone: ".$DestPhoneNumber."\n".
                    "Mobile: ".$DestMobile."\n".
                    "Fax: ".$DestFaxNumber."\n".
                    "Email: ".$DestEmail."\n".
                    "\nShipping Information\n\n".
                    "Cargo Description: ".$Cargodescription."\n".
                    "Quantity: ".$Quantity."\n".
                    "Weight: ".$Weight."\n".
                    "Container Size: ".$Containersize."\n".
                    "Weight Bridge: ".$Weightbridge."\n".
                    "Door Facing: ".$Doorfacing."\n".
                    "Declared value: ".$Declaredvalue."\n".
                    "Insurance: ".$Insurance."\n".
                    "Dangerous Goods: ".$Dangerousgoods."\n".
                    "Currency: ".$Currency."\n".
                    "Delivery Time: ".$Deliverytime."\n".
                    "Delivery Date: ".$Deliverydate."\n".
                    "Instructions: ".$Instructions;

  //mail("lisa@lisdesigns.com.au", "CFF - Make a Booking", $message, "From: ".$Email);

  mail("enquiries@changefreight.com.au", "CFF - Make a Booking", $message, "From: ".$Email);
  
  header( "Location: http://www.changefreight.com.au/thankyou.php" );
  
}
?>
