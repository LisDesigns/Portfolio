   <br/>
   <div id="errorMessageDiv" style="color:red; font-weight:bold;"></div>
   <form name="openaccount" method="post" action="processForm.php">
    <table>
      <tr><td width="130">&#42; Title: </td><td><input type="text" name="title" value="<?php echo $Title; ?>" /></td></tr>
      <tr><td>&#42; First Name: </td><td><input type="text" name="firstname"  value="<?php echo $FirstName; ?>" /></td></tr>
      <tr><td>&#42; Last Name: </td><td><input type="text" name="lastname"  value="<?php echo $LastName; ?>" /></td></tr>
      <tr><td>&nbsp; Company: </td><td><input type="text" name="company"  value="<?php echo $Company; ?>" /></td></tr>
      <tr><td>&nbsp; Position: </td><td><input type="text" name="position"  value="<?php echo $Position; ?>" /></td></tr>
      <tr><td>&#42; Address: </td><td><input type="text" name="address" value="<?php echo $Address; ?>" /></td></tr>
      <tr><td>&#42; Suburb: </td><td><input type="text" name="suburb" value="<?php echo $Suburb; ?>"/></td></tr>
      <tr><td>&#42; State: </td><td><input type="text" name="state" value="<?php echo $State; ?>"/></td></tr>
      <tr><td>&#42; Post Code: </td><td><input type="text" name="postcode" value="<?php echo $PostCode; ?>"/></td></tr>
      <tr><td>&#42; Country: </td><td><input type="text" name="country" value="<?php echo $Country; ?>"/></td></tr>
      <tr><td>&#42; Phone: </td><td><input type="text" name="phone_code" style="width:30px!important" value="<?php echo $PhoneCode; ?>"/>
                        <input type="text" name="phone" style="width:161px!important" value="<?php echo $PhoneNumber; ?>"/></td></tr>
      <tr><td>&nbsp; Mobile: </td><td><input type="text" name="mobile" value="<?php echo $Mobile; ?>"/></td></tr>
      <tr><td>&nbsp; Fax: </td><td><input type="text" name="fax_code" style="width:30px!important" value="<?php echo $FaxCode; ?>"/>
          <input type="text" name="fax" style="width:161px!important" value="<?php echo $FaxNumber; ?>"/></td></tr>
      <tr><td>&#42; Email: </td><td><input type="text" name="email" value="<?php echo $Email; ?>"/></td></tr>
      <tr><td colspan="2">&#42; Preferred Contact Method: </td>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp; 
                           &nbsp;   &nbsp;
               <input type="radio" name="contact" style="width:30px!important" value="Phone" 
<?php

 if($PreferredContactMethod == "Phone") {
    echo "checked";
 }

?>

/>Phone</td></tr>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;
                           <input type="radio" name="contact" style="width:30px!important" value="Email" 

<?php

 if($PreferredContactMethod == "Email") {
    echo "checked";
 }

?>

/>Email</td></tr>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   
                           &nbsp;   &nbsp;
<input type="radio" name="contact" style="width:30px!important" value="Fax"

<?php

 if($PreferredContactMethod == "Fax") {
    echo "checked";
 }

?>


/>Fax</td></tr>
      <tr><td colspan="2"><br/>&nbsp; Comments: </td></tr>
      <tr><td colspan="2"><textarea name="comments" style="width:340px; height:70px; font-family:arial"><?php echo $Comments; ?></textarea></td></tr>
       <tr><td><br/><input type="reset" value="Clear" style="width:60px"/></td><td align="left">
          <br/><div id="submitDiv" style="text-align:right; width:211px"><input type="submit" value="Register" style="width:60px"/></div></td></tr>
    </table>
   </form>