<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Freight Forwarding Australia</title>
<style type="text/css">
    div#footer{color:#c8e0fc;rgb(175,175,175); margin-top:8px;padding-bottom:0px; margin-bottom:0px; font-size:12px;       		font-weight:700; width:1003px; height:30px; line-height:30px;position:absolute; top:1086px; left:0px;}
    div#container1{position:absolute; top:0px; left:-1px; width:1003px; height:1100px;background-image:url(softblankbg2inside2.jpg)}
    table{border-collapse:collapse}
</style>
<?php include("header.html"); ?>

<h1><i>Request a Quote</i></h1>
<hr/>
   <br/>
   <div id="errorMessageDiv" style="color:red; font-weight:bold;"></div>
   <form name="openaccount" method="post" action="processQuote.php">
   <table>
   <tr><td width="300" valign="top" align="left">

   <h2>Contact Information</h2>
   <table>
     <tr><td width="130">&#42; Title: </td><td><input type="text" name="title" value="<?php echo $Title; ?>" /></td></tr>
      <tr><td>&#42; First Name: </td><td><input type="text" name="firstname" value="<?php echo $FirstName; ?>" /></td></tr>
      <tr><td>&#42; Last Name: </td><td><input type="text" name="lastname" value="<?php echo $LastName; ?>" /></td></tr>
      <tr><td>&nbsp; Company: </td><td><input type="text" name="company"  value="<?php echo $Company; ?>" /></td></tr>
      <tr><td>&nbsp; Position: </td><td><input type="text" name="position"  value="<?php echo $Position; ?>" /></td></tr>
      <tr><td>&#42; Address: </td><td><input type="text" name="address" value="<?php echo $Address; ?>" /></td></tr>
      <tr><td>&#42; Suburb: </td><td><input type="text" name="suburb" value="<?php echo $Suburb; ?>"/></td></tr>
      <tr><td>&#42; State: </td><td><input type="text" name="state" value="<?php echo $State; ?>"/></td></tr>
      <tr><td>&#42; Post Code: </td><td><input type="text" name="postcode" value="<?php echo $PostCode; ?>"/></td></tr>
      <tr><td>&#42; Country: </td><td><input type="text" name="country" value="<?php echo $Country; ?>"/></td></tr>
      <tr><td>&#42; Phone: </td><td><input type="text" name="phone_code" style="width:30px!important" value="<?php echo $PhoneCode; ?>"/>
      <input type="text" name="phone" style="width:161px!important" value="<?php echo $PhoneNumber; ?>"/></td></tr>
      <tr><td>&nbsp; Mobile: </td><td><input type="text" name="mobile" value="<?php echo $Mobile; ?>"/></td></tr>
      <tr><td>&nbsp; Fax: </td><td><input type="text" name="fax_code" style="width:30px!important" value="<?php echo $FaxCode; ?>"/>
          <input type="text" name="fax" style="width:161px!important" value="<?php echo $FaxNumber; ?>"/></td></tr>
      <tr><td>&#42; Email: </td><td><input type="text" name="email" value="<?php echo $Email; ?>"/></td></tr>
   </table>

   </td><td valign="top" align="left" width="300">

   <h2>General Information</h2>
   <table>
     <tr><td width="130">&#42; Sender Address: </td></tr>
         <tr><td><textarea name="originaddress" style="height:60px; width:280px"><?php echo $OriginAddress; ?>
   </textarea></td></tr>
     <tr><td>&#42; Destination Address: </td></tr>
         <tr><td><textarea name="destinationaddress" style="height:60px; width:280px"><?php echo $DestinationAddress; ?></textarea></td></tr>
     
     </table>
   </td></tr>

   <tr><td valign="top" align="left" colspan="2">
     <br/>

   <h2>Shipment Information</h2>
   <span style="color:#4066af">Please <a href="tools.php#conversion" target="_blank" style="color:#4066af">click here</a> for weight, length and currency conversion tools (to open in a separate window).</span>
   <br/><br/>

<table width="300"><tr><td valign="top">

   <table align="left">

     <tr><td width="130">&#42; Cargo To Be Shipped:</td><td><input type="text" name="cargodescription" value="<?php echo $Cargodescription;?>"/></td></tr>
     <tr><td width="130">Length:</td><td><input type="text" name="length" value="<?php echo $Length;?>"/></td></tr>
     <tr><td>Width: </td><td><input type="text" name="width" value="<?php echo $Width;?>"/></td></tr>
     <tr><td>Height: </td><td><input type="text" name="height" value="<?php echo $Height; ?>"/></td></tr>
     <tr><td>&#42; Weight:</td><td><input type="text" name="weight" value="<?php echo $Weight; ?>"/></td></tr>
     <tr><td valign="top">&#42; Container:</td><td><?php echo $Containersize;?>
        <select name="containersize" style="width:143">
		<?php
    if ($Containersize == "") {
	  echo '<option>Please select size</option>';
	} else if ($Containersize != "20ft GP") {
	  echo '<option selected="selected">20ft GP</option>';
	} else if ($Containersize != "20ft Open Top") {
	  echo '<option selected="selected">20ft Open Top</option>';
	} else if ($Containersize != "40ft GP") {
	  echo '<option selected="selected">40ft GP</option>';
	} else if ($Containersize != "") {
	  echo '<option selected="selected">40ft High Cube</option>';
	} else if ($Containersize != "") {
	  echo '<option selected="selected">40ft Open Top</option>';
    } else {
	  echo '<option>Please select size</option>
	  <option>20ft GP</option>
	  <option>20ft Open Top</option>
	  <option>40ft GP</option>
	  <option>40ft High Cube</option>
	  <option>40ft Open Top</option>';
	}
	?>
	</select>
     </td></tr>
     <tr><td>&#42; Quantity:</td><td><input type="text" name="quantity"  value="<?php echo $Quantity;?>"/></td></tr>
     <tr><td>&#42; Door Facing:</td><td>
	<?php echo $Doorfacing; 
	 	if($Doorfacing == "Front") {
		echo '<input type="radio" name="doorfacing" value="Front" selected="selected" checked="checked"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back"/>Back';
	 	} if else($Doorfacing == "Back"){
		echo '<input type="radio" name="doorfacing" value="Front"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back" selected="selected" checked="checked"/>Back';
		} else {
		echo '<input type="radio" name="doorfacing" value="Front"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back"/>Back';
		}
	 ?> 
	 </td></tr>

   </table>
   </td><td valign="top" align="left">
   <table >
     <tr><td>&#42; Weight Bridge Ticket:</td><td> <?php 
		if($Weightbridge == "Yes") {
		echo '<input type="radio" name="weightbridge" value="Yes" selected="selected" checked="checked"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No"/>No';
		} if else($Weightbridge == "No"){
		echo '<input type="radio" name="weightbridge" value="Yes"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No" selected="selected" checked="checked"/>No';
		} else {
		echo '<input type="radio" name="weightbridge" value="Yes"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No"/>No';
		}
	 ?></td></tr>
     <tr><td width="120">&#42; Declared Value:</td><td><input type="text" name="declaredvalue" value="<?php echo $Declaredvalue;?>"/></td></tr>
     <tr><td>&#42; Insurance Required:</td><td>
	 <?php 
	  if($Insurance == "Yes") {
	  echo '<input type="radio" name="insurance" value="Yes" selected="selected" checked="checked"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"/>No';
	  } else if ($Insurance == "No") {
	  echo '<input type="radio" name="insurance" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"  selected="selected" checked="checked"/>No';
	  } else {
	  echo '<input type="radio" name="insurance" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"/>No';
	  }
	?>
	 </td></tr>
     <tr><td>&#42; Dangerous Goods:</td><td>
	 <?php 
	 	if($Dangerousgoods == "Yes") {
		echo '<input type="radio" name="dangerousgoods" value="Yes" selected="selected" checked="checked"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No"/>No';
		} if else($Dangerousgoods == "No"){
		echo '<input type="radio" name="dangerousgoods" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No" selected="selected" checked="checked"/>No';
		} else {
		echo '<input type="radio" name="dangerousgoods" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No"/>No';
		} 
	 ?></td></tr>
     <tr><td>&#42; Quoted Freight Charge:</td><td valign="bottom">	  
	 <?php
      if ($Currency == "AUD") {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  } else if ($Currency == "USD") {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  } else {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  }
	  ?></td></tr>
     <tr><td>&#42; Delivery Date:</td><td><input type="text" name="deliverydate" value="<?php echo $Deliverydate;?>"/></td></tr>
     <tr><td valign="top">Mode:</td><td>
        <select name="mode" style="width:143">
		<?php
		if ($Mode == "LCL") {
		  echo '<option selected="selected">LCL</option>
			<option>FCL</option>
			<option>AIR</option>';
		} else if ($Mode == "FCL") {
		echo '<option selected="selected">FCL</option>
			<option>LCL</option>
			<option>AIR</option>';
		} else if ($Mode == "AIR"){
		echo '<option selected="selected">AIR</option>
			<option>LCL</option>
			<option>FCL</option>';
		} else {
		echo '<option>Please select option</option>
		<option>LCL</option>
		<option>FCL</option>
		<option>AIR</option>';
		}
		?>
	</select>
    </td></tr>
    <tr><td>Fumigation Required:</td><td>
	<?php 
	if ($Fumigation == "Yes") {
	echo '<input type="radio" name="fumigation" value="Yes" selected="selected" checked="checked"/>Yes  &nbsp; &nbsp; <input type="radio"name="fumigation" value="No"/>No';
	} else if ($Fumigation == "No") {
	echo '<input type="radio" name="fumigation" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="fumigation" value="No" selected="selected" checked="checked"/>No';
	} else {
	echo '<input type="radio" name="fumigation" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="fumigation" value="No"/>No';
	}
	?></td></tr>
   </table>
</td></tr>
   <tr><td colspan="2">
   <br/><br/>Comments/Questions:</td></tr>
   <tr><td colspan="2"><textarea name="comments" style="width:582px; height:70px; font-family:arial"><?php echo $Comments;?></textarea></td></tr>
   <tr><td><br/><input type="reset" value="Clear" style="width:60px"/></td><td align="right">
       <br/><div id="submitDiv" style="text-align:right; width:211px"><input type="submit" value="Request Quote" style="width:110px; margin-right:6px"/></div></td></tr>
  </td></tr>
</table> 
</td></tr>
</table>
</form>
<br/>
<script language="JavaScript1.2" type="text/javascript" src="validateForm.js"></script>
<?php include("footer.html"); ?>