<?php

//**********Get Values************

   // Sender

   $Title = $_REQUEST['title'];
   $FirstName = $_REQUEST['firstname'];
   $LastName = $_REQUEST['lastname'];
   $Company = $_REQUEST['company'];
   $Position = $_REQUEST['position'];
   $Address = $_REQUEST['address'];
   $Suburb = $_REQUEST['suburb'];
   $State = $_REQUEST['state'];
   $PostCode = $_REQUEST['postcode'];
   $Country = $_REQUEST['country'];
   $PhoneNumber = $_REQUEST['phone'];
   $Mobile = $_REQUEST['mobile'];
   $FaxNumber = $_REQUEST['fax'];
   $Email = $_REQUEST['email'];

   //  General Information

   $OriginAddress = $_REQUEST['originaddress'];
   $DestinationAddress = $_REQUEST['destinationaddress'];

   // Shipping Information

   $Cargodescription = $_REQUEST['cargodescription'];
   $Length = $_REQUEST['length'];
   $Width = $_REQUEST['width'];
   $Height = $_REQUEST['height'];
   $Weight = $_REQUEST['weight'];
   $Quantity = $_REQUEST['quantity'];
   $Containersize = $_REQUEST['containersize'];
   $Doorfacing = $_REQUEST['doorfacing'];
   $Weightbridge = $_REQUEST['weightbridge'];
   $Declaredvalue = $_REQUEST['declaredvalue'];
   $Insurance = $_REQUEST['insurance'];
   $Dangerousgoods = $_REQUEST['dangerousgoods'];
   $Currency = $_REQUEST['currency'];
   $Deliverydate = $_REQUEST['deliverydate'];
   $Mode = $_REQUEST['mode'];
   $Fumigation = $_REQUEST['fumigation'];
   $Comments = $_REQUEST['comments']; 

   include("validateForm.php");
   
   //*********Format Values***********
   /*
   $Title = removeUnsafeChars($Title);
   $Title = trimValues($Title);
   $ValidateEmail = validateEmail($Email);
   $ValidatePhoneCode = checkDigits($PhoneCode);
   $Fax = "(".$FaxCode.") ".$FaxNumber;
   $Phone = "(".$PhoneCode.") ".$PhoneNumber;
   $Title_slashed = addslashes($Title);
   */
 
   $Title = removeUnsafeChars($Title);
   $FirstName = removeUnsafeChars($FirstName);
   $LastName = removeUnsafeChars($LastName);
   $Company = removeUnsafeChars($Company);
   $Position = removeUnsafeChars($Position);
   $Address = removeUnsafeChars($Address);
   $Suburb = removeUnsafeChars($Suburb);
   $State = removeUnsafeChars($State);
   $PostCode = removeUnsafeChars($PostCode);
   $Country = removeUnsafeChars($Country);
   $PhoneNumber = removeUnsafeChars($PhoneNumber);
   $Mobile = removeUnsafeChars($Mobile);
   $FaxNumber = removeUnsafeChars($FaxNumber);
   $Email = removeUnsafeChars($Email);
   
      //  General Information

   $OriginAddress = removeUnsafeChars(originaddress);
   $DestinationAddress = removeUnsafeChars(destinationaddress);

   // Shipping Information

   $Cargodescription = removeUnsafeChars($Cargodescription);
   $Length = removeUnsafeChars($Length);
   $Width = removeUnsafeChars($Width);
   $Height = removeUnsafeChars($Height);
   $Weight = removeUnsafeChars($Weight);
   $Quantity = removeUnsafeChars($Quantity);
   $Containersize = removeUnsafeChars($Containersize);
   $Doorfacing = removeUnsafeChars($Doorfacing);
   $Weightbridge = removeUnsafeChars($Weightbridge);
   $Declaredvalue = removeUnsafeChars($Declaredvalue);
   $Insurance = removeUnsafeChars($Insurance);
   $Dangerousgoods = removeUnsafeChars($Dangerousgoods);
   $Currency = removeUnsafeChars($Currency);
   $Deliverydate = removeUnsafeChars($Deliverydate);
   $Mode = removeUnsafeChars($Mode);
   $Fumigation = removeUnsafeChars($Fumigation);
   $Comments = removeUnsafeChars($Comments); 
   
   $Title = trimValues($Title);
   $FirstName = trimValues($FirstName);
   $LastName = trimValues($LastName);
   $Company = trimValues($Company);
   $Position = trimValues($Position);
   $Address = trimValues($Address);
   $Suburb = trimValues($Suburb);
   $State = trimValues($State);
   $PostCode = trimValues($PostCode);
   $Country = trimValues($Country);
   $PhoneNumber = trimValues($PhoneNumber);
   $Mobile = trimValues($Mobile);
   $FaxNumber = trimValues($FaxNumber);
   $Email = trimValues($Email);
   
      //  General Information

   $OriginAddress = trimValues(originaddress);
   $DestinationAddress = trimValues(destinationaddress);

   // Shipping Information

   $Cargodescription = trimValues($Cargodescription);
   $Length = trimValues($Length);
   $Width = trimValues($Width);
   $Height = trimValues($Height);
   $Weight = trimValues($Weight);
   $Quantity = trimValues($Quantity);
   $Containersize = trimValues($Containersize);
   $Doorfacing = trimValues($Doorfacing);
   $Weightbridge = trimValues($Weightbridge);
   $Declaredvalue = trimValues($Declaredvalue);
   $Insurance = trimValues($Insurance);
   $Dangerousgoods = trimValues($Dangerousgoods);
   $Currency = trimValues($Currency);
   $Deliverydate = trimValues($Deliverydate);
   $Mode = trimValues($Mode);
   $Fumigation = trimValues($Fumigation);
   $Comments = trimValues($Comments); 
   
   $PostCode = checkDigits($PostCode);
   $PhoneNumber = checkDigits($PhoneNumber);
   $Mobile = checkDigits($Mobile);
   $FaxNumber = checkDigits($FaxNumber);
   $Email = checkDigits($Email);
   
   //********Validate Values***********

   if (empty($Title) || empty($FirstName) || empty($LastName) || empty($Address) || 
       empty($Suburb) || empty($State) || empty($PostCode) || empty($Country) || 
       empty($PhoneNumber) || empty($Email)) {
         $errorMessage .= " &#45; Please enter all fields marked with an asterisk(*).<br/>";
   } 

   if ($ValidateEmail) {
     $errorMessage .= " &#45; Please enter a valid email address.<br/>";
   } 

   if (($ValidatePhoneCode && (strlen($ValidatePhoneCode) > 0)) || 
   ($ValidatePhoneNumber && (strlen($ValidatePhoneNumber) > 0)) ||
   ($ValidateMobile && (strlen($ValidateMobile) >0)) ||
   ($ValidateFaxCode && (strlen($ValidateFaxCode) > 0)) || 
   ($ValidateFaxNumber && (strlen($ValidateFaxNumber) > 0)) ||
   ($ValidatePostCode && (strlen($ValidatePostCode) > 0))){
     $errorMessage .= " &#45; Please enter only numbers in the phone, mobile, fax and post code fields.<br/>";
   } 
      
   if ($errorMessage != "") {
     include "blankpage.php";
   } else {
   
   
   
   
   
//***********Send Email***********

   $message = "CFF QUOTE REQUEST\n\n".
                    "Contact Information\n\n".
                    "Title: ".$Title."\n".
                    "First Name: ".$FirstName."\n".
                    "Last Name: ".$LastName."\n".
                    "Company: ".$Company."\n".
                    "Phone: ".$PhoneNumber."\n".
                    "Mobile: ".$Mobile."\n".
                    "Fax: ".$FaxNumber."\n".
                    "Email: ".$Email."\n".

                    "\nGeneral Information\n\n".
                    "Origin Address: ".$OriginAddress."\n".
                    "Destination Address: ".$DestinationAddress."\n".

                    "\nShipping Information\n\n".
                    "Cargo Description: ".$Cargodescription."\n".
                    "Length: ".$Length."\n".
                    "Width: ".$Width."\n".
                    "Height: ".$Height."\n".
                    "Weight: ".$Weight."\n".
                    "Quantity: ".$Quantity."\n".
                    "Container Size: ".$Containersize."\n".
                    "Door Facing: ".$Doorfacing."\n".
                    "Weight Bridge: ".$Weightbridge."\n".
                    "Declared value: ".$Declaredvalue."\n".
                    "Insurance: ".$Insurance."\n".
                    "Dangerous Goods: ".$Dangerousgoods."\n".
                    "Currency: ".$Currency."\n".
                    "Delivery Date: ".$Deliverydate."\n".
                    "Mode: ".$Mode."\n".
                    "Fumigation: ".$Fumigation."\n".
                    "Comments: ".$Comments;


  //mail("lisa@lisdesigns.com.au", "CFF - REQUEST QUOTE", $message, "From: ".$Email);

  mail("enquiries@changefreight.com.au", "CFF - REQUEST QUOTE", $message, "From: ".$Email);

  header( "Location: http://www.changefreight.com.au/thankyou.php" );
  
  }
?>
