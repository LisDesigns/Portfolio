<h1><i>Make a Booking</i></h1>
<hr/>

   <div id="errorMessageDiv" style="color:red; font-weight:bold;"></div>
   <form name="makeabooking" method="post" action="processBooking.php">
<table>
   <tr><td width="300" valign="top" align="left">

   <h2>Sender Information</h2>
   <table>
      <tr><td width="130">&#42; Title: </td><td><input type="text" name="title" value="<?php echo $Title; ?>" /></td></tr>
      <tr><td>&#42; First Name: </td><td><input type="text" name="firstname"  value="<?php echo $FirstName; ?>" /></td></tr>
      <tr><td>&#42; Last Name: </td><td><input type="text" name="lastname"  value="<?php echo $LastName; ?>" /></td></tr>
      <tr><td>&nbsp; Company: </td><td><input type="text" name="company"  value="<?php echo $Company; ?>" /></td></tr>
      <tr><td>&nbsp; Position: </td><td><input type="text" name="position"  value="<?php echo $Position; ?>" /></td></tr>
      <tr><td>&#42; Address: </td><td><input type="text" name="address" value="<?php echo $Address; ?>" /></td></tr>
      <tr><td>&#42; Suburb: </td><td><input type="text" name="suburb" value="<?php echo $Suburb; ?>"/></td></tr>
      <tr><td>&#42; State: </td><td><input type="text" name="state" value="<?php echo $State; ?>"/></td></tr>
      <tr><td>&#42; Post Code: </td><td><input type="text" name="postcode" value="<?php echo $PostCode; ?>"/></td></tr>
      <tr><td>&#42; Country: </td><td><input type="text" name="country" value="<?php echo $Country; ?>"/></td></tr>
      <tr><td>&#42; Phone: </td><td><input type="text" name="phone_code" style="width:30px!important" value="<?php echo $PhoneCode; ?>"/>
      <input type="text" name="phone" style="width:161px!important" value="<?php echo $PhoneNumber; ?>"/></td></tr>
      <tr><td>&nbsp; Mobile: </td><td><input type="text" name="mobile" value="<?php echo $Mobile; ?>"/></td></tr>
      <tr><td>&nbsp; Fax: </td><td><input type="text" name="fax_code" style="width:30px!important" value="<?php echo $FaxCode; ?>"/>
          <input type="text" name="fax" style="width:161px!important" value="<?php echo $FaxNumber; ?>"/></td></tr>
      <tr><td>&#42; Email: </td><td><input type="text" name="email" value="<?php echo $Email; ?>"/></td></tr>
   </table>

   </td><td valign="top" align="left" width="300">

   <h2>Destination Information</h2>
   <table>
     <tr><td width="130">&#42; Title: </td><td><input type="text" name="desttitle" value="<?php echo $Desttitle; ?>"/></td></tr>
     <tr><td>&#42; First Name: </td><td><input type="text" name="destfirstname" value="<?php echo $Destfirstname; ?>"/></td></tr>
     <tr><td>&#42; Last Name: </td><td><input type="text" name="destlastname" value="<?php echo $Destlastname; ?>"/></td></tr>
     <tr><td>&nbsp; Company: </td><td><input type="text" name="destcompany" value="<?php echo $Company; ?>"/></td></tr>
     <tr><td>&#42; Address: </td><td><input type="text" name="destaddress" value="<?php echo $Destaddress; ?>"/></td></tr>
     <tr><td>&#42; Suburb: </td><td><input type="text" name="destsuburb" value="<?php echo $Destsuburb; ?>"/></td></tr>
     <tr><td>&#42; State: </td><td><input type="text" name="deststate" value="<?php echo $Deststate; ?>"/></td></tr>
     <tr><td>&#42; Post Code: </td><td><input type="text" name="destpostcode" value="<?php echo $Destpostcode; ?>"/></td></tr>
     <tr><td>&#42; Country: </td><td><input type="text" name="destcountry" value="<?php echo $Destcountry; ?>"/></td></tr>
     <tr><td>&#42; Phone: </td><td><input type="text" name="destphone" value="<?php echo $Destphone; ?>"/></td></tr>
     <tr><td>&nbsp; Mobile: </td><td><input type="text" name="destmobile" value="<?php echo $Destmobile; ?>"/></td></tr>
     <tr><td>&nbsp; Fax: </td><td><input type="text" name="destfax" value="<?php echo $Destfax; ?>"/></td></tr>
     <tr><td>&#42; Email: </td><td><input type="text" name="destemail" value="<?php echo $Destemail; ?>"/></td></tr>
     </table>
   </td></tr>

   <tr><td valign="top" align="left" colspan="2">
     <br/>

   <h2>Shipment Information</h2>

<table width="300"><tr><td valign="top">
   <table align="left">
     <tr><td width="130">&#42; Cargo To Be Shipped:</td><td><input type="text" name="cargodescription" value="<?php echo $Cargodescription; ?>"/></td></tr>
     <tr><td>&#42; Quantity:</td><td><input type="text" name="quantity" value="<?php echo $Quantity; ?>"/></td></tr>
     <tr><td>&#42; Weight:</td><td><input type="text" name="weight" value="<?php echo $Weight; ?>"/></td></tr>
     <tr><td valign="top">&#42; Container:</td><td>
        <select name="containersize" style="width:143">
		<?php
    if ($Containersize == "") {
	  echo '<option>Please select size</option>';
	} else if ($Containersize != "20ft GP") {
	  echo '<option selected="selected">20ft GP</option>';
	} else if ($Containersize != "20ft Open Top") {
	  echo '<option selected="selected">20ft Open Top</option>';
	} else if ($Containersize != "40ft GP") {
	  echo '<option selected="selected">40ft GP</option>';
	} else if ($Containersize != "") {
	  echo '<option selected="selected">40ft High Cube</option>';
	} else if ($Containersize != "") {
	  echo '<option selected="selected">40ft Open Top</option>';
    } else {
	  echo '<option>Please select size</option>
	  <option>20ft GP</option>
	  <option>20ft Open Top</option>
	  <option>40ft GP</option>
	  <option>40ft High Cube</option>
	  <option>40ft Open Top</option>';
	}
	?>
	</select>
     <tr><td>&#42; Weight Bridge Ticket:</td><td>
	 <?php 
		if($Weightbridge == "Yes") {
		echo '<input type="radio" name="weightbridge" value="Yes" selected="selected" checked="checked"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No"/>No';
		} if else($Weightbridge == "No"){
		echo '<input type="radio" name="weightbridge" value="Yes"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No" selected="selected" checked="checked"/>No';
		} else {
		echo '<input type="radio" name="weightbridge" value="Yes"/>Yes &nbsp; &nbsp; <input type="radio" name="weightbridge" value="No"/>No';
		}
	 ?></td></tr>
     <tr><td>&#42; Door Facing:</td><td><?php 
	 	if($Doorfacing == "Front") {
		echo '<input type="radio" name="doorfacing" value="Front" selected="selected" checked="checked"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back"/>Back';
	 	} if else($Doorfacing == "Back"){
		echo '<input type="radio" name="doorfacing" value="Front"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back" selected="selected" checked="checked"/>Back';
		} else {
		echo '<input type="radio" name="doorfacing" value="Front"/>Front &nbsp; <input type="radio" name="doorfacing" value="Back"/>Back';
		}
	 ?></td></tr>
   </table>
</td><td valign="top" align="left">
   <table >
      <tr><td width="120">&#42; Declared Value:</td><td><input type="text" name="declaredvalue"  value="<?php echo $Declaredvalue; ?>"/></td></tr>
      <tr><td>&#42; Insurance Required:</td><td>
	  <?php 
      if($Insurance == "Yes") {
	  echo '<input type="radio" name="insurance" value="Yes" selected="selected" checked="checked"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"/>No';
	  } else if ($Insurance == "No") {
	  echo '<input type="radio" name="insurance" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"  selected="selected" checked="checked"/>No';
	  } else {
	  echo '<input type="radio" name="insurance" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio" name="insurance" value="No"/>No';
	  }
	  ?></td></tr>
      <tr><td>&#42; Dangerous Goods:</td><td>
	  <?php 
	  if($Dangerousgoods == "Yes") {
	  echo '<input type="radio" name="dangerousgoods" value="Yes" selected="selected" checked="checked"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No"/>No';
	  } else if ($Dangerousgoods == "No") {
	  echo '<input type="radio" name="dangerousgoods" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No" selected="selected" checked="checked"/>No';
	  } else {
	  echo '<input type="radio" name="dangerousgoods" value="Yes"/>Yes  &nbsp; &nbsp; <input type="radio"name="dangerousgoods" value="No"/>No';
	  }	  
	  ?></td></tr>
      <tr><td>&#42; Quoted Freight Charge:</td><td valign="bottom">
	  <?php
      if ($Currency == "AUD") {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  } else if ($Currency == "USD") {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  } else {
	  echo '<input type="radio" name="currency" value="AUD"/>AUD$ <input type="radio" name="currency" value="USD"/>USD$';
	  }
	  ?></td></tr>
      <tr><td>&#42; Delivery Date:</td><td><input type="text" name="deliverydate" value="<?php echo $Deliverydate; ?>"/></td></tr>
      <tr><td>&#42; Delivery Time:</td><td><input type="text" name="deliverytime" value="<?php echo $Deliverytime; ?>"/></td></tr>
   </table>

</td></tr>
  
   <tr><td colspan="2">
   <br/><br/>Details/Special Instructions:</td></tr>
   <tr><td colspan="2"><textarea name="instructions" style="width:582px; height:70px; font-family:arial"><?php echo $Instructions; ?></textarea></td></tr>
   <tr><td><br/><input type="reset" value="Clear" style="width:60px"/></td><td align="right">
       <br/><div id="submitDiv" style="text-align:right; width:211px"><input type="submit" value="Submit Booking" style="width:110px; margin-right:6px"/></div></td></tr>
  </td></tr>
  </table> 

   </td></tr>
   </table>
   </form>