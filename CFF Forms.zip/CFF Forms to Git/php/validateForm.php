  <?php
  
// Declare Variables
   $errorMessage = "";
   $str = "";

//********Create Methods***********

  function removeUnsafeChars($str) {
    $str = preg_replace('/\x3C|\x3E/', ' ', $str);
    return $str;
  }

  function trimValues($str) {
    $str = preg_replace('/^\s+|\s+$/', '', $str);
    return $str;
  }

  function validateEmail($str) {
    $str = preg_replace('/^\S+\x40\S+\.\S+$/', '', $str);  
    // If email is valid, false will be returned.
    if (strlen($str) == 0) {
      return false;
    } else {
      return true;
    }
  }

  function checkDigits($str) {

    // Remove spaces.
    $str = preg_replace('/\s/', '', $str);
    // Check for non-digits:
    $str = preg_replace('/\d/', '', $str);

    if (strlen($str) > 0) {
      return true;
    } else {
      return false;
    }
  }


   
 ?>
   