<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Freight Forwarding Australia</title>
<style type="text/css">
    div#footer{color:#c8e0fc;rgb(175,175,175); margin-top:8px;padding-bottom:0px; margin-bottom:0px; font-size:12px;       		font-weight:700; width:1003px; height:30px; line-height:30px;position:absolute; top:1106px; left:0px;}
    div#container1{position:absolute; top:0px; left:-1px; width:1003px; height:1120px;background-image:url(softblankbg2inside2.jpg)}
</style>
<?php include("header.html"); ?>

<h1><i>Open Account</i></h1>
<hr/>

   <div id="errorMessageDiv" style="color:red; font-weight:normal;"></div>
   <form name="openaccount" method="post" action="http://www.changefreight.com/processForm.php">
    <table>
      <tr><td width="130">&#42; Title: </td><td><input type="text" name="title"/></td></tr>
      <tr><td>&#42; First Name: </td><td><input type="text" name="firstname"/></td></tr>
      <tr><td>&#42; Last Name: </td><td><input type="text" name="lastname"/></td></tr>
      <tr><td>&nbsp; Company: </td><td><input type="text" name="company"/></td></tr>
      <tr><td>&nbsp; Position: </td><td><input type="text" name="position"/></td></tr>
      <tr><td>&#42; Address: </td><td><input type="text" name="address"/></td></tr>
      <tr><td>&#42; Suburb: </td><td><input type="text" name="suburb"/></td></tr>
      <tr><td>&#42; State: </td><td><input type="text" name="state"/></td></tr>
      <tr><td>&#42; Post Code: </td><td><input type="text" name="postcode"/></td></tr>
      <tr><td>&#42; Country: </td><td><input type="text" name="country"/></td></tr>
      <tr><td>&#42; Phone: </td><td><input type="text" name="phone_code" style="width:30px!important"/>
                        <input type="text" name="phone" style="width:161px!important"/></td></tr>
      <tr><td>&nbsp; Mobile: </td><td><input type="text" name="mobile"/></td></tr>
      <tr><td>&nbsp; Fax: </td><td><input type="text" name="fax_code" style="width:30px!important"/>
          <input type="text" name="fax" style="width:161px!important"/></td></tr>
      <tr><td>&#42; Email: </td><td><input type="text" name="email"/></td></tr>
      <tr><td colspan="2">&#42; Preferred Contact Method: </td>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp; 
                           &nbsp;   &nbsp;
               <input type="radio" name="contact" style="width:30px!important" value="Phone" checked/>Phone</td></tr>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;
                           <input type="radio" name="contact" style="width:30px!important" value="Email" />Email</td></tr>
      <tr><td colspan="2"> &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  
                           &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   
                           &nbsp;   &nbsp;
<input type="radio" name="contact" style="width:30px!important" value="Fax"/>Fax</td></tr>
      <tr><td colspan="2"><br/>&nbsp; Comments: </td></tr>
      <tr><td colspan="2"><textarea name="comments" style="width:340px; height:70px; font-family:arial"></textarea></td></tr>
       <tr><td><br/><input type="reset" value="Clear" style="width:60px"/></td><td align="left">
          <br/><div id="submitDiv" style="text-align:right; width:211px"><input type="submit" value="Register" style="width:60px"/></div></td></tr>
    </table>
   </form>
<script language="JavaScript1.2" type="text/javascript" src="validateForm.js"></script>
<?php include("footer.html"); ?>