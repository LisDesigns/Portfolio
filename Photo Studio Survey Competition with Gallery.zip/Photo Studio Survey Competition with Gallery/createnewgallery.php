<?php

if (!isset($_SESSION["user"])) {
  session_start();
}
$user = "admin";
$pass = "glebe123";

$loginusername = $_POST["loginusername"];
$loginpassword = $_POST["loginpassword"];

if (!$_SESSION["user"]) {
  if (($loginusername != $user) || ($loginpassword != $pass)){
    header("location:login.php?error=1");
  } else {
    $_SESSION["user"] = $user;
    $_SESSION["pass"] = $pass;
  }
}

?>
<html>
<head>
<title>Create New Gallery
</title>
</head>
<body style="font-family:arial">
<center>
<br/><h3 style="margin-right:20px">Create New Gallery</h3><br/><br/>
<div style="width:262px;text-align:left;background-color:#CCDDEE;padding:10px;height:126px;color:rgb(60,60,60);border: solid 1px rgb(200,200,200);">

<form name="newgallery" method="post" action="addgallery.php">
<br/>
<center>
<table style="border-style:none;width:200px;font-family:arial;font-size:12px">
<tr><td style="border-style:none;height:20px;line-height:20px;text-align:left"><b>New Gallery Name: </b></td></tr>
<tr><td style="border-style:none;height:20px;line-height:20px;"><input type="text" name="GalleryName" style="width:200px"/></td></tr>
<tr><td style="border-style:none;height:20px"><input type="submit" value="Create" class="buttons" style="margin-left:136px; width:70px"/></td></tr>
</table>
</center>
</form>
</div>
</center>

</body>
</html>