<?

header("Pragma:no-cache");
include "includes/dbconn.php";
include "includes/output_header.php";

$query  = "SELECT * FROM photogallery ORDER BY Position ASC";
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
?>

<table width="1000" cellpadding="5" cellspacing="1">

<tr>
<td height="10" colspan="5" align="right">
<? echo "Page: ";
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=">1</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=2">2</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=3">3</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=4">4</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=5">5</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=6">6</a> ';
/*
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=7">7</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=8">8</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=9">9</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=10">10</a>  ';
*/
?> &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; </td>
</tr>

<?
$i = 0;
$x = 0;
$startrow = '<tr>';
$closerow = '</tr>';

echo $startrow;
while($row = mysql_fetch_assoc($result)){
  $x++;

if ($_GET["page"] == "") {
  if ($x <= 50) {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}

if ($_GET["page"] == 2) {
  if (($x > 50) && ($x <= 100)) {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}

if ($_GET["page"] == 3) {

  if (($x > 100) && ($x <= 150))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}


if ($_GET["page"] == 4) {
  if (($x > 200) && ($x <= 250))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}

if ($_GET["page"] == 5) {
  if (($x > 250) && ($x <= 300))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
if ($_GET["page"] == 6) {
  if (($x > 300) && ($x <= 350))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
/*
if ($_GET["page"] == 7) {
  if (($x > 350) && ($x <= 400))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
if ($_GET["page"] == 8) {
  if (($x > 400) && ($x <= 450))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
if ($_GET["page"] == 9) {
  if (($x > 450) && ($x <= 500))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
if ($_GET["page"] == 10) {
  if (($x > 500) && ($x <= 550))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
if ($_GET["page"] == 11) {
  if (($x > 550) && ($x <= 600))  {

  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "large/".$FileName;
 // $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
  //$size = getimagesize();
  $thumbsize = imagecreatefromjpeg($thumb);  
  $thumbsize_width = imagesx($thumb);  
  $thumbsize_height = imagesy($thumb);  
  //$vertical = ' height="100" width="150"';
  //$horizontal =  ' width="150" height="100"';
  if ($thumbsize_height > $thumbsize_width ) {
    $output = $vertical;
  } else {
    $output = $horizontal;
  }

  if ($i < 5) {
  echo '<td width="198" height="198" align="center" valign="middle">';
  echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  } else {
    $i = 0;
    echo $closerow.$startrow;
    echo '<td width="198" height="198" align="center" valign="middle">';
    echo '<a href="'.$large.'" target="first_window"><img src="'.$thumb.'" alt="'.$title.'" '.$output.'/></a><br/>'.$title.'<br/></td>';
  }

  }
}
*/

  $i++;

}
echo $closerow;


?>

<tr>
<td height="10" colspan="5" align="right"><?
  echo "Page: ";
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=">1</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=2">2</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=3">3</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=4">4</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=5">5</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/faceoffashion.php?page=6">6</a> ';
/*
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=7">7</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=8">8</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=9">9</a> ';
  echo '<a href="http://www.thephotostudio.com.au/photogallery/testphotos.php?page=10">10</a>  ';
*/
?> &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; 
</td>
</tr>

</table>

</table>
<?
include "includes/output_footer.php";
?>