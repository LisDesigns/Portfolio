<?php

if (!isset($_SESSION["user"])) {
  session_start();
}

if (!$_SESSION["user"]) {
  header("location:login.php");
}

include "includes/dbconn.php";

$dir = "uploads/";
$f=0;
$imageid = $_GET["imageid"];

if (empty($_POST["GalleryName"])) {
  $GalleryName = $_GET["GalleryName"];
} else {
  $GalleryName = $_POST["GalleryName"];
}

if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
            $f++;
        }
        closedir($dh);
    }
}

$deletefile = $_POST["deletefile"];

if (!(isset($deletefile))) {
  //$deletefile = "/uploads/img" . $_GET["imageid"].".jpg";
  $deletefile1 = "/watermark/img" . $_GET["imageid"].".jpg";
  $deletefile2 = "/thumbs/img" . $_GET["imageid"].".jpg";
}

if (file_exists($deletefile)) { 
  unlink($deletefile1);
  unlink($deletefile2);
}


$query  = "DELETE FROM photogallery WHERE ImagesId = ".$imageid;
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} else {
    header("Location: editgallery.php?msg=3&GalleryName=$GalleryName");
}


?>