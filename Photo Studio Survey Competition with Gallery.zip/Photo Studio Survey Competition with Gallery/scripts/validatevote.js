  // Onload:
  function init_form() {
    document.getElementById("submitDiv").innerHTML = "<input type='button' value='Vote' onclick='validateForm()' />";
  }
  init_form();

  // Declare variables
  var FirstName, LastName, EmailAddress, VoteNumber;
  var errorMessage, englishPattern, emailPattern;
  var engStr, emaStr;
  FirstName = "";
  LastName = "";
  EmailAddress = "";
  VoteNumber = "";
  ErrorMessage = "";
  engStr = " ";
  emaStr = " ";
  englishPattern = new RegExp(/\<|\>/gi);

  // Get and retieve values
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
  } 

  function checkEnglish(englishStr) {
    // remove <> characters
    englishPattern = new RegExp(/\<|\>/gi);
    engStr = englishStr.replace(englishPattern, " ");
    return engStr;
  }  

  function getFieldValues() {

    // Get field values.
    FirstName = vote.elements[0].value;
    LastName = vote.elements[1].value;
    Email = vote.elements[2].value;
    VoteNumber = vote.elements[3].value;

    // Trim fields
    FirstName = FirstName.trim();
    LastName = LastName.trim();
    Email = Email.trim();
    VoteNumber = VoteNumber.trim();

    // Remove unsafe characters
    FirstName = checkEnglish(FirstName);
    LastName = checkEnglish(LastName);
    Email = checkEnglish(Email);
    VoteNumber = checkEnglish(VoteNumber);

    vote.elements[0].value = FirstName;
    vote.elements[1].value = LastName;
    vote.elements[2].value = Email;
    vote.elements[3].value = VoteNumber;

  }

  function validateEmail(emailStr) {
    emailPattern = new RegExp(/^\S+@\S+\.\S+$/gi);
    return emailPattern.test(emailStr);
  }

  function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    return digitPattern.test(digitStr);
  }

function validateForm() {

    n = 0;
    getFieldValues();

if ((FirstName.length == 0) || 
    (LastName.length == 0) || 
    (Email.length == 0) ||
    (VoteNumber.length == 0)) {
    ErrorMessage = "Please enter a value for all fields marked with an asterisk(*).";
    n = 1;
} 
if (n == 0) {
  vote.submit();
} else {
  alert(ErrorMessage);
}

}
