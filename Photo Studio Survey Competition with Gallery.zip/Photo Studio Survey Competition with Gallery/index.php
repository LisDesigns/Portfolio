<?php

header("Location:http://www.thephotostudio.com.au/events/");

?>