<?php

$username = "flash_admin";
$password = "glebe123";

$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}
$databaseName = "flash_voting";




mysql_select_db($databaseName, $connection) or die('Could not select the database: '.mysql_error());

$query  = "SELECT DISTINCT `emailaddress` FROM `competition` WHERE `competitionname`='Baby and Toddler'";

$result = mysql_query($query);


  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  while($row = mysql_fetch_assoc($result)){
    $id=$row['emailaddress'];
    $i++;
  }


$to = "lisa@lisdesigns.com.au";
$emailaddress ="the photo studio";
function get_include_contents($filename) {
    if (is_file($filename)) {
        ob_start();
        include $filename;
        $contents = ob_get_contents();
        ob_end_clean();
        return $contents;
    }
    return false;
}

$message = get_include_contents('babyshow_winner.html');

//echo $message;

$subject = 'test edm';
/*
$headers = 'From: '.$emailaddress. "\r\n" .
    'Reply-To: '.$emailaddress. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
*/

     $headers  = "From:".$emailaddress."\n";
     $headers .= "X-Mailer: none\n";
     $headers .= "MIME-Version: 1.0\n";
     $headers .= "Content-Type: text/html\r\n";

mail($to, $subject, $message, $headers);
ECHO $i;
mysql_close($connection);
?>
