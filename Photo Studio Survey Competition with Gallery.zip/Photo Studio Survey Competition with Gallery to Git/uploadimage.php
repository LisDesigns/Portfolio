<?php

session_start();

if (!$_SESSION["user"]) {
  header("location:login.php");
}
include "includes/header.php";

?>

<form name="upload" method="post" action="process.php" enctype="multipart/form-data">
<b>New Image Name:</b><br/><input type="text" name="imgname" style="width:158px;"/><br/>
<input type="file" name="file1" id="file1" style="width:241px;text-align:left!important"/>
<br/><input type="submit" value="Save"/>
</form>
