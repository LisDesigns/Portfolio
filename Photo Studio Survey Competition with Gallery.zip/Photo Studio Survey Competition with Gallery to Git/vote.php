<?php
   $competitionname = $_POST["competitionname"];
   $GalleryName_title = $competitionname;   
   $firstname = $_POST["firstname"];
   $lastname = $_POST["lastname"];
   $emailaddress = $_POST["emailaddress"];
   $votenumber = $_POST["votenumber"];
   $phone = $_POST["phone"];
   include("includes/output_header.php");
   ?>   
   <center>   
   <?   
   if (empty($firstname) || empty($lastname) || empty($emailaddress) || empty($votenumber)) {
   ?>
   <center>
   <div style="margin-left:;500px;width:560px;text-align:left; border-top-style:;dashed; border-top-width:;1px;border-color:;rgb(200,200,200)">
   <center><a name="vote"></a><h1><? echo $GalleryName_title; ?></h1>
   <br/><b>Error: Please enter a value for all fields marked with an asterisk(*).  &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; </b></center><br/><form name="vote" action="http://www.thephotostudio.com.au/photogallery/vote.php" method="post"><table style="margin-left:40px;"><input type="hidden" name="competitionname" value="<? echo $GalleryName_title; ?>"/><tr><td>First Name: <span class="ast">*</span></td><td><input type="text" name="firstname"/></td>
   <td> &nbsp; &nbsp;Last Name: <span class="ast">*</span></td><td><input type="text" name="lastname"/></td></tr>
   <tr><td>Email: <span class="ast">*</span></td><td><input type="text" name="emailaddress"/></td>
   <td> &nbsp; &nbsp;Phone: <span class="ast">*</span></td><td><input type="text" name="phone"/></td>
   </tr>
   <tr><td>Vote Number: <span class="ast">*</span></td><td><input type="text" name="votenumber"/></td><td>
   </td><td align="right"><input type="submit" value="Vote" style=""/></td></tr>
   <tr><td></td><td align="right" valign="top" style="text-align:right"></td></tr></table></div><br/><br/>
   <!--     <div style="margin-left:;500px;width:560px;text-align:left; border-top-style:;dashed; border-top-width:;1px;border-color:;rgb(200,200,200)">     <h1>Error</h1>     <br/>Please enter a value for all fields marked with an asterisk(*).          <br/><br/><form name="vote" action="http://www.thephotostudio.com.au/photogallery/vote.php" method="post">     <table>     <input type="hidden" name="competitionname" value="The Face of Fashion Festival"/>     <tr><td>First Name: <span class="ast">*</span></td><td><input type="text" name="firstname"/></td>     <td> &nbsp; &nbsp;Email: <span class="ast">*</span></td><td colspan="2"><input type="text" name="emailaddress"/></td></tr>     <tr><td>Last Name: <span class="ast">*</span></td><td><input type="text" name="lastname"/></td>     <td> &nbsp; &nbsp;Vote Number: <span class="ast">*</span></td><td><input type="text" name="votenumber"/></td>     <td align="right"><div id="submitDiv"><input type="submit" value="Vote" /></div></td></tr>     </table>     </div>     <br/><br/><br/><br/><br/><br/><br/><br/>     --> 
   <?   
   } else {   
   $username = "flash_admin";
   $password = "glebe123";
   $connection = mysql_connect("localhost",$username,$password);
   if (!$connection) {  
     die('Could not connect: ' . mysql_error());
   }
   
   $databaseName = "flash_voting";
   mysql_select_db($databaseName, $connection) or die('Could not select the database: '.mysql_error());
   $query  = "INSERT INTO competition (competitionname, firstname, lastname, emailaddress, votenumber, phone) VALUES ('$competitionname', '$firstname', '$lastname', '$emailaddress', '$votenumber','$phone')";
   $result = mysql_query($query);
   //$to      = "lisa@lisdesigns.com.au";
   $to      = "entries@thephotostudio.com.au";
   $subject = $competitionname.' Vote';
   $message = 'Hello, please enter my vote into the '.$competitionname." competition.\n\n";
   $message .= "First Name: ".$firstname."\n";
   $message .= "Last Name: ".$lastname."\n";
   $message .= "Email Address: ".$emailaddress."\n";
   $message .= "Phone: ".$phone."\n";
   $message .= "Vote Number: ".$votenumber;
   $headers = 'From: '.$emailaddress. "\r\n" .    
   'Reply-To: '.$emailaddress. "\r\n" . 
   'X-Mailer: PHP/' . phpversion();
   mail($to, $subject, $message, $headers);
   mysql_close($connection); 
   ?>    
   <h1>Thank you</h1>
   <br/>Your vote has been submitted. Please <a href="http://www.thephotostudio.com.au">Click here</a> to return home.
   <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/></center>      
   <?   }
   include("includes/output_footer.php");
   ?>