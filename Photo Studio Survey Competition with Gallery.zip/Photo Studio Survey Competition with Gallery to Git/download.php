<?php

if (!isset($_SESSION["user"])) {
  session_start();
}

if (!$_SESSION["user"]) {
  header("location:login.php");
}
?>

<html>
<head>
<?php

header("Pragma:no-cache");

include "includes/dbconn1.php";

$GalleryName = $_GET["GalleryName"];
$Download = $GalleryName.".csv";

?>
<title>Votes</title>
<style type="text/css">
  body{font-family:arial}
  table{font-family:arial; font-size:12px;border:1px; padding-right:10px}
</style>
</head>
<body>



<p align="right"><small><a href="editgallery.php?GalleryName=<? echo $GalleryName ?>">Return to Gallery Admin</a> <a href="logout.php">Logout</a></small></p>



<?
//$GalleryName = "Baby and Toddler";
//$query  = "SELECT * FROM competition WHERE competitionname ='".$GalleryName."' GROUP BY votenumber ORDER BY votenumber ASC";
$query  = "SELECT * FROM competition WHERE competitionname ='".$GalleryName."' ORDER BY votenumber ASC";

$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
//$file = fopen("votes/votes.csv", "w+");

echo "<b>".$GalleryName." Votes<br/><br/>";



//fwrite($file,"Vote Number, First Name, Last Name, Email Address,\n");
echo "<table>";
echo "<tr><td>Vote Number</td><td>First Name</td><td>Last Name</td><td>Email Address</td><td>Phone</td><tr/></b>";

while($row = mysql_fetch_assoc($result)){

  $votenumber=$row['votenumber'];
  $firstname=$row['firstname'];
  $lastname=$row['lastname'];
  $phonenumber=$row['phone'];
  $emailaddress=$row['emailaddress'];
  if ($phonenumber == 0) {
    $phonenumber = "";
  }
//  $i++;
  //fwrite($file,$votenumber.", ".$firstname.", ".$lastname.", ".$emailaddress.",\n");
  echo "<tr><td>".$votenumber."</td><td>".$firstname."</td><td>".$lastname."</td><td>".$emailaddress."<td><td>".$phonenumber."</td><tr/>";
}
echo "</table>";


//echo $i;
//fclose($file);

?>
</body>
</html>
