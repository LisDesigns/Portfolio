<?php  

header('Content-type: image/jpeg');

$watermark = imagecreatefromgif('uploads/testwatermark.gif');
$watermark_width = imagesx($watermark);  
$watermark_height = imagesy($watermark);  

$im = imagecreatetruecolor(400, 30);
$im = imagecreatefromjpeg("uploads/test.jpg");
//$im1 = imagecreatefromjpeg("uploads/test.jpg");

$pic_width = imagesx($im);  
$pic_height = imagesy($im);  

$new_width = $pic_width / 1.2;
$new_height = $pic_height / 1.2;
$dest_x = ($new_width - $watermark_width - 20) / 2;  
$dest_y = $pic_height - 300; 
$white = imagecolorallocate($im, 255, 255, 255);
//imagefilledrectangle($im, 0, 0, 399, 29, $white);

$text1 = 'THE';
$text2 = 'photo';
$text3 = 'STUDIO';
$font = 'uploads/trebuc.ttf';


$image_p = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($image_p, $im, 0, 0, 0, 0, $new_width, $new_height, $pic_width, $pic_height);
imagecopymerge($image_p, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 31);  
//imagecopymerge($im, $im1, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 30);  
imagejpeg($image_p);
imagedestroy($im);

?>

