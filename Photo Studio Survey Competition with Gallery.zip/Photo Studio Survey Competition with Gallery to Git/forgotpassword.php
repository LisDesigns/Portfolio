<?

  include "includes/header.php";

  $message = "Hello,\n\r"."Your login details for your photo gallery are as follows:\n\r";
  $message .= "Username: admin";
  $message .= "\nPassword: glebe123";
  $message .="\n\rThank you,"."\n\n"."Lis Designs Web Support";

  $subject = "Photo Gallery - Password Reminder";
  //$to      = $sendtoemail;
  $to      = 'North@thephotostudio.com.au';

  $headers = 'From: '.$email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();

  mail($to, $subject, $message, $headers);

  $subtitle ="Thank you";
  $message ="Your login details have been sent to your email address.";

  echo $message;
  echo "<br/><br/><a href='login.php'>Login</a>";
?>