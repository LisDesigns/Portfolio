<?php

$username = "root";
$password = "";

$connection = mysql_connect("localhost",$username,$password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}
$databaseName = "flash_photogallery";

mysql_select_db($databaseName, $connection) or die('Could not select the database: '.mysql_error());

?>