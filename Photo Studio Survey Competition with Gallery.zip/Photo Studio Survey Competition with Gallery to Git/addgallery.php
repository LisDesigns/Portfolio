<?php


if (!isset($_SESSION["user"])) {
  session_start();
}
$user = "admin";
$pass = "glebe123";

$loginusername = $_POST["loginusername"];
$loginpassword = $_POST["loginpassword"];

if (!$_SESSION["user"]) {
  if (($loginusername != $user) || ($loginpassword != $pass)){
    header("location:login.php?error=1");
  } else {
    $_SESSION["user"] = $user;
    $_SESSION["pass"] = $pass;
  }
}

// connect to the database
  header("Pragma:no-cache");
  include "includes/dbconn.php";
if (empty($_POST["GalleryName"])) {
  $GalleryName = $_GET["GalleryName"];
} else {
  $GalleryName = $_POST["GalleryName"];
}
  $query  = "SELECT * FROM photogallery WHERE ImagesId=(select MAX(ImagesId) from photogallery)";
  $result = mysql_query($query);

  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  while($row = mysql_fetch_assoc($result)){
    $id=$row['ImagesId'];
  }

  $id++;
  $watermark ="watermark/";
  $thumbs ="thumbs/";
  $filename = "img".$id.".jpg";

  $im = imagecreatefromjpeg("images/sample.jpg");
  imagejpeg($im,$thumbs.$filename,"80");
  imagedestroy($im);

  $im1 = imagecreatefromjpeg("images/bigsample.jpg");
  imagejpeg($im1,$watermark.$filename,"80");
  imagedestroy($im1);

  $position = $id;
  $imgname = "Example";


  // insert a new row with sample image
  mysql_query("INSERT INTO `photogallery` (`ImageName`,`FileName`,`Position`,`GalleryName`) VALUES ('$imgname', '$filename', '$position','$GalleryName')");

  header("location:editgallery.php?GalleryName=".$GalleryName);
?>