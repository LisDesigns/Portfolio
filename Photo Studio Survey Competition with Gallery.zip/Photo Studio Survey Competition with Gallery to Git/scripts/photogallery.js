function renameImage(id) {
  document.getElementById('col'+id+'b').innerHTML = '<b>Please Enter New Name:</b> <input type="text" value="" name="imgname" id="imgname" class="imgnames_edit" maxlength="100" style="width:234px"/><input type="hidden" name="imgid" value="'+id+'" readonly/> <input type="submit" name="save" value="Save"/>';
}

function changeImage(id) {
  document.getElementById('col'+id+'a').innerHTML = '<b>New Name:</b> <input type="text" value="" name="imgname" id="imgname" class="imgnames_edit" maxlength="100" style="width:164px"/><input type="hidden" name="imgid" value="'+id+'" readonly/> ';
  document.getElementById('col'+id+'b').innerHTML = '<b>Please select:</b> <input type="file" name="file2" id="file2" style="width:281px;text-align:left!important"/> <input type="submit" name="save" value="Save" />';
}

function deleteImage(id,gn) {
  location.href = "deleteimage.php?imageid="+id+"&GalleryName="+gn;
}

function saveImage(id) {

}

function saveName(id) {

}

function showTip(largeimg) {
  document.getElementById(largeimg).style.display="block";
}

function hideTip(largeimg) {
  document.getElementById(largeimg).style.display="none";
}

