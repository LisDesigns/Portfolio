<?php

if (!isset($_SESSION["user"])) {
  session_start();
}

if (!$_SESSION["user"]) {
  header("location:login.php");
}


include "includes/dbconn.php";

$i=0;
$imgname = $_POST["imgname"];
$imgid = $_POST["imgid"];
$uploads = "uploads/";
$thumbs = "thumbs/";
$watermark = "watermark/";

$filename = "img".$imgid.".jpg";

if (empty($_POST["GalleryName"])) {
  $GalleryName = $_GET["GalleryName"];
} else {
  $GalleryName = $_POST["GalleryName"];
}


// Rename 

if ((!$_FILES["file1"]) && (!$_FILES["file2"])) {

  $query  = "UPDATE `photogallery` SET `ImageName` = '".$imgname."' WHERE `photogallery`.`ImagesId` =".$imgid;
  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }
  //Message: Success! Image title renamed.
  echo '<script>document.location="editgallery.php?msg=4&GalleryName='.$GalleryName.'";</script>';

// Change image
} else if ((strlen($_FILES["file2"]["name"]) > 0)) {

/*

  if (file_exists($watermark.$filename)) {
    unlink($thumbs.$filename);
    unlink($watermark.$filename);
  }

  if (strlen($_FILES["file2"]["name"]) > 0) {
    if ((($_FILES["file2"]["type"] == "image/gif") || ($_FILES["file2"]["type"] == "image/jpeg")|| ($_FILES["file2"]["type"] == "image/pjpeg")) && ($_FILES["file2"]["size"] < 200000000000)) {
      if ($_FILES["file2"]["error"] > 0) {
      $error = "Return Code: " . $_FILES["file2"]["error"] . "<br />";
      } else {
      $_FILES["file2"]["name"]=$filename;
      move_uploaded_file($_FILES["file2"]["tmp_name"],$uploads.$filename);
      }
    }
  }

  // Get new dimensions
  list($width, $height) = getimagesize($uploads.$filename);
  $new_width = $width / 10;
  $new_height = $height / 10;

  // Resample
  $image_p = imagecreatetruecolor($new_width, $new_height);
  $image = imagecreatefromjpeg($uploads.$filename);
  imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

  // Output
  imagejpeg($image_p, $thumbs.$filename, 80);

  // Create watermark
  $im = imagecreatefromjpeg($uploads.$filename);

  $pic_width = imagesx($im);  
  $pic_height = imagesy($im);  

  $new_width = $pic_width / 1.5;
  $new_height = $pic_height / 1.5;
  $dest_x = ($new_width - $watermark_width - 6) / 2;  
  $dest_y = $new_height - $watermark_height - 30; 

  $image_x = imagecreatetruecolor($new_width, $new_height);
  imagecopyresampled($image_x, $im, 0, 0, 0, 0, $new_width, $new_height, $pic_width, $pic_height);
  imagecopymerge($image_p, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 26);  

  imagejpeg($image_p,$watermark.$filename,"80");
  imagedestroy($im);

  unlink($uploads.$filename);

  // Rename image (after image change)
  $query  = "UPDATE `photogallery` SET `ImageName` = '".$imgname."' WHERE `photogallery`.`ImagesId` =".$imgid;

  $result = mysql_query($query);
  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  // Message: Success! Image changed.
  echo '<script>document.location="editgallery.php?msg=5&GalleryName='.$GalleryName.'";</script>';

*/
} 

// Upload new image

if ($_FILES["file1"]) { 

  $query  = "SELECT * FROM photogallery WHERE ImagesId=(select MAX(ImagesId) from photogallery)";
  $result = mysql_query($query);

  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }

  while($row = mysql_fetch_assoc($result)){
    $id=$row['ImagesId'];
  }

  $id++;

  $filename = "img".$id.".jpg";
  $position = $id;

  mysql_query("INSERT INTO `photogallery` (`ImageName`,`FileName`,`Position`,`GalleryName`) VALUES ('$imgname', '$filename', '$position','$GalleryName')");
  $error ="";

  if (strlen($_FILES["file1"]["name"]) > 0) {
    if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg") || ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {
      if ($_FILES["file1"]["error"] > 0) {
        $error = "Return Code: " . $_FILES["file1"]["error"] . "<br/>";
      } else {
        $_FILES["file1"]["name"]=$filename;
        move_uploaded_file($_FILES["file1"]["tmp_name"],$uploads.$_FILES["file1"]["name"]);
      }
    }
  }    

  // Get new dimensions
  list($width, $height) = getimagesize($uploads.$filename);

  $new_width = $width / 1.5;
  $new_height = $height / 1.5;

  $image_p = imagecreatetruecolor($new_width, $new_height);
  $image = imagecreatefromjpeg($uploads.$filename);
  imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

  // added in

  // Create watermark
  $watermarkimg = imagecreatefromgif($uploads."watermark.gif");

  $watermark_width = imagesx($watermarkimg);  
  $watermark_height = imagesy($watermarkimg);  
 
  $dest_x = ($new_width - $watermark_width - 6) / 2;  
  $dest_y = $new_height - $watermark_height - 30; 

  //$image_x = imagecreatetruecolor($new_width, $new_height);

  //imagecopyresampled($image_x, $image_p, 0, 0, 0, 0, $new_width, $new_height, $watermark_width, $watermark_height);

  imagecopymerge($image_p, $watermarkimg, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 26);  

  imagejpeg($image_p,$watermark.$filename,"80");

  // end

  // Output
  // imagejpeg($image_p, $watermark.$filename, 80);

  $new_width = $width / 6.5;
  $new_height = $height / 6.5;

  // Resample
  $image_p = imagecreatetruecolor($new_width, $new_height);
  $image = imagecreatefromjpeg($uploads.$filename);
  imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

  // Output
  imagejpeg($image_p, $thumbs.$filename, 80);

  //imagedestroy($image_x);
  //imagedestroy($im);

  unlink($uploads.$filename);

  //Message: Image uploaded successfully.
  echo '<script>document.location="editgallery.php?msg=1&GalleryName='.$GalleryName.'";</script>';

} else {

  //Error: Invalid file: Please upload only image files with .jpg extension.
  echo '<script>document.location="editgallery.php?msg=2&GalleryName='.$GalleryName.'";</script>';

}

mysql_close($connection);

?>