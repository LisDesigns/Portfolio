<?
   session_start();

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }
  include "includes/header.php";

  $message = "Hello,\n\r"."Your login details for your photo gallery are as follows:\n\r";
  $message .= "Username: admin";
  $message .= "\nPassword: pass";
  $message .="\n\rThank you,"."\n\n"."Lis Designs Web Support";

  $subject = "Photo Gallery - Password Reminder";
  //$to      = $sendtoemail;
  $to      = 'jeremytwu@gmail.com';

c $email = "tech@lisdesigns.com.au";

  $headers = 'From: '.$email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();

  mail($to, $subject, $message, $headers);

  $subtitle ="Thank you";
  $message ="Your login details have been sent to your jeremytwu@gmail.com.";

  echo $message;
  echo "<br/><br/><a href='login.php'>Login</a>";
?>