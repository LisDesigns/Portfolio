<?php
//header('Content-type: image/jpeg');
if (!isset($_SESSION["user"])) {
  session_start();
}

if (!$_SESSION["user"]) {
  header("location:login.php");
}

include "includes/dbconn.php";
$dir = "uploads/";

$i=0;
$imgname = $_POST["imgname"];
$imgid = $_POST["imgid"];
//echo $imgname ."   ".$imgid;

if ((!$_FILES["file1"]) && (!$_FILES["file2"])) {

$dir = "uploads/";
$f=0;

$filename ="uploads/img".$imgid.".jpg";
$filename3 ="large/img".$imgid.".jpg";
$filename2 = "img".$imgid.".jpg";

unlink($filename);
unlink($filename3);
unlink("thumbs/".$filename2);

  if (strlen($_FILES["file2"]["name"]) > 0) {
    if ((($_FILES["file2"]["type"] == "image/gif") || ($_FILES["file2"]["type"] == "image/jpeg")|| ($_FILES["file2"]["type"] == "image/pjpeg")) && ($_FILES["file2"]["size"] < 200000000000)) {
      if ($_FILES["file2"]["error"] > 0) {
      $error = "Return Code: " . $_FILES["file2"]["error"] . "<br />";
      } else {
      $_FILES["file2"]["name"]=$filename2;
      move_uploaded_file($_FILES["file2"]["tmp_name"],
      $filename);
      }
    }
  }


// Get new dimensions
list($width, $height) = getimagesize("uploads/".$filename2);

$pic = imagecreatefromjpeg("uploads/img".$imgid.".jpg");  
$pic_width = imagesx($pic);  
$pic_height = imagesy($pic);  

if ($pic_width > $pic_height) {
  $new_width = $pic_width / 3;
  $new_height = $pic_height / 3;
} else {
  $new_width = $pic_width / 3;
  $new_height = $pic_height / 3;
}

/*
if ($pic_width > $pic_height) {
  $new_width2 = $pic_width / 2;
  $new_height2 = $pic_height / 2;
} else {
  $new_width2 = $pic_width / 2;
  $new_height2 = $pic_height / 2;
}
*/

// Resample
$image_p = imagecreatetruecolor($new_width, $new_height);
$image_2 = imagecreatetruecolor($new_width2, $new_height2);

// Output
imagejpeg($image_p, "thumbs/".$filename2, 100);
//imagejpeg($image_2, "large/".$filename2, 100);

/*
$watermark = imagecreatefromjpeg('');  
$watermark_width = imagesx($watermark);  
$watermark_height = imagesy($watermark);  
$image = imagecreatetruecolor($watermark_width, $watermark_height);  
$image = imagecreatefromjpeg($filename);  
$size = getimagesize($filename);  
$dest_x = $size[0] - $watermark_width - 5;  
$dest_y = $size[1] - $watermark_height - 5;  
imagecopymerge($image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 100);  
imagejpeg($image, $filename3, 100);
*/

$query  = "UPDATE `photogallery` SET `ImageName` = '".$imgname."' WHERE `photogallery`.`ImagesId` =".$imgid;

$result = mysql_query($query);

  if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
  }
  echo '<script>document.location="editgallery.php?msg=4";</script>';

} else if ((strlen($_FILES["file2"]["name"]) > 0)) {

$query  = "UPDATE `photogallery` SET `ImageName` = '".$imgname."' WHERE `photogallery`.`ImagesId` =".$imgid;

$result = mysql_query($query);
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
  echo '<script>document.location="editgallery.php?msg=5";</script>';

} 

if ($_FILES["file1"]) { 
//upload
$query  = "SELECT * FROM photogallery WHERE ImagesId=(select MAX(ImagesId) from photogallery)";
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

while($row = mysql_fetch_assoc($result)){
  $id=$row['ImagesId'];
}

$id++;
$filename = "img".$id.".jpg";
$filename2 = "uploads/img".$id.".jpg";
$position = $id;
mysql_query("INSERT INTO `photogallery` (`imageName`,`fileName`,`position`)
VALUES ('$imgname', '$filename', '$position')");

$error ="";
if (strlen($_FILES["file1"]["name"]) > 0) {
if ((($_FILES["file1"]["type"] == "image/gif") || ($_FILES["file1"]["type"] == "image/jpeg")|| ($_FILES["file1"]["type"] == "image/pjpeg")) && ($_FILES["file1"]["size"] < 200000000000)) {
  if ($_FILES["file1"]["error"] > 0) {
    $error = "Return Code: " . $_FILES["file1"]["error"] . "<br />";
  } else {
      $_FILES["file1"]["name"]=$filename;
      move_uploaded_file($_FILES["file1"]["tmp_name"],
      "uploads/" . $_FILES["file1"]["name"]);
/*
$watermark = imagecreatefromjpeg('watermark.jpg');  
$watermark_width = imagesx($watermark);  
$watermark_height = imagesy($watermark);  
$image = imagecreatetruecolor($watermark_width, $watermark_height);  
$image = imagecreatefromjpeg($filename2);  
$size = getimagesize($filename2);  
$dest_x = $size[0] - $watermark_width - 5;  
$dest_y = $size[1] - $watermark_height - 5;  
imagecopymerge($image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 100);  
imagejpeg($image, "large/".$filename, 100);
*/

// Get new dimensions
list($width, $height) = getimagesize("uploads/".$filename);

$pic = imagecreatefromjpeg($filename2);  
$pic_width = imagesx($pic);  
$pic_height = imagesy($pic);  

if ($pic_width > $pic_height) {
  $new_width = $pic_width / 3;
  $new_height = $pic_height / 3;
} else {
  $new_width = $pic_width / 3;
  $new_height = $pic_height / 3;
}

if ($pic_width > $pic_height) {
  $new_width2 = $pic_width / 2;
  $new_height2 = $pic_height / 2;
} else {
  $new_width2 = $pic_width / 2;
  $new_height2 = $pic_height / 2;
}


// Resample
//$image_p = imagecreatetruecolor($new_width, $new_height);
//$image_2 = imagecreatetruecolor($new_width2, $new_height2);

// Output
imagejpeg($image_p, "thumbs/".$filename, 100);
//imagejpeg($image_2, "large/".$filename, 100);

// Resample
$image_p = imagecreatetruecolor($new_width, $new_height);
$image = imagecreatefromjpeg("uploads/".$filename);
imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

// Output
imagejpeg($image_p, "thumbs/".$filename, 100);


      //echo $message = "<br/><br/>Image uploaded successfully.";
     // header("Location:editgallery.php?msg=1");
    echo '<script>document.location="editgallery.php?msg=1";</script>';
  }
} else {
     //$error = "Invalid file: Please upload only image files with .jpg extension.";
     //header("Location:editgallery.php?msg=2");
    echo '<script>document.location="editgallery.php?msg=2";</script>';
  }
}

}

mysql_close($connection);

?>