<?php


?>
<html>
<head>
<title>
</title>
<style type="text/css">
  body{font-family:arial;font-size:12px}
  table{font-family:arial;font-size:12px;border-collapse:collapse;border:solid 1px rgb(200,200,200);width:700px}
  h1{font-size:14px;display:inline;color:rgb(60,60,60);}
  .imgnames{border-style:none;font-weight:bold; width:200px;}
  td{color:rgb(60,60,60);font-weight:600;vertical-align:text-middle;vertical-align:middle;text-align:right;border:solid 1px rgb(200,200,200);border-left-style:none!important;height:60px; padding:4px;}
  .leftcol{text-align:left;border-right-style:none!important;width:250px;line-height:60px;vertical-align:middle}
  input{background-color:rgb(250,250,250);	-moz-opacity:80 ;
	filter:alpha(opacity: 80);
	opacity: 80;}
  .shadedrows{background-color:rgb(240,240,240);}
  .shadedrows input{background-color:rgb(240,240,240)!important;}
  .lightrows{background-color:rgb(250,250,250);}
  .lightrows input{background-color:rgb(250,250,250)!important;}
  #file1{background-color:rgb(250,250,250)!important;}
  img{margin-right:8px;border:solid 1px rgb(200,200,200);}
  

</style>


</head>
<body>