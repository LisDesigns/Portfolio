<?php

session_start();
include "includes/dbconn.php";

if (!$_SESSION["user"]) {
  header("location:login.php");
}

$dir = "uploads/";
$f=0;
$imageid = $_GET["imageid"];

if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
            $f++;
        }
        closedir($dh);
    }
}

$deletefile = $_POST["deletefile"];

if (!(isset($deletefile))) {
  $deletefile = "/uploads/img" . $_GET["imageid"].".jpg";
}

if (file_exists($deletefile)) { 
  unlink($deletefile);
}


$query  = "DELETE FROM photogallery WHERE ImagesId = ".$imageid;
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
} else {
    header("Location: editgallery.php?msg=3");
}


?>