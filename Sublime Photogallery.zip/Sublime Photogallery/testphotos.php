<?

header("Pragma:no-cache");
include "includes/dbconn.php";

$query  = "SELECT * FROM photogallery ORDER BY Position DESC";
$result = mysql_query($query);

if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}
?>
<table>
<?
$i = 0;
$startrow = '<tr><td class="photogallery">';
$closerow = '</td></tr>';

 
echo $startrow;
while($row = mysql_fetch_assoc($result)){
  $id=$row['ImagesId'];
  $title=$row['ImageName'];
  $FileName=$row['FileName'];
  $Position=$row['Position'];
  $large = "uploads/".$FileName;
  $thumb = "thumbs/".$FileName;
$item = '<a href="'.$large.'" rel="lightbox" title="'.$title.'" target="_blank"><img src="'.$thumb.'" border="0"/></a> &nbsp; &nbsp;';
  $i++;


  if ($i <= 5) {
    echo $item.$closerow;
  } else {
    $i = 0;
    echo $closerow.$startrow.$item;
  }
}
echo $closerow;

?>
</table>
<?

?>