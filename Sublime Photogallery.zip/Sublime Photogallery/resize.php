<?php
// Content type
header('Content-type: image/jpeg');

// The file
$filename = "uploads/img1.jpg";
$filename1 = "thumbs/img1c.jpg";
$percent = 0.5;

// Get new dimensions
list($width, $height) = getimagesize($filename);
$new_width = 100; //$width * $percent;
$new_height = 100; //$height * $percent;

// Resample
$image_p = imagecreatetruecolor($new_width, $new_height);
$image = imagecreatefromjpeg($filename);
imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

// Output
imagejpeg($image_p, $filename1, 100);

    // $_FILES["file2"]["name"]=$image_p;
      //move_uploaded_file($_FILES["file2"]["tmp_name"],
      //$filename1);


//move_uploaded_file(imagejpeg($image_p, null, 100), $filename1);



?>
