
function renameImage(id) {
  document.getElementById('col'+id+'b').innerHTML = '<b>Please Enter New Name:</b> <input type="text" value="" name="imgname" id="imgname" class="imgnames_edit" maxlength="100" style="width:234px"/><input type="hidden" name="imgid" value="'+id+'" readonly/> <input type="submit" name="save" value="Save" onclick="saveName('+id+')"/>';
}

function changeImage(id) {
  document.getElementById('col'+id+'a').innerHTML = '<b>New Name:</b> <input type="text" value="" name="imgname" id="imgname" class="imgnames_edit" maxlength="100" style="width:164px"/><input type="hidden" name="imgid" value="'+id+'" readonly/> ';
  document.getElementById('col'+id+'b').innerHTML = '<b>Please select:</b> <input type="file" name="file2" id="file2" style="width:281px;text-align:left!important"/> <input type="submit" name="save" value="Save"  onclick="saveImage('+id+')"/>';
}

function deleteImage(id) {
  location.href = "deleteimage.php?imageid="+id;
}

function insertImage(id) {
//location.href = "uploadimage.php?insertafter="+id;

win = window.open('insertimage.php', 
  'windowname2', 
  'width=300, \
   height=120, \
   directories=no, \
   location=no, \
   menubar=no, \
   resizable=no, \
   scrollbars=0, \
   status=no, \
   toolbar=no'); 
 win.focus();
 return false;

}

function saveImage(id) {
  //document.forms["form9"].submit();
  //eval("form"+id).submit();
  //document.forms["form9"].submit();
}

function saveName(id) {
  //document.getElementById("form9").submit();
  //alert(id);
  //fi = eval("form"+id);
  //document.forms["form9"].submit();
  //form9.submit();
  //document.getElementById("imgname").value;
}

function showTip(largeimg) {
  document.getElementById(largeimg).style.display="block";
}

function hideTip(largeimg) {
  document.getElementById(largeimg).style.display="none";
}

