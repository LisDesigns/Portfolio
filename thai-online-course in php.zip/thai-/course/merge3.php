<?php
session_start();

header('Content-type: image/png');
$section=$_SESSION["section_line"];

$pos=$_GET["pos"];
$image = imagecreatetruecolor(400, 36);

$white = imagecolorallocate($image, 255, 255, 255);
$grey = imagecolorallocate($image, 128, 128, 128);
$black = imagecolorallocate($image, 0, 0, 0);

imagefilledrectangle($image, 0, 0, 400, 36, $white);

$font = "webpage_files/fonts/Isaana.ttf";

$position=24;

imagettftext($image, 18, 0, 10, $position, $black, $font, $section[$pos]);

imagepng($image);
imagedestroy($image);
?>