<?php

if (!isset($_SESSION["section_test"])) {
  session_start();
}

$section_test[0]="dog 0<br/>";

$section_test[1]="dog 1<br/>";

$section_test[2]="dog 2<br/>";

$section_test[3]="section 3<br/>";

$section_test[4]="section 4<br/>";

$_SESSION["section_test"] = $section_test;


$section_cat[0]="cat_kk<br/>";

$section_cat[1]="cat 1<br/>";

$section_cat[2]="cat 2<br/>";

$section_cat[3]="section 3<br/>";

$section_cat[4]="cat 4<br/>";

$_SESSION["section_cat"] = $section_cat;


?>