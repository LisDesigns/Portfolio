<?php
//header("Pragma:no-cache");

$lessonId = $_GET['lessonId'];
//$lessonId = 0;

//include("webpage_files/includes/header.php");
include("webpage_files/includes/dbconn.php");
?>


<?php

$slidequery = "SELECT * FROM slides WHERE lessonId=".$lessonId." AND lessonId != 66 ORDER BY slideId ASC";

$pathImages="webpage_files/images/slideshow/";
//$slidequery = "SELECT * FROM slides WHERE lessonId='0' ORDER BY slideId ASC";
$slides = mysql_query($slidequery);

$leftmargin=506;

if (!$slides) {
    echo "Error: ".mysql_error();
    exit;
}
$i=0;
$slideCount = 0;

while($slide = mysql_fetch_assoc($slides)){

  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  $slide_image = $slide['slide_image'];
  $slide_sound = $slide['slide_sound'];
  $i++;
  $slideCount++; 
  $slideIdMax = $slideId;

}
?>
</div>

<?php
  
  if ($i>0) {
?>
<br/><br/>
<br/><br/>
<div id='displaybox'>
<?php
  include "slideshow/slidescripts.php";
  }
  include "webpage_files/includes/footer.php";

?>