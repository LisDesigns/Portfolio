<?php

header('Content-type: image/png');

$image = imagecreatetruecolor(400, 300);

$white = imagecolorallocate($image, 255, 255, 255);
$grey = imagecolorallocate($image, 128, 128, 128);
$black = imagecolorallocate($image, 0, 0, 0);

imagefilledrectangle($image, 0, 0, 399, 329, $white);

$text = 'Testing...';

//$font = "webpage_files/fonts/Arial.ttf";

$font = "webpage_files/fonts/Isaana.ttf";
imagettftext($image, 20, 0, 10, 20, $black, $font, $text);

imagepng($image);
imagedestroy($image);
?> 