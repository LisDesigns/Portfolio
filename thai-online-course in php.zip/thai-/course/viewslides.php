<?php

include("webpage_files/includes/dbconn.php");
include("webpage_files/includes/header.php");

$lessonId = $_POST['lessonId'];

$lessonId = 0;

?>
<b>slideshow Section</b>
<br/>slides already in this animation:
<br/>
<?php

$query = "SELECT * FROM slides WHERE lessonId=".$lessonId;
$slides = mysql_query($query);
if (!$slides) {
    echo "Error: ".mysql_error();
    exit;
}
while($slide = mysql_fetch_assoc($slides)){

  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  $slide_image = $slide['slide_image'];
  $slide_sound = $slide['slide_sound'];

  echo '<form action="deleteSlide.php" post="method">';
  echo '<input type="hidden" value=".$slideId." name="slideId"/><br/>';
  echo $i++." Slide Image:".$slide_image." " Slide Sound:".$slide_sound."<input type='submit' value='Delete'/>";
  echo "<br/><br/>";

}

?>
<form name="postad" method="post" action="addslide.php" enctype="multipart/form-data" style="display:inline-block;margin-top:4px;">
<?php 
//echo '<input type="hidden" value="'.$.'" name=""/>'; 
?>

<br/><b>Add Slide Picture</b>
<br/><input type="text" name="imgname"/> <b style="margin-left:74px">Please select:</b> <input type="file" name="file1" id="file1" style="width:241px;text-align:left!important;"/> 
<br/><b>Add Slide Sound</b>
<br/><input type="text" name="imgname"/> <b style="margin-left:74px">Please select:</b> <input type="file" name="file2" id="file2" style="width:241px;text-align:left!important;"/> 
<br/><input type="submit" value="Upload" style="margin-left:2px"/>
</form>

<?php
include("webpage_files/includes/footer.php");

?>