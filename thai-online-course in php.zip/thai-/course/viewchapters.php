<?php

include("webpage_files/includes/dbconn.php");
//include("webpage_files/includes/header.php");

$query = "SELECT * FROM chapters";
$chapters = mysql_query($query);
if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}
$i = 1;
while($chapter = mysql_fetch_assoc($chapters)){

  $orderId=$chapter['orderId'];
  $chapterId = $chapter['chapterId'];
  $lessonId = $chapter['lessonId'];
  $chapter_name = $chapter['chapter_name'];
  $chapter_heading = $chapter['chapter_heading'];

  echo "<br/><a href='viewlessons.php?chapterId=$chapterId' class='numbers'>".$i++.".</a> <a href='viewlessons.php?chapterId=$chapterId'>".$chapter_heading."</a>";

}


?>