<?php 
include "../webpage_files/includes/header.php";
   /*
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["MemberId"];

   if (!$_SESSION["user"]) {
     header("location:login.php?page=profile");
   }
   */ 


   include "../webpage_files/includes/dbconn.php";



$MemberId=8;

//$query = "SELECT * FROM `members` WHERE MemberId='".$_SESSION["MemberId"]."'";
$query = "SELECT * FROM `members` WHERE MemberId=".$MemberId;
$result = mysql_query($query);

while($row = mysql_fetch_assoc($result))
  {
    $Username = $row['Username'];
    $Password = $row['Password'];
    $FirstName = $row['FirstName'];
    $LastName = $row['LastName'];
    $Address = $row['Address'];
    $Suburb = $row['Suburb'];
    $State = $row['State'];
    $Country = $row['Country'];
    $PostCode = $row['PostCode'];
    $PhoneNumber = $row['Phone'];
    $Mobile = $row['Mobile'];
    $Email = $row['Email'];
  }
   //include "header.php";

$query = "SELECT * FROM members";

$result = mysql_query($query);

$i = 0;
$Usernamelist = "";

while($row = mysql_fetch_assoc($result)) {

  $Usernamelist .= $row['Username'].">";
  $i++;

}

?>

<script language="JavaScript1.2">

function clearForm() {
  document.member.elements[2].value ="";
  document.member.elements[3].value ="";
  document.member.elements[4].value ="";
  document.member.elements[5].value ="";
  document.member.elements[6].value ="";
  document.member.elements[7].value ="";
  document.member.elements[8].value ="";
  document.member.elements[9].value ="";
  document.member.elements[10].value ="";
  //document.member.elements[11].value ="";
}

</script>
<style type="text/css">
</style>
</head>
<body>

    <br/>
      <h1 style="display:inline;padding-left:0px">Edit Profile</h1>


   <div id="errorMessageDiv2" style="color:red; font-weight:normal;display:inline"></div>
   <form name="member" method="post" action="updatemember.php">
    <table id="member">
      <tr><td width="130"><font color="gray">*</font> Username: </td><td><input type="text" name="Username" value="<?php  echo $Username; ?>" readonly/></td></tr>
      <tr><td><font color="gray">*</font> Password: </td><td><input type="text" name="Password" value="<?php  echo $Password; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> First Name: </td><td><input type="text" name="FirstName" value="<?php  echo $FirstName; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> Last Name: </td><td><input type="text" name="LastName" value="<?php  echo $LastName; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> Address: </td><td><input type="text" name="Address" value="<?php  echo $Address; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> Suburb: </td><td><input type="text" name="Suburb" value="<?php  echo $Suburb; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> State: </td><td><input type="text" name="State" value="<?php  echo $State; ?>"/></td></tr>
      <tr><td><font color="gray">*</font> Post Code: </td><td><input type="text" name="PostCode" value="<?php  echo $PostCode; ?>"  /></td></tr>
      <tr><td><font color="gray">*</font> Country:</td><td><input type="text" name="Country" value="<?php  echo $Country; ?>"  /></td></tr>
      <tr><td><font color="gray">*</font> Phone: </td><td><input type="text" name="phone" value="<?php  echo $PhoneNumber; ?>"   /></td></tr>
      <tr><td>&nbsp; &nbsp;Mobile: </td><td><input type="text" name="mobile" value="<?php  echo $Mobile; ?>"  /></td></tr>
      <tr><td><font color="gray">*</font> Email: </td><td><input type="text" name="Email" value="<?php  echo $Email; ?>"/></td></tr>
      <tr><td><br/><input type="button" value="Clear" onclick="clearForm2()" class="buttons" style="width:60px"/></td><td align="left">
          <br/><div id="submitDiv2" style="text-align:right;"><input type="submit"  onclick="validateForm()"  value="Update" class="buttons" style="width:60px"/></div></td></tr>
<?php
//remember to change back to a button instead of submit to have javascript validation working fine
?>
    </table>
   </form>
<script language="JavaScript1.2">
/*
function checkUsername(newUsername) {

x = 0;
i = <?php  echo $i; ?>;
list = "<?php  echo $Usernamelist; ?>";
oldUsername ="";
oldUsername = "<?php  echo $Username; ?>";
newlist = list.split(">");

for (x = 0; x < newlist.length; x++) {
  if (newUsername != oldUsername) {
    if (newlist[x] == newUsername) {
      register.elements[0].value = "";
      return true;
    } 
  }
}

}
*/
</script>


  
   <script language="JavaScript1.2" type="text/javascript" src="../webpage_files/scripts/validateForm.js"></script>

