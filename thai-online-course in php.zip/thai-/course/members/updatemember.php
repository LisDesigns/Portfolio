<?php
include "../webpage_files/includes/header.php";
/*
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["memberid"];

   if (!$_SESSION["user"]) {
     header("location:login.php");
   }
*/
//*******Get Values*******
$MemberId = 7;
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$Address = $_POST['Address'];
$Suburb = $_POST['Suburb'];
$State = $_POST['State'];
$Country = $_POST['Country'];
$PostCode = $_POST['PostCode'];
$PhoneNumber = $_POST['PhoneNumber'];
$Mobile = $_POST['Mobile'];
$Email = $_POST['Email'];

//*******Submit to Database*******


include "../webpage_files/includes/dbconn.php";

//mysql_query("UPDATE `members` SET `Username` = '$Username', `Password` = '$Password', `FirstName` = '$FirstName', `LastName` = '$LastName',  `Address` = '$Address',  `Suburb` = '$Suburb',  `State` = '$State',  `Country` = '$Country', `PostCode` = '$PostCode',  `Phone` = '$Phone',  `Mobile` = '$Mobile',  `Email` = '$Email' WHERE `MemberId` =".$_SESSION["MemberId"]);

$query = "UPDATE `members` SET `Username` = '$Username', `Password` = '$Password', `FirstName` = '$FirstName', `LastName` = '$LastName',  `Address` = '$Address',  `Suburb` = '$Suburb',  `State` = '$State',  `Country` = '$Country', `PostCode` = '$PostCode',  `Phone` = '$Phone',  `Mobile` = '$Mobile',  `Email` = '$Email' WHERE `MemberId` =".$MemberId;
mysql_query($query);

$subtitle ="Thank you";
$message ="Your profile has been updated.";

include "confirm.php";


?>