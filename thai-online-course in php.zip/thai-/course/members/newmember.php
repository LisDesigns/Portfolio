<?php 

  
  include "../webpage_files/includes/member_header.php";

/*

$query = "SELECT * FROM members";
mysql_query($query);
$i = 0;
$Usernamelist = "";

while($row = mysql_fetch_assoc($result)) {
  $Usernamelist .= $row['Username'].">";
  $i++;
}
*/
?>
   <h1 style="display:inline;padding-left:0px;font-family:arial;font-size:14px;">New Member Signup</h1>
   <br/>   
   <div id="errorMessageDiv2" style="color:red; font-weight:normal;"></div>
   <form name="member" method="post" action="addmember.php">
    <table id="member">
      <tr><td width="130"><font color="gray">*</font> Username:</td><td><input type="text" name="Username"/></td></tr>
      <tr><td><font color="gray">*</font> Password:</td><td><input type="text" name="Password"/></td></tr>
      <tr><td><font color="gray">*</font> First Name:</td><td><input type="text" name="FirstName"/></td></tr>
      <tr><td><font color="gray">*</font> Last Name:</td><td><input type="text" name="LastName"/></td></tr>
      <tr><td><font color="gray">*</font> Address:</td><td><input type="text" name="Address"/></td></tr>
      <tr><td><font color="gray">*</font> Suburb:</td><td><input type="text" name="Suburb"/></td></tr>
      <tr><td><font color="gray">*</font> State:</td><td><select name="State" id="state"><option value="Please select" selected>Please select</option><option value="NSW">NSW</option><option value="ACT">ACT</option><option value="QLD">QLD</option><option value="VIC">VIC</option><option value="TAS">TAS</option><option value="WA">WA</option><option value="NT">NT</option></select></td></tr>
      <tr><td><font color="gray">*</font> Country:</td><td><select name="Country"><option>Please select</option><option value="Australia">Australia</option><option value="Other">Other</option></select></td></tr>
      <tr><td><font color="gray">*</font> Post Code:</td><td><input type="text" name="PostCode"/></td></tr>
      <tr><td><font color="gray">*</font> Phone:</td><td><input type="text" name="phone"/></td></tr>
      <tr><td> &nbsp;&nbsp; Mobile: </td><td><input type="text" name="mobile"/></td></tr>
      <tr><td><font color="gray">*</font> Email: </td><td><input type="text" name="Email"/></td></tr>
      <tr><td><font color="gray">*</font> Membership Fee:</td><td>
          <select name="Amount" style="border:solid 1px rgb(220,220,220)"><option value="0.00">Single Lesson Trial - Free</option><option value="30.00">3 Months - 30.00</option><option value="60.00">6 Months - 60.00</option><option value="100.00">Lifetime - 100.00</option></select>
      <tr><td><br/><input type="reset" value="Clear" class="buttons" style="width:60px"/></td><td align="left">
          <br/><div id="submitDiv2" style="text-align:right;">
      <input type="submit" value="Register" class="buttons" onclick="validateForm()" style="width:60px"/></div></td></tr>
    </table>
   </form>

   </div>

   <script language="JavaScript1.2" type="text/javascript" src="../webpage_files/scripts/validateForm.js"></script>
