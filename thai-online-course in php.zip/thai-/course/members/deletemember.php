<?php
include "../webpage_files/includes/dbconn.php";

$MemberId = $_GET['MemberId'];

//$MemberId = $_POST['MemberId'];

//$MemberId=1;

$query = "DELETE FROM `members` WHERE MemberId=".$MemberId;
mysql_query($query);

include "../webpage_files/includes/footer.php";
?>