<?php

include "../webpage_files/includes/header.php";

  $loginUsername = $_POST["Username"];
  $loginPassword = $_POST["Password"];

//*******Get Values*******

$Username = $_POST['Username'];
$Password = $_POST['Password'];
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$Address = $_POST['Address'];
$Suburb = $_POST['Suburb'];
$State = $_POST['State'];
$Country = $_POST['Country'];
$PostCode = $_POST['PostCode'];
$phonenumber = $_POST['phone'];
$mobile = $_POST['mobile'];
$Email = $_POST['Email'];

//*******Submit to Database*******

$i=0;

mysql_query("INSERT INTO members (Username, Password, FirstName, LastName, Address, Suburb, State, Country, PostCode, Phone, Mobile, Email)
               VALUES ('$Username','$Password','$FirstName','$LastName','$Address','$Suburb','$State','$Country','$PostCode','$phonenumber','$mobile','$Email')");
/*
//$query  = "SELECT * FROM members WHERE Username = '".$loginUsername."' AND Password = '".$loginPassword."'";

//$result = mysql_query($query);

//mysql_query($query);

  $i=0;

    while($row = mysql_fetch_assoc($result))
    {
      $i++;
      $MemberId = $row['MemberId'];
      //echo $MemberId." ";
    }

if($i >= 1) {

    $_SESSION["user"] = $loginUsername;
    $_SESSION["pass"] = $loginPassword;
    $_SESSION["MemberId"] = $MemberId;
}

$personName        = $FirstName.' '.$LastName;
$SHIPTOSTREET      = $Address;
$SHIPTOCITY        = $Suburb;
$SHIPTOState	   = $State;
$SHIPTOCountryCODE = "AU";
$SHIPTOZIP         = $PostCode;

//include "ReviewOrder.php";

include "../webpage_files/includes/footer.php";
*/

$subtitle ="Thank you";
$message ="Your profile has been created.";

include "confirm.php";
?>