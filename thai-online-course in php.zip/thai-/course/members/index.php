<?php

  include "../webpage_files/includes/member_header.php";

  include "../login/memberlogin.php";
  //include "newmember.php";

  ?>
  <a href="newmember.php">Register</a>
  <?php

  include "../webpage_files/includes/footer.php";

?>