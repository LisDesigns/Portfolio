<?php
//header("Pragma:no-cache");


$lessonId = $_POST['lessonId'];
$lessonId = 0;

$pic = '<img src="webpage_files/images/slideshow/picture.jpg">';

?>

<br/><br/>
<br/><br/>
<div id='displaybox'>
<?php
$slideCount = 0;
$query = "SELECT * FROM slides WHERE lessonId=".$lessonId;
$slides = mysql_query($query);

$leftmargin=506;

//include "slideshow/index.php";

$slide_image="picture3.jpg";
while($slide = mysql_fetch_assoc($slides)){

  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  $slide_image = $slide['slide_image'];
  $slide_sound = $slide['slide_sound'];
  $slideCount++;


 // echo "<br/>Slide image: webpage_files/images/slideshow/".$slideId.".jpg";
 // echo "<br/>Slide sound: webpage_files/sounds/slideshow/".$slideId.".jpg<br/>";
 // echo $leftmargin."   <br/>";
 // echo "<img src='webpage_files/images/slideshow/".$slide_image."' border='1' class='display' />";
 // echo "<br/><br/>"; 
 // echo "<img src='webpage_files/images/slideshow/".$slide_image."' border='1' onclick='changeSlide(".'"'.$slide_image.'"'.")' class='thumbs' style='cursor:pointer;left:".$leftmargin."px!important' />"; 

  //$leftmargin+=50;

  }
?>

</div>
<script language='JavaScript1.2' type='text/javascript'>
function changeSlide(slide_image) {
  //alert(slide_image);
  
  //document.getElementById("displaybox").innerHTML= '<img src=webpage_files/images/slideshow/'+slide_image+' class=display>';
  //playSound("slideId");

}

function playSound(slideId) {

  //slide_sound = "<?php echo $slide_sound; ?>";
  
}


</script>



<?php
  include "slideshow/slidescripts.php";

  include "webpage_files/includes/footer.php";

?>