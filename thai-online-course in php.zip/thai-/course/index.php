<?php

include "webpage_files/includes/header.php";
// Display Welcome Message
?>
<br/><br/>
<h1>Welcome to our Thai Learning Course</h1>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus, elit vel elementum tempus, leo orci vehicula lectus, vitae pellentesque magna massa posuere sem. Integer eget urna sit amet leo fringilla commodo. Ut consectetur justo sed est cursus tristique. Pellentesque sed sodales purus. Phasellus lacus metus, sodales vel tincidunt sed, luctus in enim. Aliquam pellentesque, nisl vel rhoncus scelerisque, lectus justo mattis mi, in hendrerit eros mauris placerat sapien. Praesent bibendum interdum auctor. Cras ac nibh lorem, quis cursus enim. Aliquam a placerat enim. Mauris feugiat libero in tellus pharetra dictum et eget ligula. In felis mi, feugiat a tincidunt non, vulputate sit amet lectus. Vivamus tincidunt, ligula vitae egestas vehicula, mauris ante sollicitudin enim, vitae mattis massa quam a felis. Aliquam erat volutpat. Nam placerat accumsan lorem. Suspendisse potenti. 
</p>

<b>Course chapters</b>

<?php

include "viewchapters.php";
include "webpage_files/includes/footer.php";

?>