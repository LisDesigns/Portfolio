<?php

include("webpage_files/includes/dbconn.php");
include("webpage_files/includes/header.php");

$chapterId = $_GET["chapterId"];
$chapter_name="";
$query = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
$chapters = mysql_query($query);
if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}

while($chapter = mysql_fetch_assoc($chapters)){
  $chapter_heading = $chapter['chapter_heading'];
}

$query = "SELECT * FROM lessons WHERE chapterId=".$chapterId;
$lessons = mysql_query($query);

$listoflessons = "<select>";

if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
}

$i = 1;

echo "<br/><br/><h1>Lessons for ".$chapter_heading."</h1>";

while($lesson = mysql_fetch_assoc($lessons)){

  $slideId=$lesson['slideId'];
  $chapterId = $lesson['chapterId'];
  $lessonId = $lesson['lessonId'];
  $lesson_heading = $lesson['lesson_heading'];

  echo "<br/><a href='viewlesson.php?lessonId=$lessonId' class='numbers'>".$i++.".</a> <a href='viewlesson.php?lessonId=$lessonId'>".$lesson_heading."</a>";

  //$listoflessons .= "<option>".$lesson_name."</option>";
}
  //$listoflessons .= "</select>";
  //echo $listoflessons;

include("webpage_files/includes/footer.php");

?>