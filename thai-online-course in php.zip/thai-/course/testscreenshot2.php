<?php 
header("Content-type: image/gif");
echo phpinfo();


//$im = imagegrabscreen();
//imagegif($im,"1.gif");
?>

 


