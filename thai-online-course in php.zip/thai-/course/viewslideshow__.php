<?php
//header("Pragma:no-cache");

//$lessonId = $_POST['lessonId'];
$lessonId = 0;

include("webpage_files/includes/header.php");
include("webpage_files/includes/dbconn.php");
?>

<br/><br/>
<br/><br/>
<div id='displaybox'>
<?php
$slideCount = 0;

//$query = "SELECT * FROM slides WHERE lessonId=".$lessonId." ORDER BY slideId ASC";
$pathImages="webpage_files/images/slideshow/";
$slidequery = "SELECT * FROM slides WHERE lessonId='0' ORDER BY slideId ASC";
$slides = mysql_query($slidequery);

$leftmargin=506;

if (!$slides) {
    echo "Error: ".mysql_error();
    exit;
}
$i=0;
while($slide = mysql_fetch_assoc($slides)){

  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  $slide_image = $slide['slide_image'];
  $slide_sound = $slide['slide_sound'];
  $i++;
  $slideCount = $slideCount;

  //echo "<br/>Slide image: webpage_files/images/slideshow/".$slideId.".jpg";
  //echo "<br/>Slide sound: webpage_files/sounds/slideshow/".$slideId.".jpg<br/>";
  //echo $leftmargin."   <br/>";


//<img src="'.$slideImage.'" alt="Slide" id="slide'.$i.'"  class="slides"/>
  echo "<img src='webpage_files/images/slideshow/slide".$slideId.".jpg' id='slide".$i."' border='1' class='display' />";
  //echo "<br/><br/>"; 
  //echo "<img src='webpage_files/images/slideshow/thumb".$slideId.".jpg' border='1' onclick='changeSlide(".'"'.$slide_image.'"'.")' class='thumbs' style='cursor:pointer;left:".$leftmargin."px!important' />"; 

  //$leftmargin+=50;
      echo '<a href="javascript:displaySlide('.$i.')">';
      echo '<img src="'.$pathImages.'thumb'.$i.'.jpg" alt="Thumb '.$i.'" id="thumb'.$i.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/></a>';
      echo "\n";
  }
?>

</div>



<?php
  //include "slideshow/slidescripts.php";

  include "webpage_files/includes/footer.php";

?>