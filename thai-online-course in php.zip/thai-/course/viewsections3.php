<?php


include "webpage_files/includes/dbconn.php";

$font ="";

$lessonId = $_GET["lessonId"];
//$lessonId=2;

$query = "SELECT * FROM sections WHERE lessonId=".$lessonId;
$sections = mysql_query($query);

if (!$sections) {
    echo "Error: ".mysql_error();
    exit;
}

while($section = mysql_fetch_assoc($sections)){

  $sectionId=$section['sectionId'];
  $section_heading=$section['section_heading'];
  $section_picture=$section['section_picture'];

  $section_text=$section['section_text'];

  $language = $section['language'];
  $english = "webpage_files/fonts/Arial.ttf";
  $thai = "webpage_files/fonts/Isaana.ttf";

  if ($language == "English") {
    $font = $english;
    
    echo '<br/><br/><div name="section_text" style="font-family:Arial;Times New Roman;font-size:13px;font-weight:300;width:400px;">'.$section_text.'</div>';
  }
  if ($language == "Thai") {

    echo '<br/><br/><div name="section_text" style="font-family:Isaana 2008-23;Times New Roman;font-size:13px;font-weight:300;width:400px;">'.$section_text.'</div>';

    // $font = $thai;
    // $font = '<div style="font-family:Arial;Times New Roman;font-size:14px;font-weight:300;width:400px;">';
    // $font = '<span style="font-family:Isaana 2008-23;font-size:20px;font-weight:300;">';

    // echo "<br/>".$sectionId;

  }
 
}
  
?>
 <img src="webpage_files/images/lessons/tr.gif" border="0" width="450" style="position:absolute; display:none;top:360px;left:450px;height:800px;padding-bottom:20px;border-style:none"/>
<br/><br/>