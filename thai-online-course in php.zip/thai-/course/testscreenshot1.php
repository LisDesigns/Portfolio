<?php 
$im = imagegrabscreen();
imagepng($im);
?>
