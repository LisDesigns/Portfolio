<?php
//  session_start();

include "webpage_files/includes/dbconn.php";
echo "";
$font ="";

$lessonId = $_GET["lessonId"];

$query = "SELECT * FROM sections WHERE lessonId=".$lessonId." ORDER BY sectionId ASC";
$sections = mysql_query($query);

if (!$sections) {
    echo "Error: ".mysql_error();
    exit;
}

while($section = mysql_fetch_assoc($sections)){

  $sectionId=$section['sectionId'];
  $section_heading=$section['section_heading'];
  $section_picture=$section['section_picture'];
  $section_text=$section['section_text'];
  $language=$section['language'];
  $english = "webpage_files/fonts/Arial.ttf";
  $thai = "webpage_files/fonts/Isaana.ttf";
  $file = "webpage_files/images/lessons/".$sectionId.".jpg";
  echo "<h3>".$section_heading."</h3>";

  if (file_exists($file)) {
      echo "<img src='webpage_files/images/lessons/".$sectionId.".jpg' border='1'/><br/>";
  }

  if ($language == "English") {
    //$font = $english;
    $font = '<div style="font-family:Arial;Isaana 2008-23;Arial;Times New Roman;font-size:16px!important;font-weight:300;width:400px;">';
    echo $font.$section_text."</font></div>"; 
  }
  if ($language == "Thai") {
    //$font = $thai;
    $font = '<div style="font-family:Isaana 2008-23!important;Times New Roman;font-size:22px!important;font-weight:300;width:400px;">';
    //$font = '<span style="font-family:Isaana 2008-23;font-size:24px;font-weight:300;">';
    $section_text = wordwrap($section_text,20,"[:]");
    $section_block = explode("[:]", $section_text);
    $i=0;
    while ($i < count($section_block)) {

      $_SESSION["pos"]=$i;
      $_SESSION["section_line"]=$section_block[$i];
      ?><img src='<?php echo "merge.php?pos=".$i; ?>'/><?php
      $_SESSION["section_line"]=$section_block;
      $i++;

    }
  }

  $file = "webpage_files/sounds/lessons/".$sectionId.".mp3";
  if (file_exists($file)) {
  //    echo "<embed src='webpage_files/images/sound/".$sectionId.".mp3' border='1'></embed><br/>";
?>
<OBJECT ID="Player" height="0" width="0" style="display:none" 
  CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6">
   <PARAM name="UIMode" value="none"/><PARAM name="autoplay" value="true"/>
</OBJECT>

<INPUT TYPE="BUTTON" NAME="BtnPlay" VALUE="Play" OnClick="StartMeUp()">
<!--
<INPUT TYPE="BUTTON" NAME="BtnStop" VALUE="Stop" OnClick="ShutMeDown()">
-->
<SCRIPT>
    Player.URL = "<?php echo $file; ?>";
function StartMeUp ()
{
    Player.URL = "<?php echo $file; ?>";
}

function ShutMeDown ()
{
   // Player.controls.stop();

}
function mute()
{
  Player.AudioMixer.Mute;
}
function up() {
  AudioMixer.VolumeUp;
}
function down() {
  AudioMixer.VolumeDown;
}


</script>

<?php

  }

  echo "<br/>";

  }


?>