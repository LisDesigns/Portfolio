<?php

   include "dbconn.php";

  // include "../../login/check.php";

  // $error_message = "Could not successfully run query ($sql) from DB: " . mysql_error();

?>

<link rel="stylesheet" href="../webpage_files/editor/docs/style.css" type="text/css">
<script type="text/javascript" src="../webpage_files/editor/scripts/wysiwyg.js"></script>
<script type="text/javascript" src="../webpage_files/editor/scripts/wysiwyg-settings.js"></script>


<html><head><title></title><style type="text/css">  body{font-family:arial;font-size:12px}  
table{font-family:arial;font-size:12px;border-collapse:collapse;border:solid 1px rgb(200,200,200);width:700px}  
h1{font-size:14px;display:inline;color:rgb(60,60,60);}  
.imgnames{border-style:none;font-weight:bold; width:200px;}  
td{color:rgb(60,60,60);font-weight:600;vertical-align:text-middle;vertical-align:middle;text-align:right;border:solid 1px rgb(200,200,200);border-left-style:none!important;height:60px; padding:4px;}  
.leftcol{text-align:left;border-right-style:none!important;width:250px;line-height:60px;vertical-align:middle}  
input{background-color:rgb(250,250,250);	-moz-opacity:80 ;	filter:alpha(opacity: 80);	opacity: 80;}  
.shadedrows{background-color:rgb(240,240,240);}  
.shadedrows input{background-color:rgb(240,240,240)!important;}  
.lightrows{background-color:rgb(250,250,250);}  
.lightrows input{background-color:rgb(250,250,250)!important;}  
#file1{background-color:rgb(250,250,250)!important;}  
img{margin-right:8px;border:solid 1px rgb(200,200,200);}  
select{width:146px}
table{width:520px;}
table#editlesson td{text-align:left;height:20px;}
table#editlesson input{width:260px}
table#editlesson textarea{width:508px;height:160px; font-family:arial;font-size:12px}
table#editlesson #update{text-align:center;float:right;width:60px}
option{height:10px!important;overflow:hidden}
#next_lesson{display:inline; float:right}
#previous_lesson{display:inline; float:left}

.numbers{text-decoration:none}
.display{position:absolute; top:75px;width:400px; height:270px;visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=30);-moz-opacity:30}

.thumbs{position:absolute; top:355px;width:40px; height:40px;visibility:;visible; border-color:rgb(250,250,250);filter:alpha(opacity=0);-moz-opacity:0}

h3{font-size:13px;}

#register{font-family:arial;font-size:12px;height:400px;}

#member{width:320px;border-style:none!important;}

#member td{height:20px!important;overflow:hidden!important;border-style:none!important;font-weight:normal}

#login{width:320px;border-style:none!important;}

#login td{height:20px!important;overflow:hidden!important;border-style:none!important;font-weight:normal}

.selectlesson{display:inline;}

body{line-height:22px;overflow:;hidden;margin-left:40px;}
.slides{margin-top:14px;margin-left:460px!important}
.thumbs{margin-left:460px}
i{margin-top:4px!important;display:inline-block}
textarea{margin-top:4px;}
</style>



</head><body>

<div style="width:900px;text-align:right;position:absolute;top:10px;"> <small><a href="../index.php">Course Home</a>  &nbsp;<a href="index.php">Admin Home</a> &nbsp;<a href="../members/">Members</a></small></small></div>

