<P STYLE="margin-bottom: 0in"><FONT FACE="Tahoma">


&nbsp;
<font face="Isaana 2008-23, serif">
<select style="font-family:Isaana 2008-23, serif">
<option><FONT FACE="Tahoma">Phonic Symbols</font></option>
<option>&#128;</option>
<option>&#129;</option>
<option>&#130;</option>
<option>&#131;</option>
<option>&#132;</option>
<option>&#133;</option>
<option>&#134;</option>
<option>&#135;</option>
<option>&#136;</option>
<option>&#137;</option>
<option>&#138;</option>
<option>&#139;</option>
<option>&#140;</option>
<option>&#141;</option>
<option>&#142;</option>
<option>&#143;</option>
<option>&#144;</option>
<option>&#145;</option>
<option>&#146;</option>
<option>&#147;</option>
<option>&#148;</option>
<option>&#149;</option>
<option>&#150;</option>
<option>&#151;</option>
<option>&#152;</option>
<option>&#153;</option>
<option>&#154;</option>
<option>&#155;</option>
<option>&#156;</option>
<option>&#157;</option>
<option>&#158;</option>
<option>&#159;</option>
<option>&#160;</option>
<option>&#161;</option>
<option>&#162;</option>
<option>&#163;</option>
<option>&#164;</option>
<option>&#165;</option>
<option>&#166;</option>
<option>&#167;</option>
<option>&#168;</option>
<option>&#169;</option>
<option>&#170;</option>
<option>&#171;</option>
<option>&#172;</option>
<option>&#173;</option>
<option>&#174;</option>
<option>&#175;</option>
<option>&#176;</option>
<option>&#177;</option>
<option>&#178;</option>
<option>&#179;</option>
<option>&#180;</option>
<option>&#181;</option>
<option>&#182;</option>
<option>&#183;</option>
</select>
</font>

<FONT FACE="Tahoma"><FONT SIZE=6><SPAN LANG="hi-IN"><FONT FACE="Tahoma, sans-serif">

<select>
<option>Thai Symbols</option>
<option>&#3613;</option>
<option>&#3614;</option>
<option>&#3615;</option>
<option>&#3616;</option>
<option>&#3617;</option>
<option>&#3618;</option>
<option>&#3619;</option>
<option>&#3620;</option>
<option>&#3621;</option>
<option>&#3622;</option>
<option>&#3623;</option>
<option>&#3624;</option>
<option>&#3625;</option>
<option>&#3626;</option>
<option>&#3627;</option>
<option>&#3628;</option>
<option>&#3629;</option>
<option>&#3630;</option>
<option>&#3631;</option>
<option>&#3632;</option>
<option>&#3633;</option>
<option>&#3634;</option>
<option>&#3635;</option>
<option>&#3636;</option>
<option>&#3637;</option>
<option>&#3638;</option>
<option>&#3639;</option>
<option>&#3640;</option>
<option>&#3641;</option>
<option>&#3642;</option>
<option>&#3647;</option>
<option>&#3648;</option>
<option>&#3649;</option>
<option>&#3650;</option>
<option>&#3651;</option>
<option>&#3652;</option>
<option>&#3653;</option>
<option>&#3654;</option>
<option>&#3655;</option>
<option>&#3656;</option>
<option>&#3657;</option>
<option>&#3658;</option>
<option>&#3659;</option>
<option>&#3660;</option>
<option>&#3661;</option>
<option>&#3662;</option>
<option>&#3663;</option>
<option>&#3664;</option>
<option>&#3665;</option>
<option>&#3666;</option>
<option>&#3667;</option>
<option>&#3668;</option>
<option>&#3669;</option>
<option>&#3670;</option>
<option>&#3671;</option>
<option>&#3672;</option>
<option>&#3673;</option>
<option>&#3674;</option>
<option>&#3675;</option>
</select>



</FONT></SPAN></FONT></FONT></P>