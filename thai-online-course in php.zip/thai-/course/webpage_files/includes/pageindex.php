<?php
$pages = array();

$query = "SELECT lessonId FROM lessons WHERE chapterId=".$chapterId." ORDER BY lessonId ASC";
$lessons = mysql_query($query);
$i=0;
while($lesson = mysql_fetch_assoc($lessons)){
 
  $lessonId=$lesson['lessonId'];
  $pages[$i]=$lessonId;

  echo $pages[$i]."<br/>";
  $p = $i - 1;
  $n = $i + 1;

  if ($pages[$i] == $lessonId) {
    echo $pages[$i];
  }


  if ($pages[$p] == $lessonId) {
    echo $pages[$p];
  }

  if ($pages[$n] == $lessonId) {

    echo $pages[$n];
  }

  $i++;

}
   // $pageprev = $pages[$p];
   // $pagenext = $pages[$n];

    echo "i: ".$i."p: ".$p." n:".$n;
   // $pageprev = $pages[$p];
   // $pagenext = $pages[$n];

echo "pageprev ".$pageprev;
echo "pagenext ".$pagenext;
?>

<div style="display:inline-block;width:374px;">
<?php

if ($p >= 0) {
  $previous_link = "viewlesson.php?lessonId=".$pages[$p];
  echo '<a href="'.$previous_link.'" id="previous_lesson">Previous</a>';
}


if ($n > $i) {
  $next_link = "viewlesson.php?lessonId=".$pages[$n];
  echo '<a href="'.$next_link.'" id="next_lesson">Next</a>';
}
?>
</div>
