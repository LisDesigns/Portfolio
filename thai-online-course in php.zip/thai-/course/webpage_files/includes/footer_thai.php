		         </div>

		<div id="fw-sidebar">

<!--
			  
-->



			<div id="fw-sidebarbegin"></div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Special Offer</h3>
				<div class="fw-text"><p align="center"><a target="_blank" href="http://www.learnspeakthai.com/apps/webstore/"><img src="http://www.learnspeakthai.com/%20ST1+2%20offer.jpg" height="181" width="299"/></a></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Speak Thai To Me!</h3>
				<div class="fw-text"><p align="center"><img src="http://www.learnspeakthai.com/Brochure%20front%20R%20100kb%20jpg.jpg" height="583" width="292"/><br/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Thai - Hello</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/sawaddeeka%20pp.jpg" width="297" height="227"/><br/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Isaan Thai - I drink beer</h3>
				<div class="fw-text"><div align="left"><i><u><b><img src="http://www.learnspeakthai.com/I%20drink%20beer.jpg" height="204" width="295"/></b></u></i></div></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Thai - What is your name</h3>
				<div class="fw-text"><p align="left"><img src="http://www.learnspeakthai.com/kun cheu arai slide.jpg" height="202" width="292"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Isaan Thai - We like you</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/We%20like%20ou.jpg" height="199" width="296"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Thai - I want a beer Chang</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/visual slide bia chang 05.10.10.jpg" style="WIDTH: 295px; HEIGHT: 204px" height="336" width="444"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Isaan Thai - I miss you</h3>
				<div class="fw-text"><p align="left"><img src="http://www.learnspeakthai.com/visual slide miss you isan 05.10.10.jpg" height="202" width="297"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Thai - Can we meet again</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/Can we meet again Thai.jpg" height="218" width="298"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Isaan Thai - I'll phone you tomorrow</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/I%27ll%20call%20you%20tomorrow%20Isaan.jpg" height="223" width="299"/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div class="fw-paragraph">
				<div class="fw-paragraphtop"></div>
				<h3 class="fw-title">Thai - Good luck</h3>
				<div class="fw-text"><p><img src="http://www.learnspeakthai.com/good%20luck.jpg" height="201" width="295"/><br/></p></div>
				<div class="fw-paragraphbottom"></div>
			</div>
			
			<div id="fw-sidebarend"></div>
		</div>

		<div class="clears"></div>
	</div>
    <div class="clears"></div>
</div>

<div id="fw-footer">
	<p id="fw-foottext" class="fw-footertext">www.LearnSpeakThai.com     
                       </p>
	<p></p>
</div>

<!-- Start ClickyPlugin (0) -->
<script type="text/javascript" src="http://images.freewebs.com/JS/clicky.js"></script><script type="text/javascript">var clicky_page_title='Home';startClicky(21540539,'fwdb3');</script><noscript><p><img alt="Clicky Web Analytics" src="http://in.freewebs.getclicky.com/21540539-fwdb3.gif"/></p></noscript>
<!-- End ClickyPlugin (0) -->

<!--[if IE 6]>
<script type="text/javascript" src="http://images.webs.com/static/global/js/webs/usersites/ie6subnav.js"></script>
<![endif]-->
</body>
</html>
<!-- lappserver2 -->

<!-- [SB] PageID 58612367-->
<!-- null -->