
<?php

  //$section_text=$section['section_text'];

  $path="../webpage_files/images/lessons/picture.jpg";
  $path="../webpage_files/images/lessons/picture1.jpg";
  $image = imagecreatefromjpeg($path);

  $section_text="gghfghfhffg";
  $angle="";
  $size = 20;

  $image_width = imagesx($image);  
  $image_height = imagesy($image);  

  $font = "webpage_files/fonts/Arial.ttf";
  $black = imagecolorallocate($image, 0, 0, 0);

  imagettftext($image, $size, $angle, 10, $size+15, $black, $font, $section_text);

  $new_width = $image_width * 10;
  $new_height = $image_height * 10;

  $posx = ($new_width - $watermark_width - 6) / 2;  
  $posy = $new_height - $watermark_height - 30;

  $image_x = imagecreatetruecolor($new_width, $new_height);
  imagecopyresampled($image_x, $im, 0, 0, 0, 0, $new_width, $new_height, $pic_width, $pic_height);


  //imagecopymerge($image_p, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 26);  

  imagejpeg($image,$path1,"80");

  header('Content-type: image/jpeg');

  imagejpeg($image);
  imagedestroy($image);

?>