

<label style="font-family:aria;font-weight:normal!important;width:210px;text-align:right!important"><i>Insert Symbol</i></label>
<select name="selectSymbol1" style="font-family:Isaana 2008-23, serif; font-size:14px;line-height:8px;overflow:hidden;height:10px;" onchange="pastesymbol1()">
<option value="&#128;">&#128;</option>
<option value="&#130;">&#130;</option>
<option value="&#131;">&#131;</option>
<option value="&#132;">&#132;</option>
<option value="&#133;">&#133;</option>
<option value="&#134;">&#134;</option>
<option value="&#135;">&#135;</option>
<option value="&#136;">&#136;</option>
<option value="&#137;">&#137;</option>
<option value="&#138;">&#138;</option>
<option value="&#139;">&#139;</option>
<option value="&#140;">&#140;</option>
<option value="&#145;">&#145;</option>
<option value="&#146;">&#146;</option>
<option value="&#147;">&#147;</option>
<option value="&#148;">&#148;</option>
<option value="&#149;">&#149;</option>
<option value="&#150;">&#150;</option>
<option value="&#151;">&#151;</option>
<option value="&#152;">&#152;</option>
<option value="&#153;">&#153;</option>
<option value="&#154;">&#154;</option>
<option value="&#155;">&#155;</option>
<option value="&#156;">&#156;</option>

<!--
<option>&#157;</option>
<option>&#158;</option>
<option>&#159;</option>
<option>&#160;</option>
-->
</select>
<select name="selectSymbol2" style="font-family:Isaana 2008-23, serif; font-size:14px;line-height:12px;overflow:hidden;height:10px;" onchange="pastesymbol2()">
<option value="&#161;">&#161;</option>
<option value="&#162;">&#162;</option>
<option value="&#163;">&#163;</option>
<option value="&#164;">&#164;</option>
<option value="&#165;">&#165;</option>
<option value="&#166;">&#166;</option>
<option value="&#167;">&#167;</option>
<option value="&#168;">&#168;</option>
<option value="&#169;">&#169;</option>
<option value="&#170;">&#170;</option>
<option value="&#171;">&#171;</option>
<option value="&#172;">&#172;</option>
<option value="&#173;">&#173;</option>
<option value="&#174;">&#174;</option>
<option value="&#175;">&#175;</option>
<option value="&#176;">&#176;</option>
<option value="&#177;">&#177;</option>
<option value="&#178;">&#178;</option>
<option value="&#179;">&#179;</option>
<option value="&#180;">&#180;</option>
<option value="&#181;">&#181;</option>
<option value="&#182;">&#182;</option>
<option value="&#183;">&#183;</option>
</select><br/>











