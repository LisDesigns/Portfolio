<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
        <title>Home - </title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta name="keywords" content="Thai, Thailand, Isaan, Isan, Esan, E-san, Ee-san, I-san, I-saan, Isahn, Isarn, Eesarn, Ee-sahn, I-sahn, Learn Thai, Speak Thai, Study Thai, Thai language, Lao, Laos, Thai course, Thai dvd, Thai book, Thai cd, Thai words, Thai phrases">
	<meta name="description" content="Learn to speak Thai and Isaan Thai (Isan Thai/Esaan Thai/Esan Thai/Lao Thai) course. Our book and 3 hour DVD makes Thai language learning easy, fast, fun and interesting.">
	<!-- master box -->
	<link ref="canonical" href="http://www.learnspeakthai.com/"/>

<meta property="og:site_name" content="" />
<meta property="og:title" content="Home" />

<link rel="stylesheet" type="text/css" href="http://static.websimages.com/static/global/theme/css/pluggables.css"/>
<script type="text/javascript" src="http://static.websimages.com/static/global/js/webs/usersites/webs_common.js"></script>
<script type="text/javascript" src="http://static.websimages.com/static/global/js/webs/websover.min.js"></script><link id="templatebase" rel="stylesheet" type="text/css" media="screen" href="http://static.websimages.com/static/global/css/templatebase.css">
<link id="fw_template_file" rel="stylesheet" type="text/css" href="http://www.learnspeakthai.com/.design.css?r=708" media="screen">
<script>if(typeof(webs)==='undefined'){webs={page:{id:58612367}}}else if(typeof(webs.page)==='undefined'){webs.page={id:58612367}}else if(typeof(webs.page.id)==='undefinded'){webs.page.id=58612367}</script>
<!-- Start Google Webmaster Tool Verify Code -->
<meta name="google-site-verification" content="Zb2D9Hr7jqEVyKJ8dy0VuUvEg22ijZx68WljZy1NNns." />
<!-- End Google Webmaster Tool Verify Code -->

<!-- Start ClickyPlugin (0) -->

<!-- End ClickyPlugin (0) -->

	<link rel="stylesheet" type="text/css" href="http://images.freewebs.com/members/Generationz/Standard/PrintCSS/print.css" media="print">
</head>
<body class="hasOneColumn hasSidebar navtype-Top" >

<!-- Start ClickyPlugin (0) -->

<!-- End ClickyPlugin (0) -->

<script type="text/javascript" src="http://static.websimages.com/JS/fw.js"></script>
<!--
{NavHeaderFormat}
<li class="fw-navheader">{NavHeader}</li>
{/NavHeaderFormat}



-->

<div id="fw-container">
	<div id="fw-head">
		<h1 id="fw-title"><a id="fw-titlelink" href="http://www.learnspeakthai.com/"></a></h1>
		<h2 id="fw-smalltitle"></h2>
		<div id="logo-div" class="fw-logo"></div>
	</div>

	<div id="fw-blockContainer">
		<div id="fw-mainnavwrap">
			<div id="fw-nav-menu">
				<ul class="fw-nav-level-0">
					<li><a class="section fw-current-nav-link" href="http://www.learnspeakthai.com/" >Home</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/featuresandbenefits.htm" >Features and benefits</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/lookinsidebookdvd.htm" >Look inside book & DVD</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/speakthai.htm" >Speak Thai</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/speakisaanthai.htm" >Speak Isaan Thai</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/dictionaries.htm" >Dictionaries</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/qaisaanvthaivlao.htm" >Q&A: Isaan v Thai v Lao</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/apps/webstore/" >Web Store</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/feedbackandtestimonials.htm" >Feedback and testimonials</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/customersurvey.htm" >Customer survey</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/contactus.htm" >Contact us</a></li>
<li><a class="section" href="http://www.learnspeakthai.com/comingsoon.htm" >Coming soon!</a></li>

				</ul>
			</div>
		</div>


		<div id="fw-bigcontain">
			


			<div id="fw-mainColumn">

