<?php
mysql_query($query);

if (!$result) {
    echo $error_message;
    exit;
}
?>