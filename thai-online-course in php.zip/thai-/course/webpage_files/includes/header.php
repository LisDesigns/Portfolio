<?php
if (!isset($_SESSION["section_line"])) {
  session_start();
}
  // include "dbconn.php";
  // include "../../login/check.php";
  // $error_message = "Could not successfully run query ($sql) from DB: " . mysql_error();

?>



<html><head><title></title><style type="text/css">  
body{font-family:arial;font-size:13px}  
table{font-family:arial;font-size:12px;border-collapse:collapse;border:solid 1px rgb(200,200,200);width:700px}  
h1{font-size:14px;display:inline;color:rgb(60,60,60);}  
.imgnames{border-style:none;font-weight:bold; width:200px;}  
td{color:rgb(60,60,60);font-weight:600;vertical-align:text-middle;vertical-align:middle;text-align:right;border:solid 1px rgb(200,200,200);border-left-style:none!important;height:60px; padding:4px;}  
.leftcol{text-align:left;border-right-style:none!important;width:250px;line-height:;60px;vertical-align:middle}  
input{background-color:rgb(250,250,250);	-moz-opacity:80 ;	filter:alpha(opacity: 80);	opacity: 80;}  
.shadedrows{background-color:rgb(240,240,240);}  
.shadedrows input{background-color:rgb(240,240,240)!important;}  
.lightrows{background-color:rgb(250,250,250);}  
.lightrows input{background-color:rgb(250,250,250)!important;}  
#file1{background-color:rgb(250,250,250)!important;}  
img{margin-right:8px;border:solid 1px rgb(200,200,200);}  
select{width:146px}
table{width:520px;}
table#editlesson td{text-align:left;height:20px;}
table#editlesson input{width:260px}
table#editlesson textarea{width:508px;height:160px; font-family:arial;font-size:12px}
table#editlesson #update{text-align:center;float:right;width:60px}
#next_lesson{display:inline; float:right}
#previous_lesson{display:inline; float:left}
.numbers{text-decoration:none}
.display{position:absolute; top:75px;width:400px; height:270px;visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=30);-moz-opacity:30}
.thumbs{position:absolute; top:355px;width:40px; height:40px;visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=100);-moz-opacity:100}
h1{font-size:15px;font-family:arial;font-weight:600}
h3{font-size:16px;font-family:arial;font-weight:600}
#register{font-family:arial;font-size:12px;height:400px;}
#member{width:320px;border-style:none!important;}
#member td{height:20px!important;overflow:hidden!important;border-style:none!important;font-weight:normal}
#login{width:320px;border-style:none!important;}
#login td{height:20px!important;overflow:hidden!important;border-style:none!important;font-weight:normal}
.lesson{display:inline;font-size:10px;height:20px;}
body{line-height:29px;overflow:;hidden;margin-left:470px;}
.slides{margin-top:35px;margin-left:460px!important}
.thumbs{margin-left:460px}
.editbuttons{display:inline;float:left;left:10px;}
.editlist{display:inline}
p{width:400px}
img{border:none;}
</style>


</head><body>

<div style="width:400px;text-align:right;position:absolute;left:480px;top:10px;"> <small><a href="index.php">Course Home</a>  &nbsp;<a href="admin/">Admin Home</a> &nbsp;<a href="members/">Members</a></small></div>