<?php
$pages = array();

$query = "SELECT lessonId FROM lessons WHERE chapterId=".$chapterId." ORDER BY lessonId ASC";
$lessons = mysql_query($query);
$i=0;
while($lesson = mysql_fetch_assoc($lessons)){
 
  $lessonId=$lesson['lessonId'];
  $pages[$i]=$lessonId;
  if ($pages[$i] == $lessonId) {
    echo $pages[$i];
    $p = $i - 1;
    $n = $i + 1;
    $pageprev = $pages[$p];
    $pagenext = $pages[$n];
  }
  $i++;

}

?>



<div style="display:inline-block;width:374px;">
<?php
//$pageprev =  $lessonId-1;
$previous_link = "viewlesson.php?lessonId=".$pageprev;

//if ($pageprev >= 1) {
  //echo '<a href="'.$previous_link.'" id="previous_lesson">Previous</a>';
//}

//$pagenext = $lessonId+1;

$next_link = "viewlesson.php?lessonId=".$pagenext;


//for ($i=0; $i == $x; $x++) {


//  if $pages[$i] = $lessonId 

//  echo $pages[$i];
//}


//search the array - where lessonId, loop until the id number


//if ($lessonId != $maxlessonId) {
  echo '<a href="'.$next_link.'" id="next_lesson">Next</a>';
//}
?>
</div>
