/********************************************************************
 * openWYSIWYG settings file Copyright (c) 2006 openWebWare.com
 * Contact us at devs@openwebware.com
 * This copyright notice MUST stay intact for use.
 *
 * $Id: wysiwyg-settings.js,v 1.4 2007/01/22 23:05:57 xhaggi Exp $
 ********************************************************************/

/*
 * Full featured setup used the openImageLibrary addon
 */
var full = new WYSIWYG.Settings();
//full.ImagesDir = "../webpage_files/editor/images/";
//full.PopupsDir = "../webpage_files/editor/popups/";
//full.CSSFile = "../webpage_files/editor/styles/wysiwyg.css";
full.Width = "85%"; 
full.Height = "250px";
// customize toolbar buttons
full.addToolbarElement("font", 3, 1); 
full.addToolbarElement("fontsize", 3, 2);
full.addToolbarElement("headings", 3, 3);
// openImageLibrary addon implementation
full.ImagePopupFile = "addons/imagelibrary/insert_image.php";
full.ImagePopupWidth = 600;
full.ImagePopupHeight = 245;

/*
 * Small Setup Example
 */
var english = new WYSIWYG.Settings();
english.ImagesDir = "../webpage_files/editor/images/";
english.PopupsDir = "../webpage_files/editor/popups/";
english.Width = "510px!important";
english.Height = "150px";
english.DefaultStyle = "font-family: Arial; font-size: 12px; background-color:white; #AA99AA";
english.Toolbar[0] = new Array("forecolor"); // small setup for toolbar 1 "font", 
english.Toolbar[1] = ""; // disable toolbar 2
english.StatusBarEnabled = false;

var thai = new WYSIWYG.Settings();
thai.ImagesDir = "../webpage_files/editor/images/";
thai.PopupsDir = "../webpage_files/editor/popups/";
thai.Width = "510px!important";
thai.Height = "150px";
thai.DefaultStyle = "font-family: Isaana 2008-23; font-size: 12px; background-color:white; #AA99AA";
thai.Toolbar[0] = "";//new Array("forecolor"); // small setup for toolbar 1 "font", 
thai.Toolbar[1] = ""; // disable toolbar 2
thai.StatusBarEnabled = false;