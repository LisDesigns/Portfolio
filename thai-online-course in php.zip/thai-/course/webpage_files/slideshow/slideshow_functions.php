
<script language="JavaScript1.2" type="text/javascript">

// Repeat in php the following code for every slide

  secondsToCount1 = 2;
  secondsToCount2 = 2;
  secondsToCount3 = 2;
  secondsToCount4 = 2;
  i1=0;
  i2=0;
  i3=0;
  i4=0;

function increaseOpacity1() { 
  if (i1 <= 80) {
    secondsToCount1 += 1;
    i1+=10;
    document.getElementById("thumb1").filters.alpha.opacity=i1;
    t1 = setTimeout("increaseOpacity1();", secondsToCount1);
  }
}

// Repeat in php inside only

if ((navigator.appName == 'Microsoft Internet Explorer') && (document.getElementById)) {
    //alert("true");
    secondsToCount = 2300;
    t5 = setTimeout("increaseOpacity1();", secondsToCount);
    secondsToCount += 2300;
    t5 = setTimeout("increaseOpacity2();", secondsToCount);
    secondsToCount += 2300;
    t5 = setTimeout("increaseOpacity3();", secondsToCount);
    secondsToCount += 2300;
    t5 = setTimeout("increaseOpacity4();", secondsToCount);
}


// Repeat in php the following code for every slide

  mozSeconds1 = 2;
  mozSeconds2 = 2;
  mozSeconds3 = 2;
  mozSeconds4 = 2;
  m1=0;
  m2=0;
  m3=0;
  m4=0;

function mozOpacity1() { 
  if (m1 <= 0.8) {
    mozSeconds1 += 1;
    m1+=0.03;
    document.getElementById("thumb1").style.MozOpacity=m1;
    mt1 = setTimeout("mozOpacity1();", mozSeconds1);
  }
}

// Repeat in php inside only

if ((navigator.product == 'Gecko') && (document.getElementById)){

    mozSeconds = 2300;
    mt5 = setTimeout("mozOpacity1();", mozSeconds);
    mozSeconds += 2300;
    mt5 = setTimeout("mozOpacity2();", mozSeconds);
    mozSeconds += 2300;
    mt5 = setTimeout("mozOpacity3();", mozSeconds);
    mozSeconds += 2300;
    mt5 = setTimeout("mozOpacity4();", mozSeconds);
}

</script>
</div> 
