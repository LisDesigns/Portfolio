
function submitChoice() {
  alert("test");
  //document.forms[i].submit();
}