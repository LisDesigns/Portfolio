  // Onload:

  function init_form() {
    document.getElementById("submitDiv").innerHTML = "<input type='button' value='Submit' onclick='validateForm()' />";
  }

  init_form();
  // Declare variables

  var FirstName, LastName, EmailAddress, comments;
  var errorMessage, englishPattern, EmailPattern;
  var engStr, emaStr;
  FirstName = "";
  LastName = "";
  EmailAddress = "";
  comments = "";
    errorMessage = "<br/><b>Error:</b><br/>";
  engStr = " ";
  emaStr = " ";
  englishPattern = new RegExp(/\<|\>/gi);

  // Get and retieve values

  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
  } 

  function checkEnglish(englishStr) {
    // remove <> characters
    englishPattern = new RegExp(/\<|\>/gi);
    engStr = englishStr.replace(englishPattern, " ");
    return engStr;
  }  

  function getFieldValues() {

    // Get field values.
    Title = document.forms[0].elements[0].value;
    FirstName = document.forms[0].elements[1].value;
    LastName = document.forms[0].elements[2].value;
    Company = document.forms[0].elements[3].value;
    Position = document.forms[0].elements[4].value;
    Address = document.forms[0].elements[5].value;
    Suburb = document.forms[0].elements[6].value;
    State = document.forms[0].elements[7].value;
    PostCode = document.forms[0].elements[8].value;
    Country = document.forms[0].elements[9].value;
    PhoneCode = document.forms[0].elements[10].value;
    PhoneNumber = document.forms[0].elements[11].value;
    Mobile = document.forms[0].elements[12].value;
    FaxCode = document.forms[0].elements[13].value;
    FaxNumber = document.forms[0].elements[14].value;
    Email = document.forms[0].elements[15].value;
    PreferredContactMethod = document.forms[0].elements[16].value;
    Comments = document.forms[0].elements[17].value;

    // Trim fields
    Title = Title.trim();
    FirstName = FirstName.trim();
    LastName = LastName.trim();
    Company = Company.trim();
    Position = Position.trim();
    Address = Address.trim();
    Suburb = Suburb.trim();
    State = State.trim();
    PostCode = PostCode.trim();
    Country = Country.trim();
    PhoneCode = PhoneCode.trim();
    PhoneNumber = PhoneNumber.trim();
    Mobile = Mobile.trim();
    FaxCode = FaxCode.trim();
    FaxNumber = FaxNumber.trim();
    Email = Email.trim();
    PreferredContactMethod = PreferredContactMethod.trim();
    Comments = Comments.trim();

    // Remove unsafe characters
    Title = checkEnglish(Title);
    FirstName = checkEnglish(FirstName);
    LastName = checkEnglish(LastName);
    Company = checkEnglish(Company);
    Position = checkEnglish(Position);
    Address = checkEnglish(Address);
    Suburb = checkEnglish(Suburb);
    State = checkEnglish(State);
    PostCode = checkEnglish(PostCode);
    Country = checkEnglish(Country);
    PhoneCode = checkEnglish(PhoneCode);
    PhoneNumber = checkEnglish(PhoneNumber);
    Mobile = checkEnglish(Mobile);
    FaxCode = checkEnglish(FaxCode);
    FaxNumber = checkEnglish(FaxNumber);
    Email = checkEnglish(Email);
    PreferredContactMethod = checkEnglish(PreferredContactMethod);
    Comments = checkEnglish(Comments);

  }

  function validateEmail(EmailStr) {
    EmailPattern = new RegExp(/^\S+@\S+\.\S+$/gi);
    return EmailPattern.test(EmailStr);   // true or false will be returned 
  }

  function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    return digitPattern.test(digitStr);   // true or false will be returned 
  }


  // On submit click:
  
  function validateForm() {
    document.getElementById("errorMessageDiv").innerHTML = "";
    errorMessage = "<br/><b>Error:</b><br/>";
    testmsg = errorMessage;
    getFieldValues();
    er = 0; 
    
    if ((Title.length == 0) || 
      (FirstName.length == 0) || 
      (LastName.length == 0) ||  
      (Address.length == 0) ||  
      (Suburb.length == 0) || 
      (State.length == 0) || 
      (PostCode.length == 0) || 
      (Country.length == 0) || 
      (PhoneNumber.length == 0) || 
      (Email.length == 0) || 
      (PreferredContactMethod.length == 0))
      {
        errorMessage = errorMessage + "<br/> - Please enter all fields marked with an asterisk(*).";
        er = 1; 
    } 

    if (!(validateEmail(Email))) {
        errorMessage = errorMessage + "<br/> - Please enter a valid Email Address.";
        er = 1; 
    }

    if (PhoneCode.length > 0) {
      if (!validateDigits(PhoneCode)) {
        er = 2; 
      }
    } 
    if (PhoneNumber.length > 0) {
      if (!validateDigits(PhoneNumber)) {
        er = 2; 
      }
    } 
    if (FaxCode.length > 0) {
      if (!validateDigits(FaxCode)) {
        er = 2; 
      }
    } 
    if (FaxNumber.length > 0) {
      if (!validateDigits(FaxNumber)) {
        er = 2; 
      }
    } 
    if (Mobile.length > 0) {
      if (!validateDigits(Mobile)) {
        er = 2; 
      }
    } 
    if (PostCode.length > 0) {
      if (!validateDigits(PostCode)) {
        er = 2; 
      }
    } 

    if (er == 2) {
         errorMessage = errorMessage + "<br/> - Please enter only numbers in the phone, mobile, fax and post code fields.";
    }

    if (er == 0){
       errorMessage = "";
       document.forms[0].submit();
    }
    document.getElementById("errorMessageDiv").innerHTML = errorMessage;

    //document.writeln("Display error message");
    //document.writeln(errorMessage);

  }