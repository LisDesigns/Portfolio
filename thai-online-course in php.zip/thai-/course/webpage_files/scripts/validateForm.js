  // Onload:
  errorMessage="";
  document.getElementById("errorMessageDiv2").innerHTML = errorMessage;
  function init_form() {
    document.getElementById("submitDiv2").innerHTML = "<input type='button' value='Submit' onclick='validateForm()' />";
  }

  // Declare variables

  var FirstName, LastName, EmailAddress, comments;
  var errorMessage, englishPattern, EmailPattern;
  var engStr, emaStr;
  FirstName = "";
  LastName = "";
  EmailAddress = "";

  comments = "";
    errorMessage = "<br/><b>Error:</b><br/>";
  engStr = " ";
  emaStr = " ";
  englishPattern = new RegExp(/\<|\>/gi);

  // Get and retieve values

  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
  } 

  function checkEnglish(englishStr) {
    // remove <> characters
    englishPattern = new RegExp(/\<|\>/gi);
    engStr = englishStr.replace(englishPattern, " ");
    return engStr;
  }  

  function clearForm() {
    // Get field values.
    //document.member.elements[0].value="";
    //document.member.elements[1].value="";
    document.member.elements[2].value="";
    document.member.elements[3].value="";
    document.member.elements[4].value="";
    document.member.elements[5].value="";
    //document.member.elements[6].value="Please select";
    //document.member.elements[7].value="Please select";
    document.member.elements[8].value="";
    document.member.elements[9].value="";
    document.member.elements[10].value="";
    document.member.elements[11].value="";
    document.member.elements[12].value="";
    //document.member.elements[13].value="";
    //document.member.elements[14].value="";
    //document.member.elements[13].value="";
    //document.member.elements[16].value="";
    //document.member.elements[17].value="";
  }

  function clearForm2() {
    // Get field values.
    //document.member.elements[0].value="";
    //document.member.elements[1].value="";
    document.member.elements[2].value="";
    document.member.elements[3].value="";
    document.member.elements[4].value="";
    document.member.elements[5].value="";
    document.member.elements[6].value="";
    document.member.elements[7].value="";
    document.member.elements[8].value="";
    document.member.elements[9].value="";
    document.member.elements[10].value="";
    document.member.elements[11].value="";
    document.member.elements[12].value="";
    //document.member.elements[13].value="";
    //document.member.elements[14].value="";
    //document.member.elements[13].value="";
    //document.member.elements[16].value="";
    //document.member.elements[17].value="";
  }






  function getFieldValues() {

    // Get field values.
   
    Username = document.member.elements[0].value;
    Password = document.member.elements[1].value;
    FirstName = document.member.elements[2].value;
    LastName = document.member.elements[3].value;
    Address = document.member.elements[4].value;
    Suburb = document.member.elements[5].value;
    //State = document.member.elements[6].options[document.member.elements[6].selectedIndex].value;
    //Country = document.member.elements[7].options[document.member.elements[7].selectedIndex].value;
    PostCode = document.member.elements[8].value;
    //PhoneCode = document.member.elements[].value;
    PhoneNumber = document.member.elements[9].value;
    Mobile = document.member.elements[10].value;
    //FaxCode = document.member.elements[].value;
    //FaxNumber = document.member.elements[].value;
    Email = document.member.elements[11].value;
    //PreferredContactMethod = document.member.elements[16].value;
    //Comments = document.member.elements[17].value;

    // Trim fields
    Username = Username.trim();
    Password = Password.trim();
    FirstName = FirstName.trim();
    LastName = LastName.trim();
    Address = Address.trim();
    Suburb = Suburb.trim();
    //State = State.trim();
    PostCode = PostCode.trim();
    //Country = Country.trim();
    //PhoneCode = PhoneCode.trim();
    PhoneNumber = PhoneNumber.trim();
    Mobile = Mobile.trim();
    //FaxCode = FaxCode.trim();
    //FaxNumber = FaxNumber.trim();
    Email = Email.trim();
    //PreferredContactMethod = PreferredContactMethod.trim();
    //Comments = Comments.trim();

    // Remove unsafe characters
    Username = checkEnglish(Username);
    Password = checkEnglish(Password);
    FirstName = checkEnglish(FirstName);
    LastName = checkEnglish(LastName);
    Address = checkEnglish(Address);
    Suburb = checkEnglish(Suburb);
    //State = checkEnglish(State);
    PostCode = checkEnglish(PostCode);
    //Country = checkEnglish(Country);
    //PhoneCode = checkEnglish(PhoneCode);
    PhoneNumber = checkEnglish(PhoneNumber);
    Mobile = checkEnglish(Mobile);
    //FaxCode = checkEnglish(FaxCode);
    //FaxNumber = checkEnglish(FaxNumber);
    Email = checkEnglish(Email);
    //PreferredContactMethod = checkEnglish(PreferredContactMethod);
    //Comments = checkEnglish(Comments);

  }

  function validateEmail(EmailStr) {
    EmailPattern = new RegExp(/^\S+@\S+\.\S+$/gi);
    return EmailPattern.test(EmailStr);   // true or false will be returned 
  }

  function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    return digitPattern.test(digitStr);   // true or false will be returned 
  }


  // On submit click:
  
  function validateForm() {
  errorMessage="";
  document.getElementById("errorMessageDiv2").innerHTML = errorMessage;
    document.getElementById("errorMessageDiv2").innerHTML = "";
    errorMessage = "<br/><b>Error:</b>";
    testmsg = errorMessage;


    //alert("test");

    getFieldValues();
    er = 0; 
       //alert("test");
    if ((FirstName.length == 0) || 
      (LastName.length == 0) ||  
      (Address.length == 0) || 
      (Suburb.length == 0) || 
      (PostCode.length == 0) ||  
      (PhoneNumber.length == 0) || 
      (Email.length == 0))
      {
      //(Suburb.length == 0) || 
      //(State.length == 0) || 

        errorMessage = errorMessage + "<br/> - Please enter all fields marked with an asterisk(*).";
        er = 1; 
    } 
    /*
    if (!(validateEmail(Email))) {
        errorMessage = errorMessage + "<br/> - Please enter a valid Email Address.";
        er = 4; 
    }

    if (PhoneCode.length > 0) {
      if (!validateDigits(PhoneCode)) {
        er = 2; 
      }
    } 
    
    if (PhoneNumber.length > 0) {
      if (!validateDigits(PhoneNumber)) {
        er = 2; 
      }
    }
    */
    /* 
    if (FaxCode.length > 0) {
      if (!validateDigits(FaxCode)) {
        er = 2; 
      }
    } 
    //if (FaxNumber.length > 0) {
      //if (!validateDigits(FaxNumber)) {
        //er = 2; 
      //}
    //} 
    */
    /*
    if (Mobile.length > 0) {
      if (!validateDigits(Mobile)) {
        er = 2; 
      }
    } 
    if (PostCode.length > 0) {
      if (validateDigits(PostCode)) {
        er = 2; 
      }
    } 
    */

    if (er == 2) {
         errorMessage = errorMessage + "<br/> - Please enter only numbers in the phone, mobile and post code fields.";
    }

    if (er == 0){
       errorMessage = "";
       document.forms["member"].submit();
    }
    document.getElementById("errorMessageDiv2").innerHTML = errorMessage;

  }
  
  init_form();
