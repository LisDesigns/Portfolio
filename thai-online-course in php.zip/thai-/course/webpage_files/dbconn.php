<?php

//$username = "root";
//$Password = "";


$username = "learnspeakthai";
$Password = "zCB4v9qI";

$host = "learnspeakthai.db.3633375.hostedresource.com";
$connection = mysql_connect($host,$username,$Password);
//$connection = mysql_connect("localhost",$username,$Password);
if (!$connection) {
  die('Could not connect: ' . mysql_error());
}
$databaseName = "learnspeakthai";
//$databaseName = "thai";
mysql_select_db($databaseName, $connection) or die('Could not select the database: '.mysql_error());

?>