<?php

echo "<br/>".$_FILES["file1"]["type"];

echo "<br/>".$_FILES["file2"]["type"]."<br/>";

if (($_FILES["s1"]["type"] == "audio/mpeg")
&& ($_FILES["s1"]["size"] < 20000000000))
  {
  if ($_FILES["s1"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["s1"]["error"] . "<br />";
    }
  else
    {
    echo "images: " . $_FILES["s1"]["name"] . "<br />";
    echo "Type: " . $_FILES["s1"]["type"] . "<br />";
    echo "Size: " . ($_FILES["s1"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["s1"]["tmp_name"] . "<br />";

    if (file_exists("images/" . $_FILES["s1"]["name"]))
      {
      echo $_FILES["file1"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["s1"]["tmp_name"],
      "images/" . $_FILES["s1"]["name"]);
      echo "Stored in: " . "images/" . $_FILES["s1"]["name"];
      }
    }
  } else
  {
  echo "Invalid Mp3 file";
  }

if (($_FILES["file2"]["type"] == "image/jpeg")
&& ($_FILES["file2"]["size"] < 20000000000))
  {
  if ($_FILES["file2"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file2"]["error"] . "<br />";
    }
  else
    {
    echo "images: " . $_FILES["file2"]["name"] . "<br />";
    echo "Type: " . $_FILES["file2"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file2"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["file2"]["tmp_name"] . "<br />";

    if (file_exists("images/" . $_FILES["file2"]["name"]))
      {
      echo $_FILES["file2"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file2"]["tmp_name"],
      "images/" . $_FILES["file2"]["name"]);
      echo "Stored in: " . "images/" . $_FILES["file2"]["name"];
      }
    }
  }
else
  {
  echo "Invalid Jpg file";
  }

?> 