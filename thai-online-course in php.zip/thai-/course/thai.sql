-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 14, 2011 at 12:51 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `thai`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE IF NOT EXISTS `chapters` (
  `orderId` int(100) NOT NULL,
  `lessonId` int(100) NOT NULL,
  `chapterId` int(100) NOT NULL AUTO_INCREMENT,
  `chapter_name` varchar(200) NOT NULL,
  `chapter_heading` varchar(200) NOT NULL,
  PRIMARY KEY (`chapterId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`orderId`, `lessonId`, `chapterId`, `chapter_name`, `chapter_heading`) VALUES
(0, 0, 17, 'Chapter 1', 'Chapter 1 dfgdfgd'),
(0, 333, 0, 'Chapter 2', 'Chapter 2'),
(0, 0, 18, 'Chapter 5', 'Chapter 3'),
(0, 0, 4, 'Chapter 6', 'Chapter 4'),
(0, 0, 19, 'Chapter 7', 'Chapter 5'),
(0, 0, 20, 'Chapter 8', 'Chapter 6'),
(0, 0, 22, '', 'Introductory Chapter');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE IF NOT EXISTS `lessons` (
  `slideId` int(100) NOT NULL,
  `lessonId` int(100) NOT NULL AUTO_INCREMENT,
  `chapterId` int(100) NOT NULL,
  `lesson_heading` varchar(200) NOT NULL,
  `lesson_name` varchar(200) NOT NULL,
  PRIMARY KEY (`lessonId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`slideId`, `lessonId`, `chapterId`, `lesson_heading`, `lesson_name`) VALUES
(5, 1, 1, 'How to Say Hello', 'How to Say Hello'),
(3, 2, 1, 'How to Say GoodBye', 'How to Say GoodBye'),
(0, 3, 1, 'How to Say How Are You?', 'How to Say How Are You'),
(0, 4, 1, 'How to Say Please and Thankyou', 'How to Say Please and Thankyou'),
(0, 5, 0, 'fhgfhgf', 'dfdddf'),
(0, 10, 2, 'gfgfgffhf', 'dffdddd'),
(0, 8, 3, 'fgdgdgddgddg', 'sdfsdfsdfsdfsdf'),
(0, 11, 0, 'fddfddd', 'dgdfdghggg'),
(0, 12, 2, 'fgfgffgfgf', 'sdfddffffff'),
(0, 13, 6, 'ddfsdfdfs', 'fdsdffdsfd'),
(0, 14, 2, 'fghffgfg', 'fgfgfh'),
(0, 15, 18, 'gjhgjg', 'gghhhhhh'),
(0, 16, 4, 'dffdddf', 'fghghghhghh'),
(0, 17, 1002, 'fghfgfggggg', 'fgghfgfffffffffff'),
(0, 18, 5, 'fffffffffff', 'sddsssssssssssssss'),
(0, 19, 17, 'ccccccccccc', 'dddddddddd'),
(0, 25, 2, 'ghgfh', 'ghghfh'),
(0, 21, 5, 'llllllllllllllll', 'dddddddddd'),
(0, 22, 17, 'vvvvvvgtgtttty', 'cccccccccc'),
(0, 23, 1000, '', ''),
(0, 24, 5, 'bnvbb', 'bnvnbvbn'),
(0, 26, 20, 'ddttt', 'bnnvvnbnghh'),
(0, 27, 4, 'test', 'test'),
(0, 28, 19, 'ghfgfgh', 'hgfggh'),
(0, 29, 20, 'gggggg®', 'g®gggg®'),
(0, 20, 21, '®®®', '®®®'),
(0, 31, 20, '‘_Na’ ', ''),
(0, 32, 19, '‘_Na’ ', '‘_Na’ '),
(0, 33, 17, 'Na', 'Na');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `MemberId` int(200) NOT NULL AUTO_INCREMENT,
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Suburb` varchar(200) NOT NULL,
  `State` varchar(200) NOT NULL,
  `Country` varchar(200) NOT NULL,
  `PostCode` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Mobile` varchar(100) NOT NULL,
  `Email` varchar(200) NOT NULL,
  PRIMARY KEY (`MemberId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`MemberId`, `Username`, `Password`, `FirstName`, `LastName`, `Address`, `Suburb`, `State`, `Country`, `PostCode`, `Phone`, `Mobile`, `Email`) VALUES
(2, 'ewqwe', 'eqwqwe', 'weqwe', 'ewqeqwqwe', 'hjjh hjkkh', 'gjghgh', 'QLD', '', '', '', '', ''),
(4, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', '', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(15, '', '', '', '', '', '', 'NSW', 'Please select', '', '', '', ''),
(16, '', '', '', '', '', '', 'Please select', 'Please select', '', '', '', ''),
(6, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', '', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(7, 'gjghghg', '', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '', '', 'fghgh@fgfgh.com'),
(8, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(9, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(10, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(11, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(12, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(13, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com'),
(14, 'gjghghg', 'ghff', 'fgfhf', 'hjhhjkhj', 'fgfgf', 'sssdfsdfsdf', 'VIC', 'Australia', '1213', '576567556', '456454454464', 'fghgh@fgfgh.com');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `PaymentId` int(100) NOT NULL AUTO_INCREMENT,
  `DatePaid` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `PaymentAmount` float(10,2) DEFAULT NULL,
  `MembershipType` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`PaymentId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `payments`
--


-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE IF NOT EXISTS `sections` (
  `sectionId` int(100) NOT NULL AUTO_INCREMENT,
  `chapterId` int(100) DEFAULT NULL,
  `lessonId` int(11) DEFAULT NULL,
  `section_heading` varchar(200) DEFAULT NULL,
  `section_picture` varchar(200) DEFAULT NULL,
  `section_sound` varchar(200) NOT NULL,
  `section_text` varchar(1000) DEFAULT NULL,
  `language` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sectionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`sectionId`, `chapterId`, `lessonId`, `section_heading`, `section_picture`, `section_sound`, `section_text`, `language`) VALUES
(1, 12, 1, '12', '12', '', '12', 'English'),
(3, 1, 2, 'Subheading', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum<font face="Isaana 2008-23, serif">&#183;</font>	Ut enim lacus, aliquet ac auctor eu, euismod sed mauris. Cras mollis elementum consequat. Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis<font face="Isaana 2008-23, serif">	&#183;	</font> Proin ut consectetur sapien. Suspendisse eu orci lacus. Sed faucibus, erat et fermentum venenatis, nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulputate luctus. Quisque dapibus condimentum vulputate. Nullam eget dui nec neque faucibus laoreet imperdiet eget nulla. Nam tempor magna eget risus condimentum pharetra euismod erat placerat. ', 'English'),
(4, 1, 2, 'Section 2', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(5, 1, 3, 'Subheading', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'Thai'),
(6, 1, 3, 'Section 2', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(7, 1, 4, 'Subheading', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(2, 1, 1, 'Section 1', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(28, 1, 5, 'Section 1', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(8, 1, 4, 'Subheading', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'Thai'),
(14, 1, 4, 'Subheading', 'picture.jpg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel odio sed libero vulputate interdum. <font face="Isaana 2008-23, serif">&#175;</font>Ut enim lacus, aliquet ac auctor eu,<font face="Isaana 2008-23, serif">&#176;</font> euismod sed<font face="Isaana 2008-23, serif">&#177;</font> mauris. Cras mollis elementum consequat. <font face="Isaana 2008-23, serif">&#178;</font>Suspendisse ut dui ut turpis volutpat aliquam at eget magna. Nam &nbsp;\r\n<font face="Isaana 2008-23, serif">&#181;</font>venenatis viverra laoreet. Vivamus aliquet pellentesque venenatis. Proin ut consectetur sapien. Suspendisse eu orci lacus. <font face="Isaana 2008-23, serif">&#179;</font>Sed faucibus, erat et fermentum venenatis,<font face="Isaana 2008-23, serif">&#180;</font> nulla tortor viverra nulla, eu luctus ante arcu vel metus. Ut luctus venenatis quam, sed laoreet ipsum <font face="Isaana 2008-23, serif">&#174;</font>ornare at. Mauris convallis urna at nibh sodales fringilla. Integer lacinia vulpu', 'English'),
(29, 0, 0, 'gfdfgfdgdfgdf', 'Array', '', 'gfgfgfgggggfd gffgdfg gfdfgdfg gfdgfdgd', NULL),
(30, 0, 0, 'test', 'Array', '', 'dfdd fff fgfghfgfgf fghgffghfg hfghfghfghfh hgfghfghf hgfhgfghfggfgh', 'English'),
(31, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(32, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(33, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(34, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(35, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(36, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(37, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(38, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(39, 12, 1, 'gggguyuyuy', 'Array', '', 'ghghghghgh', 'English'),
(40, 4, 27, 'gg', 'Array', 'Array', 'fvfgh fghfghf ghfgfghfh fghfghfghgfhg fghfghf ytuytuyjhgjh iuyiuyjhxfdxfdg', 'English'),
(41, 4, 27, 'gg', 'Array', 'Array', 'fvfgh fghfghf ghfgfghfh fghfghfghgfhg fghfghf ytuytuyjhgjh iuyiuyjhxfdxfdg', 'English'),
(42, 4, 27, 'gg', 'Array', 'Array', 'fvfgh fghfghf ghfgfghfh fghfghfghgfhg fghfghf ytuytuyjhgjh iuyiuyjhxfdxfdg', 'English'),
(43, 2, 10, 'gfgffgdfgdgfgfg', 'Array', 'Array', 'gddgfgfgfgdggfgf fgdgff dfgdg dg', 'English'),
(57, 17, 22, '', 'Array', 'Array', 'ergrrgrgregf', 'English'),
(58, 17, 19, 'ffffff', 'Array', 'Array', 'fe<FONT color=#99ff33>s</FONT>fs<FONT color=#00ff66>dfd<FONT color=#ffcccc>fsf</FONT><FONT color=#996633>sdfs</FONT><FONT color=#3333cc>dfsfdsbvcfb</FONT>dfgfdfgdfg</FONT>', 'English'),
(46, 17, 19, 'aaaaaaaaaaaaa', 'Array', 'Array', 'jhh<FONT color=#996633>jh</FONT><FONT color=#99ff33>hhjjjssssssccc</FONT>ccs', 'English'),
(47, 17, 19, 'refwefrwer', 'Array', 'Array', 're<FONT color=#996699>wwer</FONT>erw re<FONT color=#00ff99>wwrew</FONT>er errw<FONT color=#ff6600>erewer</FONT>', 'Thai'),
(48, 17, 22, '', 'Array', 'Array', '', 'English'),
(49, 20, 26, 'gfhgghfg', 'Array', 'Array', 'fhfgfhgccccccc', 'Thai'),
(50, 1, 5, 'gggggg', 'Array', 'Array', '®®®gfdfgdfdf gfdggfgfg®', 'Thai'),
(51, 20, 29, '®®®®®', 'Array', 'Array', '®®®®', 'Thai'),
(52, 21, 30, '®®®', 'Array', 'Array', '®®® ®® ®® ®®xaaaadfdd', 'Thai'),
(53, 21, 30, 'ffff', 'Array', 'Array', 'fffffff', 'Thai'),
(54, 21, 30, '', 'Array', 'Array', 'gghhg gjhgjhgjghg hgjhgjhgjkjg ghhjgjhgjhgjhgkgh jhjkhjkhlkjhjklhk ffytftyfyfty', 'Thai'),
(55, 19, 28, 'fdgfdgfd', 'Array', 'Array', 'fdgfddf', 'Thai'),
(56, 17, 19, 'jhh', 'Array', 'Array', 'hj<FONT color=#3333ff>kjhhhjkh</FONT>hjh', 'Thai'),
(59, 4, 16, 'gfd', 'Array', 'Array', 'hgffh<FONT color=#33cccc>fhfg</FONT>', 'English'),
(60, 17, 33, 'Na', 'Array', 'Array', '<FONT size=5>\r\n<P align=justify>‘_Na’ is a polite particle that is used in three main ways:</P></FONT><FONT face="Courier New" size=5>\r\n<P>o </FONT><B><U><FONT size=5><FONT face="Times New Roman">With commands</FONT></B></U><FONT face="Times New Roman"> and invitations to add encouragement or urgency. </FONT></P></FONT>', 'English'),
(61, 17, 33, '', 'Array', 'Array', '<FONT color=#7f0000 size=5>\r\n<P>¥Ork</FONT><FONT color=#007f00 size=5> bpy</FONT><FONT size=5> </FONT><FONT color=#0000ff size=5>_na!</FONT></P><FONT color=#0000ff size=5><FONT color=#7f0000 size=5>\r\n<P>&#3629;&#3629;&#3585;</FONT><FONT color=#007f00 size=5>&#3652;&#3611;</FONT><FONT color=#0000ff size=5>&#3609;&#3632;</FONT></P><FONT color=#0000ff size=5><FONT color=#7f0000 size=5>\r\n<P>Go </FONT><FONT color=#007f00 size=5>away</FONT><FONT color=#0000ff size=5>!</P></FONT></FONT></FONT>', 'Thai'),
(62, 17, 33, '', 'Array', 'Array', '<P>‘_Na’ is a polite particle that is used in three main ways:</P>\r\n<P>o With commands and invitations to add encouragement or urgency. </P>', 'English'),
(63, 17, 33, '', 'Array', 'Array', '‘¥La’ is often used in conjunction with the polite particle ‘k_rap’ / ßka’, reinforcing the polite intent of what is being said. The tone of ‘_la’ changes to a high tone (‘_la’) when used with ‘k±rap/ ‘ßka’.<BR>', 'Thai');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE IF NOT EXISTS `slides` (
  `slideId` int(100) NOT NULL AUTO_INCREMENT,
  `lessonId` int(100) NOT NULL,
  `chapterId` int(100) NOT NULL,
  `slide_image` varchar(100) NOT NULL,
  `slide_sound` varchar(100) NOT NULL,
  PRIMARY KEY (`slideId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`slideId`, `lessonId`, `chapterId`, `slide_image`, `slide_sound`) VALUES
(1, 1, 4, '', ''),
(8, 1, 1, 'picture2.jpg', 'sound.mp3'),
(3, 0, 0, 'picture3.jpg', 'sound.mp3'),
(4, 0, 0, 'picture2.jpg', 'sound.mp3'),
(7, 0, 0, 'picture4.jpg', 'sound.mp3'),
(6, 5, 2, 'picture2.jpg', 'sound.mp3'),
(9, 0, 0, 'picture1.jpg', 'sound.mp3'),
(14, 1, 4, 'Picture', 'Sound'),
(15, 1, 4, 'Picture', 'Sound'),
(16, 1, 4, 'Picture', 'Sound'),
(17, 1, 4, 'Picture', 'Sound'),
(18, 1, 4, 'Picture', 'Sound'),
(19, 1, 4, 'Picture', 'Sound'),
(20, 1, 4, 'Picture', 'Sound'),
(21, 1, 4, 'Picture', 'Sound'),
(22, 0, 0, 'Picture', 'Sound'),
(23, 0, 0, 'Picture', 'Sound'),
(24, 1, 4, 'Picture', 'Sound'),
(25, 1, 4, 'Picture', 'Sound'),
(26, 1, 4, 'Picture', 'Sound'),
(36, 19, 0, 'Picture', 'Sound'),
(35, 19, 0, 'Picture', 'Sound');
