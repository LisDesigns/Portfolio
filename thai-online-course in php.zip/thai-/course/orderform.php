<?php

$qty298 = $_REQUEST["qty298"];
$qty156 = $_REQUEST["qty156"];
$qty150 = $_REQUEST["qty150"];
$qty171 = $_REQUEST["qty171"];
$qty174 = $_REQUEST["qty174"];
$qty197 = $_REQUEST["qty197"];
$qty158 = $_REQUEST["qty158"];
$qty151 = $_REQUEST["qty151"];
$qty176 = $_REQUEST["qty176"];
$qty180 = $_REQUEST["qty180"];
$qty827 = $_REQUEST["qty827"];
$qty951 = $_REQUEST["qty951"];
$qty952 = $_REQUEST["qty952"];
$qty953 = $_REQUEST["qty953"];
$qty170 = $_REQUEST["qty170"];
$qty163 = $_REQUEST["qty163"];
$qty177 = $_REQUEST["qty177"];
$qty173 = $_REQUEST["qty173"];
$qty204 = $_REQUEST["qty204"];

$qty198S = $_REQUEST["qty198S"];
$qty198 = $_REQUEST["qty198"];
$qty830 = $_REQUEST["qty830"];
$qty1140 = $_REQUEST["qty1140"];
$qty226 = $_REQUEST["qty226"];
$qty243 = $_REQUEST["qty243"];
$qty2230 = $_REQUEST["qty2230"];
$qty258 = $_REQUEST["qty258"];

$opt2_215 = $_REQUEST["opt2_215"];
$opt2_275 = $_REQUEST["opt2_275"];
$opt2_284 = $_REQUEST["opt2_284"];
$opt2_225 = $_REQUEST["opt2_225"];
$opt2_293 = $_REQUEST["opt2_293"];
$opt2_257 = $_REQUEST["opt2_257"];
$opt2_295 = $_REQUEST["opt2_295"];
$opt2_274 = $_REQUEST["opt2_274"];
$opt2_2220 = $_REQUEST["opt2_2220"];
$opt2_291 = $_REQUEST["opt2_291"];
$opt2_297 = $_REQUEST["opt2_297"];
$opt2_297B = $_REQUEST["opt2_297B"];
$opt2_298 = $_REQUEST["opt2_298"];
$opt2_158 = $_REQUEST["opt2_158"];
$opt2_151 = $_REQUEST["opt2_151"];
$opt2_176 = $_REQUEST["opt2_176"];
$opt2_180 = $_REQUEST["opt2_180"];
$opt2_827 = $_REQUEST["opt2_827"];
$opt2_951 = $_REQUEST["opt2_951"];
$opt2_952 = $_REQUEST["opt2_952"];
$opt2_953 = $_REQUEST["opt2_953"];
$opt2_170 = $_REQUEST["opt2_170"];
$opt2_177 = $_REQUEST["opt2_177"];
$opt2_173 = $_REQUEST["opt2_173"];
$opt2_198S = $_REQUEST["opt2_198S"];
$opt2_198 = $_REQUEST["opt2_198"];
$opt2_830 = $_REQUEST["opt2_830"];
$opt2_1140 = $_REQUEST["opt2_1140"];
$opt2_226 = $_REQUEST["opt2_226"];
$opt2_243 = $_REQUEST["opt2_243"];
$opt2_2230 = $_REQUEST["opt2_2230"];
$opt2_258 = $_REQUEST["opt2_258"];
$opt2_204 = $_REQUEST["opt2_204"];

$opt1_275 = $_REQUEST["opt1_275"];
$opt1_284 = $_REQUEST["opt1_284"];
$opt1_293 = $_REQUEST["opt1_293"];
$opt1_274 = $_REQUEST["opt1_274"];
$opt1_2220 = $_REQUEST["opt1_2220"];
$opt1_158 = $_REQUEST["opt1_158"];
$opt1_176 = $_REQUEST["opt1_176"];
$opt1_180 = $_REQUEST["opt1_180"];
$opt1_827 = $_REQUEST["opt1_827"];
$opt1_952 = $_REQUEST["opt1_952"];
$opt1_953 = $_REQUEST["opt1_953"];
$opt1_150 = $_REQUEST["opt1_150"];
$opt1_156 = $_REQUEST["opt1_156"];
$opt1_197 = $_REQUEST["opt1_197"];
$opt1_163 = $_REQUEST["opt1_163"];
$opt1_198S = $_REQUEST["opt1_198S"];
$opt1_198 = $_REQUEST["opt1_198"];
$opt1_830 = $_REQUEST["opt1_830"];
$opt1_1140 = $_REQUEST["opt1_1140"];
$opt1_226 = $_REQUEST["opt1_226"];
$opt1_243 = $_REQUEST["opt1_243"];
$opt1_2230 = $_REQUEST["opt1_2230"];
$opt1_258 = $_REQUEST["opt1_258"];
$opt1_204 = $_REQUEST["opt1_204"];

$item215 = $_REQUEST["item215"];
$item275 = $_REQUEST["item275"];
$item284 = $_REQUEST["item284"];
$item225 = $_REQUEST["item225"];
$item293 = $_REQUEST["item293"];
$item257 = $_REQUEST["item257"];
$item295 = $_REQUEST["item295"];
$item274 = $_REQUEST["item274"];
$item2220 = $_REQUEST["item2220"];
$item291 = $_REQUEST["item291"];
$item297 = $_REQUEST["item297"];
$item297B = $_REQUEST["item297B"];
$item298 = $_REQUEST["item298"];
$item156 = $_REQUEST["item156"];
$item150 = $_REQUEST["item150"];
$item171 = $_REQUEST["item171"];
$item174 = $_REQUEST["item174"];
$item197 = $_REQUEST["item197"];
$item158 = $_REQUEST["item158"];
$item151 = $_REQUEST["item151"];
$item176 = $_REQUEST["item176"];
$item180 = $_REQUEST["item180"];
$item827 = $_REQUEST["item827"];
$item951 = $_REQUEST["item951"];
$item952 = $_REQUEST["item952"];
$item953 = $_REQUEST["item953"];
$item170 = $_REQUEST["item170"];
$item163 = $_REQUEST["item163"];
$item177 = $_REQUEST["item177"];
$item173 = $_REQUEST["item173"];

$item198S = $_REQUEST["item198S"];
$item198 = $_REQUEST["item198"];
$item830 = $_REQUEST["item830"];
$item1140 = $_REQUEST["item1140"];
$item226 = $_REQUEST["item226"];
$item243 = $_REQUEST["item243"];
$item2230 = $_REQUEST["item2230"];
$item258 = $_REQUEST["item258"];
$item204 = $_REQUEST["item204"];

$firstname = $_REQUEST["firstname"];
$lastname = $_REQUEST["lastname"];
$phone = $_REQUEST["phone"];
$mobile = $_REQUEST["mobile"];
$email = $_REQUEST["email"];
$address = $_REQUEST["address"];
$suburb = $_REQUEST["suburb"];
$state = $_REQUEST["state"];
$postcode = $_REQUEST["postcode"];
$country = $_REQUEST["country"];

$message ="\n\nSharifWear Australia Online Order:\n";

if (!empty($qty215)) {$message .= "\n\nItem Name: ".$item215." Size: ".$opt2_215." Quantity: ".$qty215; }
if (!empty($qty275)) {$message .= "\n\nItem Name: ".$item275." Colour: ".$opt1_275." Size: ".$opt2_275." Quantity: ".$qty275; }
if (!empty($qty284)) {$message .= "\n\nItem Name: ".$item284." Colour: ".$opt1_284." Size: ".$opt2_284." Quantity: ".$qty284; }
if (!empty($qty225)) {$message .= "\n\nItem Name: ".$item225." Size: ".$opt2_225." Quantity: ".$qty225; }
if (!empty($qty293)) {$message .= "\n\nItem Name: ".$item293." Colour: ".$opt1_293." Size: ".$opt2_293." Quantity: ".$qty293; }
if (!empty($qty257)) {$message .= "\n\nItem Name: ".$item257." Size: ".$opt2_257." Quantity: ".$qty257; }
if (!empty($qty295)) {$message .= "\n\nItem Name: ".$item295." Size: ".$opt2_295." Quantity: ".$qty295; }
if (!empty($qty274)) {$message .= "\n\nItem Name: ".$item274." Colour: ".$opt1_274." Size: ".$opt2_274." Quantity: ".$qty274; }
if (!empty($qty2220)) {$message .= "\n\nItem Name: ".$item2220." Colour: ".$opt1_2220." Size: ".$opt2_2220." Quantity: ".$qty2220; }
if (!empty($qty291)) {$message .= "\n\nItem Name: ".$item291." Size: ".$opt2_291." Quantity: ".$qty291; }
if (!empty($qty297)) {$message .= "\n\nItem Name: ".$item297." Size: ".$opt2_297." Quantity: ".$qty297; }
if (!empty($qty297B)) {$message .= "\n\nItem Name: ".$item297B." Size: ".$opt2_297B." Quantity: ".$qty297B; }
if (!empty($qty298)) {$message .= "\n\nItem Name: ".$item298." Size: ".$opt2_298." Quantity: ".$qty298; }
if (!empty($qty156)) {$message .= "\n\nItem Name: ".$item156." Colour: ".$opt1_156." Quantity: ".$qty156; }
if (!empty($qty150)) {$message .= "\n\nItem Name: ".$item150." Colour: ".$opt1_150." Quantity: ".$qty150; }
if (!empty($qty171)) {$message .= "\n\nItem Name: ".$item171." Quantity: ".$qty171; }
if (!empty($qty174)) {$message .= "\n\nItem Name: ".$item174." Quantity: ".$qty174; }
if (!empty($qty197)) {$message .= "\n\nItem Name: ".$item197." Colour: ".$opt1_197." Quantity: ".$qty197; }
if (!empty($qty158)) {$message .= "\n\nItem Name: ".$item158." Colour: ".$opt1_158." Size: ".$opt2_158." Quantity: ".$qty158; }
if (!empty($qty151)) {$message .= "\n\nItem Name: ".$item151." Size: ".$opt2_151." Quantity: ".$qty151; }
if (!empty($qty176)) {$message .= "\n\nItem Name: ".$item176." Colour: ".$opt1_176." Size: ".$opt2_176." Quantity: ".$qty176; }
if (!empty($qty180)) {$message .= "\n\nItem Name: ".$item180." Colour: ".$opt1_180." Size: ".$opt2_180." Quantity: ".$qty180; }
if (!empty($qty827)) {$message .= "\n\nItem Name: ".$item827." Colour: ".$opt1_827." Size: ".$opt2_827." Quantity: ".$qty827; }
if (!empty($qty951)) {$message .= "\n\nItem Name: ".$item951." Size: ".$opt2_951." Quantity: ".$qty951; }
if (!empty($qty952)) {$message .= "\n\nItem Name: ".$item952." Colour: ".$opt1_952." Size: ".$opt2_952." Quantity: ".$qty952; }
if (!empty($qty953)) {$message .= "\n\nItem Name: ".$item953." Colour: ".$opt1_953." Size: ".$opt2_953." Quantity: ".$qty953; }
if (!empty($qty170)) {$message .= "\n\nItem Name: ".$item170." Size: ".$opt2_170." Quantity: ".$qty170; }
if (!empty($qty163)) {$message .= "\n\nItem Name: ".$item163." Colour: ".$opt1_163." Quantity: ".$qty163; }
if (!empty($qty177)) {$message .= "\n\nItem Name: ".$item177." Size: ".$opt2_177." Quantity: ".$qty177; }
if (!empty($qty173)) {$message .= "\n\nItem Name: ".$item173." Size: ".$opt2_173." Quantity: ".$qty173; }


if (!empty($qty198S)) {$message .= "\n\nItem Name: ".$item198S." Colour: ".$opt1_198S." Size: ".$opt2_198S." Quantity: ".$qty198S; }
if (!empty($qty198)) {$message .= "\n\nItem Name: ".$item198." Colour: ".$opt1_198." Size: ".$opt2_198." Quantity: ".$qty198; }
if (!empty($qty830)) {$message .= "\n\nItem Name: ".$item830." Colour: ".$opt1_830." Size: ".$opt2_830." Quantity: ".$qty830; }
if (!empty($qty1140)) {$message .= "\n\nItem Name: ".$item1140." Colour: ".$opt1_1140." Size: ".$opt2_1140." Quantity: ".$qty1140; }
if (!empty($qty226)) {$message .= "\n\nItem Name: ".$item226." Colour: ".$opt1_226." Size: ".$opt2_226." Quantity: ".$qty226; }
if (!empty($qty243)) {$message .= "\n\nItem Name: ".$item243." Colour: ".$opt1_243." Size: ".$opt2_243." Quantity: ".$qty243; }
if (!empty($qty2230)) {$message .= "\n\nItem Name: ".$item2230." Colour: ".$opt1_2230." Size: ".$opt2_2230." Quantity: ".$qty2230; }
if (!empty($qty258)) {$message .= "\n\nItem Name: ".$item258." Colour: ".$opt1_258." Size: ".$opt2_258." Quantity: ".$qty258; }


if (!empty($qty204)) {$message .= "\n\nItem Name: ".$item204." Colour: ".$opt1_204." Size: ".$opt2_204." Quantity: ".$qty204; }


$message .="\n\n\nShipping Details:\n";

$message .= "\nFirst Name: ".$firstname;
$message .= "\nLast Name: ".$lastname;
$message .= "\nEmail: ".$email;
$message .= "\nPhone: ".$phone;
$message .= "\nMobile: ".$mobile;
$message .= "\nAddress: ".$address;
$message .= "\nSuburb: ".$suburb;
$message .= "\nState: ".$state;
$message .= "\nPost Code: ".$postcode;
$message .= "\nCountry: ".$country;



  //mail("orders@sharifwear-aus.com.au", "Online Order", $message, "From: ".$email);
  mail("orders@sharifwear-aus.com.au,lisa@lisdesigns.com.au", "Sharifwear Online Order", $message, "From: ".$email);

$message ="\n\nSharifWear Australia Order Confirmation:\n";

if (!empty($qty215)) {$message .= "\n\nItem Name: ".$item215." Size: ".$opt2_215." Quantity: ".$qty215; }
if (!empty($qty275)) {$message .= "\n\nItem Name: ".$item275." Colour: ".$opt1_275." Size: ".$opt2_275." Quantity: ".$qty275; }
if (!empty($qty284)) {$message .= "\n\nItem Name: ".$item284." Colour: ".$opt1_284." Size: ".$opt2_284." Quantity: ".$qty284; }
if (!empty($qty225)) {$message .= "\n\nItem Name: ".$item225." Size: ".$opt2_225." Quantity: ".$qty225; }
if (!empty($qty293)) {$message .= "\n\nItem Name: ".$item293." Colour: ".$opt1_293." Size: ".$opt2_293." Quantity: ".$qty293; }
if (!empty($qty257)) {$message .= "\n\nItem Name: ".$item257." Size: ".$opt2_257." Quantity: ".$qty257; }
if (!empty($qty295)) {$message .= "\n\nItem Name: ".$item295." Size: ".$opt2_295." Quantity: ".$qty295; }
if (!empty($qty274)) {$message .= "\n\nItem Name: ".$item274." Colour: ".$opt1_274." Size: ".$opt2_274." Quantity: ".$qty274; }
if (!empty($qty2220)) {$message .= "\n\nItem Name: ".$item2220." Colour: ".$opt1_2220." Size: ".$opt2_2220." Quantity: ".$qty2220; }
if (!empty($qty291)) {$message .= "\n\nItem Name: ".$item291." Size: ".$opt2_291." Quantity: ".$qty291; }
if (!empty($qty297)) {$message .= "\n\nItem Name: ".$item297." Size: ".$opt2_297." Quantity: ".$qty297; }
if (!empty($qty297B)) {$message .= "\n\nItem Name: ".$item297B." Size: ".$opt2_297B." Quantity: ".$qty297B; }
if (!empty($qty298)) {$message .= "\n\nItem Name: ".$item298." Size: ".$opt2_298." Quantity: ".$qty298; }
if (!empty($qty156)) {$message .= "\n\nItem Name: ".$item156." Colour: ".$opt1_156." Quantity: ".$qty156; }
if (!empty($qty150)) {$message .= "\n\nItem Name: ".$item150." Colour: ".$opt1_150." Quantity: ".$qty150; }
if (!empty($qty171)) {$message .= "\n\nItem Name: ".$item171." Quantity: ".$qty171; }
if (!empty($qty174)) {$message .= "\n\nItem Name: ".$item174." Quantity: ".$qty174; }
if (!empty($qty197)) {$message .= "\n\nItem Name: ".$item197." Colour: ".$opt1_197." Quantity: ".$qty197; }
if (!empty($qty158)) {$message .= "\n\nItem Name: ".$item158." Colour: ".$opt1_158." Size: ".$opt2_158." Quantity: ".$qty158; }
if (!empty($qty151)) {$message .= "\n\nItem Name: ".$item151." Size: ".$opt2_151." Quantity: ".$qty151; }
if (!empty($qty176)) {$message .= "\n\nItem Name: ".$item176." Colour: ".$opt1_176." Size: ".$opt2_176." Quantity: ".$qty176; }
if (!empty($qty180)) {$message .= "\n\nItem Name: ".$item180." Colour: ".$opt1_180." Size: ".$opt2_180." Quantity: ".$qty180; }
if (!empty($qty827)) {$message .= "\n\nItem Name: ".$item827." Colour: ".$opt1_827." Size: ".$opt2_827." Quantity: ".$qty827; }
if (!empty($qty951)) {$message .= "\n\nItem Name: ".$item951." Size: ".$opt2_951." Quantity: ".$qty951; }
if (!empty($qty952)) {$message .= "\n\nItem Name: ".$item952." Colour: ".$opt1_952." Size: ".$opt2_952." Quantity: ".$qty952; }
if (!empty($qty953)) {$message .= "\n\nItem Name: ".$item953." Colour: ".$opt1_953." Size: ".$opt2_953." Quantity: ".$qty953; }
if (!empty($qty170)) {$message .= "\n\nItem Name: ".$item170." Size: ".$opt2_170." Quantity: ".$qty170; }
if (!empty($qty163)) {$message .= "\n\nItem Name: ".$item163." Colour: ".$opt1_163." Quantity: ".$qty163; }
if (!empty($qty177)) {$message .= "\n\nItem Name: ".$item177." Size: ".$opt2_177." Quantity: ".$qty177; }
if (!empty($qty173)) {$message .= "\n\nItem Name: ".$item173." Size: ".$opt2_173." Quantity: ".$qty173; }

if (!empty($qty198S)) {$message .= "\n\nItem Name: ".$item198S." Colour: ".$opt1_198S." Size: ".$opt2_198S." Quantity: ".$qty198S; }
if (!empty($qty198)) {$message .= "\n\nItem Name: ".$item198." Colour: ".$opt1_198." Size: ".$opt2_198." Quantity: ".$qty198; }
if (!empty($qty830)) {$message .= "\n\nItem Name: ".$item830." Colour: ".$opt1_830." Size: ".$opt2_830." Quantity: ".$qty830; }
if (!empty($qty1140)) {$message .= "\n\nItem Name: ".$item1140." Colour: ".$opt1_1140." Size: ".$opt2_1140." Quantity: ".$qty1140; }
if (!empty($qty226)) {$message .= "\n\nItem Name: ".$item226." Colour: ".$opt1_226." Size: ".$opt2_226." Quantity: ".$qty226; }
if (!empty($qty243)) {$message .= "\n\nItem Name: ".$item243." Colour: ".$opt1_243." Size: ".$opt2_243." Quantity: ".$qty243; }
if (!empty($qty2230)) {$message .= "\n\nItem Name: ".$item2230." Colour: ".$opt1_2230." Size: ".$opt2_2230." Quantity: ".$qty2230; }
if (!empty($qty258)) {$message .= "\n\nItem Name: ".$item258." Colour: ".$opt1_258." Size: ".$opt2_258." Quantity: ".$qty258; }

if (!empty($qty204)) {$message .= "\n\nItem Name: ".$item204." Colour: ".$opt1_204." Size: ".$opt2_204." Quantity: ".$qty204; }



  $message .= "\n\nThank you for your order. A SharifWear staff member will contact you shortly to provide you with a shipping cost and payment details.";

  mail($email, "Sharifwear Order Confirmation", $message, "From: ".$email);

  header( "Location: http://www.sharifwear-aus.com.au/orderthankyou.html" );




?>
