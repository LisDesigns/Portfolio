<?php
//  session_start();

include "webpage_files/includes/dbconn.php";
echo "";
$font ="";

$lessonId = $_GET["lessonId"];
//$lessonId=2;


$query = "SELECT * FROM sections WHERE lessonId=".$lessonId;
$sections = mysql_query($query);

if (!$sections) {
    echo "Error: ".mysql_error();
    exit;
}


while($section = mysql_fetch_assoc($sections)){

  $sectionId=$section['sectionId'];
  $section_heading=$section['section_heading'];
  $section_picture=$section['section_picture'];
  $section_text=$section['section_text'];
  $language=$section['language'];
  $english = "webpage_files/fonts/Arial.ttf";
  $thai = "webpage_files/fonts/Isaana.ttf";

  if ($language == "English") {
    //$font = $english;
    $font = '<div style="font-family:Arial;Isaana 2008-23;Arial;Times New Roman;font-size:16px!important;font-weight:300;width:400px;">';

  }
  if ($language == "Thai") {

    //$font = $thai;
    $font = '<div style="font-family:Isaana 2008-23!important;Times New Roman;font-size:22px!important;font-weight:300;width:400px;">';
    //$font = '<span style="font-family:Isaana 2008-23;font-size:24px;font-weight:300;">';
    
  }

  //echo "<br/>".$sectionId;

  echo "<h3>".$section_heading."</h3>";
  echo "<img src='webpage_files/images/lessons/".$sectionId.".jpg' border='1'/><br/>";
  //echo "<img src='webpage_files/images/lessons/".$section_picture."'.jpg' border='1'/><br/>";

  //$section_text = 'Testing.. ./nfgh fghf gh/ngjh gjjg h\n';
  $section_text = wordwrap($section_text,30,"[:]");
  $section_block = explode("[:]", $section_text);

  $i=0;

  while ($i < count($section_block)) {

  $_SESSION["pos"]=$i;
  $_SESSION["section_line"]=$section_block[$i];
  ?><img src='<?php echo "merge.php?pos=".$i; ?>'/><?php
  $_SESSION["section_line"]=$section_block;
  $i++;
  
  }

  //echo "<br/>".$font.$section_text."</font></div>";
  echo "<br/>";

}


?>