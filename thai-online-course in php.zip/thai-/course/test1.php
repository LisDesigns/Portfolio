<?php
  session_start();
//session_destroy();
//if (!isset($_SESSION["section_test"])) {
  //session_start();
//}

$section_cat[0]="cat 0<br/>";

$section_cat[1]="cat 1<br/>";

$section_cat[2]="cat 2<br/>";

$section_cat[3]="section 3<br/>";

$section_cat[4]="cat 4<br/>";

$_SESSION["section_cat"] = $section_cat;

$section_text = 'Testing.. ./nfgh fghf gh/ngjh gjjg h\n';
$section_text = wordwrap($section_text,10,"[:]");
$section_block = explode("[:]", $section_text);

  //echo count($section_block);
  $i=0;
  while ($i < count($section_block)) {

  $_SESSION["pos"]=$i;

  $_SESSION["section_line"]=$section_block[$i];

  //echo $_SESSION["section_line"]."<br/><br/>";

  ?><img src='<?php echo "merge.php?pos=".$i; ?>'/><?php

  $_SESSION["section_line"]=$section_block;

  $i++;
  
  }
 
 
?>

