


<div id="soundbox" style="margin-top:0px;width:1px;height:1px;overflow:hidden;">
</div>

<?php
  include "slideshow/slidescripts.php";
?>











