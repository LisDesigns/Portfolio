



<?php






<script language="JavaScript1.2" type="text/javascript">

function playSound(sound) {
  
}

</script>

<script language="JavaScript1.2" type="text/javascript">
// Preload all sounds and images

slideCount = "<?php echo $slideCount; ?>";


$slideCount = 0;
$query = "SELECT * FROM slides WHERE lessonId=".$lessonId;
$slides = mysql_query($query);
while($slide = mysql_fetch_assoc($slides)){




function displaySlide(slideNumber,idNumber) {

  if (document.getElementById) {
    hideAll();
    document.getElementById("slide"+slideNumber).style.visibility = "visible";
    sound = "sound"+idNumber+".mp3";
    document.getElementById("soundbox").innerHTML='<embed src="+sound+" id="" />';    

    }
  }

  $image_name = "picture.jpg";

  //output the number of slides based on the maximum amouont of slides there are for that lesson.
  for (i=0; slideCount <= i; i++) { 
    if(i == slideId){ 
      document.writeln('<img src="image4.jpg" alt="Slide 4" id="slide4" width="550" height="350" style="position:absolute; top:0px; left:0px; visibility:hidden" />';
    }
  }

  //output the number of slides based on the maximum amouont of slides there are for that lesson.
  for (i=0; slideCount <= i; i++) { 
    if(i == slideId){ 
      document.writeln('<a href="javascript:displaySlide(i,slideId)"><img src="thumb4.jpg" alt="Thumb 4" id="thumb4" width="100" height="65" border="1" /></a>');
    }
  }

</script>