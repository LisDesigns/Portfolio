<?php 

  $slideCount=9;
  $pathThumbs = "webpage_files/images/slideshow/";
  $pathImages = "webpage_files/images/slideshow/";
  $pathSounds = "webpage_files/sounds/slideshow/";
  
?>

<script language="JavaScript1.2" type="text/javascript">

slideCount = "<?php echo $slideCount; ?>";

function hideAll() {
  <?php
  for ($i=0; $i <= $slideCount; $i++) { 
    //if ($i == $slideId) { 
      echo "document.getElementById('slide".$i."').style.visibility = 'hidden';";
      echo "\n";
    //}
  }
  ?>
// Back to JavaScript
}

function displaySlide(slideNumber) {

  i = slideNumber;
  if (document.getElementById) {

    pathImages = "webpage_files/images/slideshow/";
    pathSounds = "webpage_files/sounds/slideshow/";
     
    slideImage = pathImages+"slide"+i+".jpg"; 
    //alert(slideImage);
    slidesound = pathSounds+"slide"+i+".mp3";
    document.getElementById("slide"+i).style.visibility = "visible";
    hideAll();
    document.getElementById("slide"+i).style.visibility = "visible";
    document.getElementById("soundbox").innerHTML='<embed src="'+slidesound+'" id="" />';    

  }
}

<?php

  for ($i=0; $i <= $slideCount; $i++) { 
    //if ($i == $slideId) { 
      //document.writeln('<img src="'+slideImage+'" alt="Slide $i" id="slide" width="550" height="350" />';
      //echo "\n\n";
    //}
  }

?>
</script>
<style type="text/css">
  .thumbs{position:absolute; top:281px; visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=100);-moz-opacity:100}
  .slides{position:absolute; top:0px; left:0px; visibility:;hidden;filter:alpha(opacity=0);-moz-opacity:0;width:400px;height:280px;filter:alpha(opacity=0);-moz-opacity:0}
</style>
</head>
<body>
<div id="slideshowContainer" style="position:absolute; top:35px; left:10px; height:250px; width:350px; border-width:0px; border-style:none; border-color:white;">

<?php
$leftmargin=0;
  for ($i=0; $i <= $slideCount; $i++) { 
    //if ($i == $slideId) { 
      $slideImage = $pathImages."slide".$i.".jpg";  
      echo '<img src="'.$slideImage.'" alt="Slide" id="slide'.$i.'"  class="slides"/>';
      echo "\n";
    //}
  }
      echo "\n";
  for ($i=0; $i <= $slideCount; $i++) { 
    //if ($i == $slideId) { 

      echo '<a href="javascript:displaySlide('.$i.')">';
      echo '<img src="'.$pathImages.'thumb'.$i.'.jpg" alt="Thumb '.$i.'" id="thumb'.$i.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/></a>';
      echo "\n";
      $leftmargin += 40;
      echo "";
    //}
  }

?>

  <div id="soundbox" style="margin-top:0px;width:1px;height:1px;overflow:hidden;">
  </div>

  <script language="JavaScript1.2" type="text/javascript">

<?php

  for ($i=0; $i <= $slideCount; $i++) { 

    //if ($i == $slideId) { 
      echo "secondsToCount".$i." = 2;";
      echo "\n";
    //}
  }
      echo "\n";

  for ($i=0; $i <= $slideCount; $i++) { 
    //if ($i == $slideId) { 

      echo "i".$i." = 0;\n";

     // echo "\n";
    //}
  }

  for ($i=0; $i <= $slideCount; $i++) { 
  //  if ($i == $slideId) { 

      echo "\n";
      echo "function increaseOpacity".$i."() {\n";    
      echo "  if (i".$i." <= 80) {\n";
      echo "  secondsToCount".$i." += 1;";
      echo "\n"."  i".$i."+=10;";


      //Slide opacity...
      echo "\n".'  document.getElementById("slide'.$i.'").filters.alpha.opacity=i'.$i.";";
      

      //echo "\n".'  document.getElementById("thumb'.$i.'").filters.alpha.opacity=i'.$i.";";
      echo "\n".'  t'.$i.' = setTimeout("increaseOpacity'.$i.'();", secondsToCount'.$i.');';
    
    echo "\n";
    echo "  }";
    echo "\n";
    echo "}";
 //   }
  }

  for ($i=0; $i <= $slideCount; $i++) { 
    echo "\n secondsToCount".$i."=2;";
    echo "\n i".$i."=0;";
  }
echo "\n";
?>

if ((navigator.appName == 'Microsoft Internet Explorer') && (document.getElementById)) {
    secondsToCount = 0;
<?php

    for ($i=0; $i <= $slideCount; $i++) { 

      echo "\n";
      $increaseOpacity = "increaseOpacity".$i."();";
      ?>
      t5 = <?php echo 'setTimeout("'.$increaseOpacity.'", secondsToCount);';
      echo "\n";
      echo "secondsToCount += 1300;";
      echo "\n";
    //t5 = setTimeout("increaseOpacity4();", secondsToCount);
  //}
    }
?>
}

<?php

  echo "\n\n";

  for ($i=0; $i <= $slideCount; $i++) { 

    echo "\n mozSeconds".$i."=2;";
    echo "\n m".$i."=0;";

  } 

  echo "\n\n";

  for ($i=0; $i <= $slideCount; $i++) { 
    echo "\n function mozOpacity".$i."() {"; 
    echo "\n if (m".$i." <= 0.8) {";
    echo "\n mozSeconds".$i." += 1;";
    echo "\n m".$i."+=0.03;";
    echo "\n document.getElementById(".'"slide'.$i.'").style.MozOpacity=m'.$i.';';
    echo "\n mt".$i.' = setTimeout("mozOpacity'.$i.'();", mozSeconds'.$i.');';
    echo "}}";
  }

  echo "\n\n";

  echo "if ((navigator.product == 'Gecko') && (document.getElementById)){";
  echo "mozSeconds = 0;\n\n";
  for ($i=0; $i <= $slideCount; $i++) { 
    echo "\n mt5 = setTimeout(".'"mozOpacity'.$i.'();", mozSeconds);';
    echo "\n mozSeconds += 1300;";
  }
  echo '}';

?>
</script>



</div> 

</body>
</html>