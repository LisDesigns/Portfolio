<?php 
include("../webpage_files/includes/header.php");
include("../webpage_files/includes/dbconn.php");

  $pathThumbs = "webpage_files/images/slideshow/";
  $pathImages = "webpage_files/images/slideshow/";
  $pathSounds = "webpage_files/sounds/slideshow/";
  $slideCount=9;
?>
 
<script language="JavaScript1.2" type="text/javascript">

slideCount = "<?php echo $slideCount; ?>";

function hideAll() {
  <?php
  for ($i=0; $i <= $slideCount; $i++) { 
    if ($i == $slideId) { 
      echo "document.getElementById('slide".$i."').style.visibility = 'hidden';";
      echo "\n";
    }
  }
  ?>
// Back to JavaScript
}

function displaySlide(slideNumber) {

  i = slideNumber;
  if (document.getElementById) {

    pathImages = "webpage_files/images/slideshow/";
    pathSounds = "webpage_files/sounds/slideshow/";
     
    slideImage = pathImages+"slide"+i+".jpg"; 
    //alert(slideImage);
    slidesound = pathSounds+"slide"+i+".mp3";
    document.getElementById("slide"+i).style.visibility = "visible";
    hideAll();
    document.getElementById("slide"+i).style.visibility = "visible";
    document.getElementById("soundbox").innerHTML='<embed src="'+slidesound+'" id="" />';    

  }

}

<?php
/*
  for ($i=0; $i <= $slideCount; $i++) { 
    if ($i == $slideId) { 
      document.writeln('<img src="'+slideImage+'" alt="Slide $i" id="slide" width="550" height="350" />';
      echo "\n\n";
    }
  }
*/
?>
</script>
<style type="text/css">
  .thumbs{position:absolute; top:281px; visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=100);-moz-opacity:100}
  .slides{position:absolute; top:0px; left:0px; visibility:;hidden;filter:alpha(opacity=0);-moz-opacity:0;width:400px;height:280px;filter:alpha(opacity=0);-moz-opacity:0}
</style>
</head>
<body>
<div id="slideshowContainer" style="position:absolute; top:35px; left:10px; height:250px; width:350px; border-width:0px; border-style:none; border-color:white;">

<?php
include("webpage_files/includes/dbconn.php");
$leftmargin=0;
$slidequery1 = "SELECT * FROM slides WHERE lessonId='0' ORDER BY slideId ASC";
$slides1 = mysql_query($slidequery1);
while($slide1 = mysql_fetch_assoc($slides1)){

  $slideId=$slide1['slideId'];
  $chapterId = $slide1['chapterId'];
  $lessonId = $slide1['lessonId'];
  $slide_image = $slide1['slide_image'];
  $slide_sound = $slide1['slide_sound'];
  $i++;
  $slideCount = $slideId;
  $i = $slideId;
     //echo "<br/>Slide image: webpage_files/images/slideshow/".$slideId.".jpg";
     //echo "<br/>Slide sound: webpage_files/sounds/slideshow/".$slideId.".jpg<br/>";
     echo $leftmargin."   <br/>";


     //<img src="'.$slideImage.'" alt="Slide" id="slide'.$i.'"  class="slides"/>
     echo "<img src='webpage_files/images/slideshow/slide".$slideId.".jpg' id='slide".$i."' border='1' class='display' />";
     //echo "<br/><br/>"; 
     //echo "<img src='webpage_files/images/slideshow/thumb".$slideId.".jpg' border='1' onclick='changeSlide(".'"'.$slide_image.'"'.")' class='thumbs' style='cursor:pointer;left:".$leftmargin."px!important' />"; 

     $leftmargin += 40;
     //echo '<a href="javascript:displaySlide('.$i.')">';
     echo '<img src="'.$pathImages.'thumb'.$slideId.'.jpg" alt="Thumb '.$i.'" id="thumb'.$i.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/>';//</a>';
     echo "\n";
  }



/*
$leftmargin=0;
  for ($i=0; $i <= $slideCount; $i++) { 
    if ($i == $slideId) { 
      $slideImage = $pathImages."slide".$i.".jpg";  
      echo '<img src="'.$slideImage.'" alt="Slide" id="slide'.$i.'"  class="slides"/>';
      echo "\n";
    }
  }
      echo "\n";
  for ($i=0; $i <= $slideCount; $i++) { 
    if ($i == $slideId) { 

      echo '<a href="javascript:displaySlide('.$i.')">';
      echo '<img src="'.$pathImages.'thumb'.$i.'.jpg" alt="Thumb '.$i.'" id="thumb'.$i.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/></a>';
      echo "\n";
      $leftmargin += 40;
      echo "";
    }
  }
*/
?>




</div> 

</body>
</html>