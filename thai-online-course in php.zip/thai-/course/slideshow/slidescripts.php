<?php 

  //$slideIdMax=9;
  $pathThumbs = "webpage_files/images/slideshow/";
  $pathImages = "webpage_files/images/slideshow/";
  $pathSounds = "webpage_files/sounds/slideshow/";
  
?>

<script language="JavaScript1.2" type="text/javascript">

i = "<?php echo $slideIdMax; ?>";

function hideAll() {

  <?php

  $i=0;
  $slides = mysql_query($slidequery);

  while($slide = mysql_fetch_assoc($slides)){
    $slideId=$slide['slideId'];
    echo "document.getElementById('slide".$slideId."').style.visibility = 'hidden';";
    echo "\n";
    $i++;
  }
  ?>

}

function displaySlide(slideNumber) {

  i = slideNumber;
  if (document.getElementById) {

    pathImages = "webpage_files/images/slideshow/";
    pathSounds = "webpage_files/sounds/slideshow/";
     
    //slideImage = pathImages+"slide"+i+".jpg"; 
    slideImage = pathImages+slideNumber+".jpg";
    //alert(slideImage);
    //slidesound = pathSounds+"slide"+i+".mp3";
    slidesound = pathSounds+slideNumber+".mp3";

    document.getElementById("slide"+i).style.visibility = "visible";
    hideAll();
    document.getElementById("slide"+i).style.visibility = "visible";
    
    document.getElementById("soundbox").innerHTML='<embed src="'+slidesound+'" id="" />';

  }

}

<?php
/* 
 $i=0;
  for ($slideId=0; $slideId <= $slideIdMax; $slideId++) { 
    if ($i == $slideId) { 
      ?>
      document.writeln('<img src="'+slideImage+'" alt="Slide $slideId" id="slide" width="550" height="350" />';
      <?php //echo "\n\n";
    }
  }
*/
?>
</script>
<style type="text/css">
  .thumbs{position:absolute; top:281px; visibility:visible; border-color:rgb(250,250,250);filter:alpha(opacity=100);-moz-opacity:100}
  .slides{position:absolute; top:0px; left:0px; visibility:;hidden;filter:alpha(opacity=0);-moz-opacity:0;width:400px;height:245px;filter:alpha(opacity=0);-moz-opacity:0}
</style>
</head>
<body>
<div id="slideshowContainer" style="position:absolute; top:35px; left:10px; height:200px; width:350px; border-width:0px; border-style:none; border-color:white;overflow:;hidden;">

<?php
$leftmargin=0;
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];
      //$slideImage = $pathImages."slide".$slideId.".jpg";  
      $slideImage = $pathImages.$slideId.".jpg";  

      echo '<img src="'.$slideImage.'" alt="" id="slide'.$slideId.'" class="slides"/>';
      echo "\n";
  }
      echo "\n";
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];
      echo '<a href="javascript:displaySlide('.$slideId.')">';
      //echo '<img src="'.$pathImages.'thumb'.$slideId.'.jpg" alt="" id="thumb'.$slideId.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/></a>';
      echo '<img src="'.$pathImages.$slideId.'.jpg" alt="" id="thumb'.$slideId.'" width="100" height="65" border="1" class="thumbs" style="cursor:pointer;left:'.$leftmargin.'px!important"/></a>';
      echo "\n";
      $leftmargin += 40;
      echo "";
  }

?>

  <div id="soundbox" style="margin-top:0px;width:1px;height:1px;overflow:hidden;">
  </div>

 <script language="JavaScript1.2" type="text/javascript">

<?php
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];
      echo "secondsToCount".$slideId." = 2;";
      echo "\n";
  }
      echo "\n";
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];

      echo "i".$slideId." = 0;\n";

     // echo "\n";
  }
   $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];

      echo "\n";
      echo "function increaseOpacity".$slideId."() {\n";    
      echo "  if (i".$slideId." <= 80) {\n";
      echo "  secondsToCount".$slideId." += 1;";
      echo "\n"."  i".$slideId."+=10;";


      //Slide opacity...
      echo "\n".'  document.getElementById("slide'.$slideId.'").filters.alpha.opacity=i'.$slideId.";";
      

      //echo "\n".'  document.getElementById("thumb'.$slideId.'").filters.alpha.opacity=i'.$slideId.";";
      echo "\n".'  t'.$slideId.' = setTimeout("increaseOpacity'.$slideId.'();", secondsToCount'.$slideId.');';
    
    echo "\n";
    echo "  }";
    echo "\n";
    echo "}";
  }
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
    $slideId=$slide['slideId'];
    echo "\n secondsToCount".$slideId."=2;";
    echo "\n i".$slideId."=0;";
  }
echo "\n";
?>
if ((navigator.appName == 'Microsoft Internet Explorer') && (document.getElementById)) {
    secondsToCount = 0;
<?php

  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
      $slideId=$slide['slideId'];
      echo "\n";
      $slideIdncreaseOpacity = "increaseOpacity".$slideId."();";
      ?>
      t5 = <?php echo 'setTimeout("'.$slideIdncreaseOpacity.'", secondsToCount);';
      echo "\n";
      echo "secondsToCount += 1300;";
      echo "\n";
    //t5 = setTimeout("increaseOpacity4();", secondsToCount);
  }
?>
}

<?php

  echo "\n\n";
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
    $slideId=$slide['slideId'];
    echo "\n mozSeconds".$slideId."=2;";
    echo "\n m".$slideId."=0;";
  } 

  echo "\n\n";
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
    $slideId=$slide['slideId']; 
    echo "\n function mozOpacity".$slideId."() {"; 
    echo "\n if (m".$slideId." <= 0.8) {";
    echo "\n mozSeconds".$slideId." += 1;";
    echo "\n m".$slideId."+=0.03;";
    echo "\n document.getElementById(".'"slide'.$slideId.'").style.MozOpacity=m'.$slideId.';';
    echo "\n mt".$slideId.' = setTimeout("mozOpacity'.$slideId.'();", mozSeconds'.$slideId.');';
    echo "}}";
  }

  echo "\n\n";

  echo "if ((navigator.product == 'Gecko') && (document.getElementById)){";
  echo "mozSeconds = 0;\n\n";
  $i=0;
  $slides = mysql_query($slidequery);
  while($slide = mysql_fetch_assoc($slides)){
    $slideId=$slide['slideId'];
    echo "\n mt5 = setTimeout(".'"mozOpacity'.$slideId.'();", mozSeconds);';
    echo "\n mozSeconds += 1300;";
  }
  echo '}';
?>
</script>



</div> 

</body>
</html>