<?php

if (!isset($_SESSION["section_tell"])) {
  session_start();
}

$section_tell[0]="tell 0<br/>";

$section_tell[1]="tell 1<br/>";

$section_tell[2]="mice 2<br/>";

$section_tell[3]="section 3<br/>";

$section_tell[4]="section 4<br/>";

$_SESSION["section_tell"] = $section_tell;

/*
$section_cat[0]="cat_*<br/>";

$section_cat[1]="cat 1<br/>";

$section_cat[2]="cat 2<br/>";

$section_cat[3]="section 3<br/>";

$section_cat[4]="cat 4<br/>";

$_SESSION["section_cat"] = $section_cat;
*/

?>



