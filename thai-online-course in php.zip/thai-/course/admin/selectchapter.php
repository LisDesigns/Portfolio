<b>Select Chapter</b>
<form action="selectlesson.php" method="post">

<?php
  include "addchapter.php";
?>

<br/> or add new <input type="text" value="" name="new_chapter_name"/>
<br/>
<br/>
<input type="submit" value="View lessons">
</form>
