<?php

include("../webpage_files/includes/dbconn.php");

$chapterId=$_POST["chapterId"];
if ($chapterId == -1) {
  header("Location:index.php");
}

include("../webpage_files/includes/admin_header.php");

$lessonId=$_POST[$chapterId];

if (empty($lessonId)) {
  header("Location:index.php");
}

$query = "SELECT * FROM `lessons` WHERE `lessonId`=".$lessonId;
$lessons = mysql_query($query);

if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
}

while($lesson = mysql_fetch_assoc($lessons)){
  $lesson_heading = $lesson['lesson_heading'];
}
echo "<h1>Edit Lesson: ".$lesson_heading."</h1>";

$chapterId = $_POST["chapterId"];

?>

<form action="editslideshow.php" method="post">

<input type="hidden" value="<?php echo $lessonId; ?>" name="lessonId"/>
<input type="submit" value="Edit Slideshow"/>
</form>
<?php


$query = "SELECT * FROM sections WHERE lessonId=".$lessonId." ORDER BY sectionId ASC";
$sections = mysql_query($query);

if (!$sections) {
    echo "Error: ".mysql_error();
    exit;
}

$i = 0;

while($section = mysql_fetch_assoc($sections)){
  $sectionId=$section['sectionId'];
  $chapterId = $section['chapterId'];
  //$lessonId = $section['lessonId'];
  $section_heading = $section['section_heading'];
  $language = $section['language'];
  $i++;

?>
<form action="editsection.php" method="post" enctype="multipart/form-data" style="display:inline;">
<?php
  echo '<div class="editlist"><i>'.$language.' Section '.$i.'. </i>'.$section_heading.'</div><input type="hidden" name="sectionId" value="'.$sectionId.'"><input type="submit" value="Edit" class="editbuttons" style="width:60px"/>';
?>
</form>
<form action="deletesection.php" method="post"  enctype="multipart/form-data" style="display:inline">
<?php
  echo ' &nbsp; <input type="submit" value="Delete" class="editbuttons" style="width:60px"/><input type="hidden" name="sectionId" value="'.$sectionId.'"></div><br/>';
?>
</form>
<?php
}
?>
</table>
</form>

Click below to add text, sound or images.
<br/>
<form action="newsection.php" method="post" style="display:inline">
<input type="hidden" value="English" name="language"/>
<input type="hidden" value="<?php echo $chapterId; ?>" name="chapterId"/>
<input type="hidden" value="<?php echo $lessonId; ?>" name="lessonId"/>
<input type="submit" value="Add English Section" style="width:126px;"/>
</form>
<br/><br/>
<form action="newsection.php" method="post" style="display:inline">
<input type="hidden" value="Thai" name="language"/>
<input type="hidden" value="<?php echo $chapterId; ?>" name="chapterId"/>
<input type="hidden" value="<?php echo $lessonId; ?>" name="lessonId"/>
<input type="submit" value="Add Thai Section" style="width:126px;"/>
</form>
<!--
<input type="submit" value="Delete All Sections" class="editbuttons"/>
-->
<br/><br/>
<h1>Change Lesson Name</h1>
<form action="submitlesson.php" method="post" enctype="multipart/form-data">

<input type="hidden" value="<?php echo $chapterId; ?>" name="chapterId"/>
<input type="hidden" value="<?php echo $lessonId; ?>" name="lessonId"/>

<?php

  echo "<table id='editlesson' align='top'>";
  echo "<tr><td width='240'>Chapter:  </td><td>";
  include "listchapters.php";

  echo "</td></tr><tr><td width='240'>Lesson Heading:  </td><td><input type='text' name='lesson_heading' value='".$lesson_heading."'/></td></tr>";
/*
  echo "<tr><td width='240'>Lesson Name (for link):  </td><td><input type='text' name='lesson_name'/></td></tr>";
*/
  echo '<tr><td><br/></td><td align="right">';
  echo '<input type="submit" value="Submit" class="buttons" style="width:60px"/></td></tr>';
  echo "</table><br/><br/>";

?>

</form>
<?php
//include("../webpage_files/includes/output_footer.php");
include("../webpage_files/includes/footer.php");

?>