<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");

$chapterId = $_POST["chapterId"];

?>

<h1>Add New Lesson</h1>
<form action="addlesson.php" method="post" enctype="multipart/form-data">
<input type="hidden"  name='lesson_name' value="">
<?php

  echo "<table id='editlesson' align='top'>";
  echo "<tr><td width='240'>Chapter:  </td><td>";
  include "listchapters.php";

  echo "</td></tr><tr><td width='240'>Lesson Heading:  </td><td><input type='text' name='lesson_heading'/></td></tr>";
/* 
 echo "<tr><td width='240'>Lesson Name (for link):  </td><td><input type='text' name='lesson_name'/></td></tr>";
*/  
echo '<tr><td><br/></td><td align="right">';
  echo '<input type="submit" value="Submit" class="buttons" style="width:60px"/></td></tr>';
  echo "</table><br/><br/>";
?>

</form>


<?php

  include("../webpage_files/includes/footer.php");
?>