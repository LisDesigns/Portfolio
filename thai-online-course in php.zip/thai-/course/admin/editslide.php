<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");



//$chapterId = $_POST["chapterId"];
//$lessonId = $_POST["lessonId"];
$slideId = $_POST["slideId"];


?>

<h1>Edit Slide</h1>
<form action="submitslide.php" method="post" enctype="multipart/form-data">
<?php

$query = "SELECT * FROM slides WHERE slideId=".$slideId;
$slides = mysql_query($query);

//$listoflessons = "<select>";

if (!$slides) {
    echo "Error: ".mysql_error();
    exit;
}

while($slide = mysql_fetch_assoc($slides)){

  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  $slide_picture = $slide['slide_image'];
  $slide_sound = $slide['slide_sound'];

  echo "<table id='editlesson'  valign='top'>";

  echo "<input type='hidden' name='lessonId' value='".$lessonId."'/>";
  echo "<input type='hidden' name='slideId' value='".$slideId."'/>";
  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";
/*
  echo "<tr><td width='240'>Slide Heading:  </td><td><input type='text' name='slide_heading' value='".$slide_heading."'/></td></tr>";
*/
  echo "<tr><td>Slide Picture:  </td><td><input type='file' name='slide_i' value='".$slide_picture."'/></td></tr>";
  echo "<tr><td>Slide Sound:  </td><td><input type='file' name='slide_s' value='".$slide_sound."'/></td></tr>";
  echo '<tr><td><br/><input type="reset" value="Clear" class="buttons" style="width:60px"/></td><td align="left">';
  echo '<br/><div id="submitDiv" style="text-align:right;">';
  echo '<input type="submit" value="Update" class="buttons" style="width:60px"/></div></td></tr>';

  echo "</table><br/><br/>";
}
?>


</form>


<?php
//include("../webpage_files/includes/output_footer.php");
include("../webpage_files/includes/footer.php");

?>