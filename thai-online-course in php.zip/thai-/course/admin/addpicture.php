<form action="addlesson.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="lessonId" id="lessonId" value="8">
<input type="file" name="lesson_picture" id="lesson_picture">
<input type="submit" value="Upload"/>
</form>