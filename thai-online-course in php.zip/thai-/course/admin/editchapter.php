<?php

include("../webpage_files/includes/dbconn.php");
if ($_POST["chapterId"] == -1) {
  header("Location:index.php");
}
include("../webpage_files/includes/admin_header.php");
$chapterId = $_POST["chapterId"];
$query = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
$chapters = mysql_query($query);

//$listoflessons = "<select>";

if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}

while($chapter = mysql_fetch_assoc($chapters)){

  //$slideId=$section['slideId'];

  //$chapterId = $section['chapterId'];
  //$lessonId = $section['lessonId'];
  //$sectionId = $section['sectionId'];
  $chapter_heading = $chapter['chapter_heading'];
  //$section_picture = $section['section_picture'];
  //$section_text = $section['section_text'];
  //$language = $section['language'];
}
?>

<h1>Edit Chapter</h1>
<form action="submitchapter.php" method="post" enctype="multipart/form-data">
<input type="hidden" value="
<?php

echo $chapterId;

?>" name="chapterId"/>
<?php

  echo "<table id='editlesson' align='top'>";
  echo "<tr><td width='240'>Chapter Heading:  </td><td><input type='text' name='chapter_heading' value='".$chapter_heading."'/></td></tr>";
  echo '<tr><td><br/></td><td align="right">';
  echo '<input type="submit" value="Submit" class="buttons" style="width:60px"/></td></tr>';
  echo "</table><br/><br/>";
?>

</form>


<?php
  include("../webpage_files/includes/footer.php");
?>