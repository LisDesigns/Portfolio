<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");

?>

<h1>Add New Chapter</h1>
<form action="addchapter.php" method="post" enctype="multipart/form-data">
<?php

  echo "<table id='editlesson' align='top'>";
  echo "<tr><td width='240'>Chapter Heading:  </td><td><input type='text' name='chapter_heading'/></td></tr>";
  echo '<tr><td><br/></td><td align="right">';
  echo '<input type="submit" value="Submit" class="buttons" style="width:60px"/></td></tr>';
  echo "</table><br/><br/>";
?>

</form>


<?php
  include("../webpage_files/includes/footer.php");
?>