<?php

include("../webpage_files/includes/dbconn.php");
//include("../webpage_files/includes/header.php");

$chapterId = $_POST["chapterId"];

$query1 = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
$chapters1 = mysql_query($query1);
if (!$chapters1) {
    echo "Error: ".mysql_error();
    exit;
}
$i = 1;
while($chapter1 = mysql_fetch_assoc($chapters1)){
  $chapter_heading  = $chapter1['chapter_heading'];
  $i++;
}


if ($i >= 2) {
  $listofchapters = "<select name='chapterId'><option value='".$chapterId."'>".$chapter_heading."</option>";
} else {
  $listofchapters = "<select name='chapterId'><option value='-1'>Please select</option>";
}

$selected = $chapterId;
//mysql_close($connection);
//include("../webpage_files/includes/dbconn.php");

//} else {
//$selected = "test";

$query = "SELECT * FROM chapters";
$chapters = mysql_query($query);
if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}
$i = 1;
while($chapter = mysql_fetch_assoc($chapters)){

  $orderId=$chapter['orderId'];
  $chapterId = $chapter['chapterId'];
  $lessonId = $chapter['lessonId'];
  $chapter_name = $chapter['chapter_name'];
  $chapter_heading = $chapter['chapter_heading'];

  //echo "Slide Id:".$slideId."<br/>";
  //echo "Lesson Id:".$lessonId."<br/>";
  //echo "Chapter Id:".$chapterId."<br/>";
  //echo "Chapter Name:".$chapter_name."<br/>";
  //echo "Chapter Heading:".$chapter_heading."<br/>";

  // echo "<br/><br/><a href='viewlessons.php?chapterId=$chapterId' class='numbers'>".$i++.".</a> <a href='viewlessons.php?chapterId=$chapterId'>".$chapter_name."</a>";

  if($chapterId != $selected) {
  $listofchapters .= "<option value='".$chapterId."'>".$chapter_name."</option>";
  }
}

  $listofchapters .= "</select>";

?>


<?php

  echo $listofchapters;

?>