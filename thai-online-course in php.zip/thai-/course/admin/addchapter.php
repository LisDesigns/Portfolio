<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/header.php");

  //$chapterId = $_POST['chapterId'];
  //$lessonId = $_POST['lessonId'];
  $chapter_name = "";//$_POST['chapter_name'];
  $chapter_heading = $_POST['chapter_heading'];
  $orderId=0;
  mysql_query("INSERT INTO `chapters` (`orderId`,`chapter_name`,`chapter_heading`) VALUES ('$orderId','$chapter_name','$chapter_heading')");
  ?>
  <script>
    document.location.href="index.php";
  </script>
  <?php

include("../webpage_files/includes/footer.php");

?>