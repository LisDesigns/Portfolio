<?php

include("../webpage_files/includes/dbconn.php");
//include("../webpage_files/includes/header.php");


$slideId = $_POST["slideId"];
$query = "DELETE FROM slides WHERE slideId=".$slideId;
mysql_query($query);

$path="webpage_files/images/slideshow/";
$filename=$slideId.".jpg";

  if (file_exists($slideId)) {
    unlink($path.$slideId.".jpg");
  }

$path="webpage_files/sounds/slideshow/";
$filename=$slideId.".jpg";

  if (file_exists($slideId)) {
    unlink($path.$slideId.".mp3");
  }

header("Location:index.php");
include("../webpage_files/includes/footer.php");

?>

