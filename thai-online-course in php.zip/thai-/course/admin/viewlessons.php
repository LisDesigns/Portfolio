<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");
?>

<h1>Delete Lessons</h1> 
<br/>
Select a lesson below to delete.
<br/>
<?php
//$query = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
$query = "SELECT * FROM chapters";
$chapters = mysql_query($query);

if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}

while($chapter = mysql_fetch_assoc($chapters)){

  $i = 1;
  $chapter_heading = $chapter['chapter_heading'];
  $chapter_name = $chapter['chapter_name'];
  $chapterId = $chapter['chapterId'];

  $query = "SELECT * FROM lessons WHERE chapterId=".$chapterId;
  $lessons = mysql_query($query);

  ?>

  <form action="../deletelesson.php" method="post" class="selectlesson">
  <script>
  function submitChoice(i) {
    document.forms[i].submit();
  }
  </script>
  <?php

  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";

  $listoflessons = "<br/><select name='lesson' onchange='submitChoice(".$i.")'/>";//alert(".'"'."test".'"'.")'>";

  if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
  }

  echo "<br/><i>".$chapter_heading."</i>";
  $i=0;

  while($lesson = mysql_fetch_assoc($lessons)){
   
    $slideId=$lesson['slideId'];
    $chapterId = $lesson['chapterId'];
    $lessonId = $lesson['lessonId'];
    $lesson_heading = $lesson['lesson_heading'];
    $lesson_name = $lesson['lesson_name'];
    $i++;

    // echo "<br/><br/><a href='viewlesson.php?lessonId=$lessonId' class='numbers'>".$i++.".</a> <a href='viewlesson.php?lessonId=$lessonId'>".$lesson_heading."</a>";

    $listoflessons .= "<option value='".$lessonId."' >".$lesson_name."</option>";
  }
  $listoflessons .= "</select></form>";
  echo $listoflessons;
  }



include("../webpage_files/includes/footer.php");
?>