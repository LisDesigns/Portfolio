<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");
?>

<?php
//$chapterId = $_GET["chapterId"];
$chapter_name="";

include "editlessons.php";

?>

<?php

/*
$chapterId = 1;

$chapterId = 2;
include "editlessons.php";

echo "<h1>Lessons for ".$chapter_name."</h1>";

while($chapter = mysql_fetch_assoc($chapters)){

  $slideId=$chapter['slideId'];
  $chapterId = $chapter['chapterId'];
  $lessonId = $chapter['lessonId'];
  $chapter_heading = $chapter['chapter_heading'];
  $chapter_name = $chapter['chapter_name'];

}
  $listoflessons .= "</select>";
  echo $listoflessons;

*/

include("../webpage_files/includes/footer.php");
?>