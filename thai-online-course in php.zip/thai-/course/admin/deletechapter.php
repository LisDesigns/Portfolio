<?php

include("../webpage_files/includes/dbconn.php");

$chapterId = $_POST["chapterId"];

//echo $chapterId;

$query = "DELETE FROM chapters WHERE chapterId=".$chapterId;
mysql_query($query);

header("Location:index.php");

include("../webpage_files/includes/footer.php");

?>