<h1>Edit Lessons</h1> 
<br/>
  <script>
  function submitChoice(i) {
    document.forms[i].submit();
  }
  </script>
<div style="float:left;width:200px;">
<form action="editlesson.php" method="post" class="selectlesson" id="editcourse">
<input type="hidden" name="chapterId" value="-1"/>
<?php

//$query = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
$query = "SELECT * FROM chapters";
$chapters = mysql_query($query);

if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}

while($chapter = mysql_fetch_assoc($chapters)){

  $i = 1;
  $chapter_heading = $chapter['chapter_heading'];
  $chapter_name = $chapter['chapter_name'];
  $chapterId = $chapter['chapterId'];

  $query = "SELECT * FROM lessons WHERE chapterId=".$chapterId;
  $lessons = mysql_query($query);

  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";

  $listoflessons = " &nbsp;<select name='".$chapterId."' class='lesson' />";

  if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
  }

  echo '<br/><input type="radio" id="chapterId" name="chapterId" value="'.$chapterId.'"/><i>'.$chapter_heading."</i>";
  $i=0;

  while($lesson = mysql_fetch_assoc($lessons)){
   
    $slideId=$lesson['slideId'];
    $chapterId = $lesson['chapterId'];
    $lessonId = $lesson['lessonId'];
    $lesson_heading = $lesson['lesson_heading'];
    $lesson_name = $lesson['lesson_name'];
    $i++;

    // echo "<br/><br/><a href='viewlesson.php?lessonId=$lessonId' class='numbers'>".$i++.".</a> <a href='viewlesson.php?lessonId=$lessonId'>".$lesson_heading."</a>";

    $listoflessons .= "<option value='".$lessonId."' name='lessonId'>".$lesson_heading."</option>";
  }
  $listoflessons .= "</select>";

  echo '<br/>';
  //echo '<input type="radio" name="chapter" value="'.$chapterId.'"/>';
  echo $listoflessons;
  }

?>
</div>
<script language="JavaScript1.2" type="text/javascript">
function checkthis() {
  alert('test');
  alert(document.forms[0].chapterId.checked);
}
</script>
<div style="float:left;width:300px;">
<br/><br/>
<input type="button" value="Edit Lesson" onclick="editLesson()" style="width:140px;margin-bottom:7px;margin-top:7px;">
<input type="button" value="Delete Lesson" onclick="deleteLesson()" style="width:140px;margin-bottom:7px;margin-top:7px;">
<br/><input type="button" value="Edit Chapter" onclick="editChapter()" style="width:140px;margin-bottom:7px;">
<input type="button" value="Delete Chapter" onclick="deleteChapter()" style="width:140px;margin-bottom:7px;">
<br/><input type="button" value="Add New Lesson" onclick="addNewLesson()" style="width:140px;margin-bottom:7px;">
<input type="button" value="Add New Chapter" onclick="addNewChapter()" style="width:140px;margin-bottom:7px;"> 
</div>


<script language="JavaScript1.2" type="text/javascript">

function addNewChapter() {
  document.getElementById("editcourse").action="newchapter.php";
  submitChoice(0);
}

function addNewLesson() {
  document.getElementById("editcourse").action="newlesson.php";
  submitChoice(0);
}

function editChapter() {
  document.getElementById("editcourse").action="editchapter.php";
  submitChoice(0);
}

function deleteChapter() {
  document.getElementById("editcourse").action="deletechapter.php";
  submitChoice(0);
}

function editLesson() {
  document.getElementById("editcourse").action="editlesson.php";
  submitChoice(0);
}

function deleteLesson() {
  document.getElementById("editcourse").action="deletelesson.php";
  submitChoice(0);
}
 
</script>
</form>