<?php

include("../webpage_files/includes/dbconn.php");

  $slideId=$_POST['slideId'];
  $chapterId = $_POST['chapterId'];
  $lessonId = $_POST['lessonId'];
  $slide_s = $_FILES['slide_s'];
  $slide_i = $_FILES['slide_i'];

  //$uploads="images/";
  $uploads = "../webpage_files/images/slideshow/";
  $filename = $slideId.".jpg";
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }
  if ($_FILES['slide_i']["type"] == "image/pjpeg") {
      $_FILES['slide_i']["name"]=$filename;
      move_uploaded_file($_FILES['slide_i']["tmp_name"],$uploads.$filename);
      //echo "Image Uploaded.";
  }

  $uploads = "../webpage_files/sounds/slideshow/";
  $filename = $slideId.".mp3";
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }

  if ($_FILES['slide_s']["type"] == "audio/mpeg") {
      $_FILES['slide_s']["name"]=$filename;
      move_uploaded_file($_FILES['slide_s']["tmp_name"],$uploads.$filename);
      //echo "<br/>Sound Uploaded.";
  }

  $query = "UPDATE `slides` SET `slideId` = '".$slideId."', `chapterId` = '".$chapterId."', `lessonId` = '".$lessonId."',`slide_image` = '".$slide_picture."',  `slide_sound` = '".$slide_sound."' WHERE slideId=".$slideId;
  mysql_query($query);

  header("Location:index.php");
//include("../webpage_files/includes/admin_header.php");
  include("../webpage_files/includes/footer.php");


?>