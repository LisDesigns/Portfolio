<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");

$lessonId=$_POST["lessonId"];
//$lessonId=1;
$query = "SELECT * FROM `lessons` WHERE `lessonId`=".$lessonId;
$lessons = mysql_query($query);

if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
}

while($lesson = mysql_fetch_assoc($lessons)){
  $lesson_heading = $lesson['lesson_heading'];
}

echo "<br/><h1>Edit SlideShow: ".$lesson_heading."</h1>";


$query = "SELECT * FROM slides WHERE lessonId=".$lessonId;
$slides = mysql_query($query);

if (!$slides) {
    echo "Error: ".mysql_error();
    exit;
}

$i = 0;

while($slide = mysql_fetch_assoc($slides)){
  $slideId=$slide['slideId'];
  $chapterId = $slide['chapterId'];
  $lessonId = $slide['lessonId'];
  //$slide_heading = $slide['slide_heading'];
  $i++;
?>
<form action="editslide.php" method="post" enctype="multipart/form-data" style="display:inline;">
<?php
  echo '<div class="editlist"><i>Slide '.$i.'. </i></div><img src="webpage_files/images/slideshow/thumbs/'.$slideId.'.jpg" width="20" height="20"/><input type="hidden" name="slideId" value="'.$slideId.'"><input type="submit" value="Edit" class="editbuttons" style="width:60px"/>';
?>
</form>
<form action="deleteslide.php" method="post"  enctype="multipart/form-data" style="display:inline">
<?php
  echo ' <input type="hidden" name="slideId" value="'.$slideId.'">&nbsp; <input type="submit" value="Delete" class="editbuttons" style="width:60px"/><br/>';
?>
</form>
<?php
}
?>
</table>
</form>

<br/><br/>
<form action="newslide.php" method="post" style="display:inline">
<input type="hidden" value="<?php echo $chapterId; ?>" name="chapterId"/>
<input type="hidden" value="<?php echo $lessonId; ?>" name="lessonId"/>
<input type="submit" value="Add New Slide" style="width:126px;"/>
</form>


<?php

include("../webpage_files/includes/footer.php");

?>