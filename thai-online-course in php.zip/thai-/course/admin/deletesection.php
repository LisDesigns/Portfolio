<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/header.php");

$sectionId = $_POST["sectionId"];

$query = "DELETE FROM sections WHERE sectionId=".$sectionId;
mysql_query($query);

//$subtitle ="Section Deleted";
//$message ="Please click below.";

//include("confirm.php");
header("Location:index.php");

include("../webpage_files/includes/footer.php");

?>

