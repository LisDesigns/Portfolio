<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/header.php");

  $chapterId = $_POST['chapterId'];
//  $lessonId = $_POST['lessonId'];
  $lesson_heading = $_POST['lesson_heading'];
  $lesson_name = $_POST['lesson_name'];

  mysql_query("INSERT INTO `lessons`(`chapterId`,`lesson_heading`,`lesson_name`) VALUES ('$chapterId','$lesson_heading','$lesson_name')");

  ?>

  <script>
    document.location.href="index.php";
  </script>
  
  <?php



include("../webpage_files/includes/footer.php");

?>