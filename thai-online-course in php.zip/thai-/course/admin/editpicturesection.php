


<script language="JavaScript1.2" type="text/javascript">
  textsectioncode = <?php include "../webpage_files/includes/addtextsection.php"; ?>
  function appendNewTextSection(){
    // divid section will equal div with the id of the highest     //id of the textsections in that lesson, plus one.
    document.getElementById("divid");
    
  }

</script>

