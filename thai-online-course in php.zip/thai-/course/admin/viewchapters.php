<?php

include("../webpage_files/includes/dbconn.php");
//include("../webpage_files/includes/header.php");

$listofchapters = "<select name='chapterId'><option>Please select</option>";

$query = "SELECT * FROM chapters";
$chapters = mysql_query($query);
if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
}
$i = 1;
while($chapter = mysql_fetch_assoc($chapters)){

  $slideId=$chapter['slideId'];
  $chapterId = $chapter['chapterId'];
  $lessonId = $chapter['lessonId'];
  $chapter_name = $chapter['chapter_name'];
  $chapter_heading = $chapter['chapter_heading'];

  //echo "Slide Id:".$slideId."<br/>";
  //echo "Lesson Id:".$lessonId."<br/>";
  //echo "Chapter Id:".$chapterId."<br/>";
  //echo "Chapter Name:".$chapter_name."<br/>";
  //echo "Chapter Heading:".$chapter_heading."<br/>";

 // echo "<br/><br/><a href='viewlessons.php?chapterId=$chapterId' class='numbers'>".$i++.".</a> <a href='viewlessons.php?chapterId=$chapterId'>".$chapter_name."</a>";

  $listofchapters .= "<option value='".$chapterId."'>".$chapter_name."</option>";

}

  $listofchapters .= "</select>";

?>


<?php


  echo $listofchapters;

?>