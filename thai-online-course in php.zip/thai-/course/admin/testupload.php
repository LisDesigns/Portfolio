<?php
//include("../webpage_files/includes/admin_header.php");
include("../webpage_files/includes/dbconn.php");

  $sectionId=$_POST['sectionId'];
  $chapterId = $_POST['chapterId'];
  $lessonId = $_POST['lessonId'];
  $section_heading = $_POST['section_heading'];
  $section_picture = $_FILES['section_picture'];
  $section_sound = $_FILES['section_sound'];
  $section_text = $_POST['section_text'];

  $uploads = "../webpage_files/images/lessons/";
  $filename = "image".$chapterId.".jpg";
  $uploads.$filename;
  if ($_FILES['section_picture']["type"] == "image/jpg") {
      $_FILES['section_picture']["name"]=$filename;
      move_uploaded_file($_FILES['section_picture']["tmp_name"],$uploads.$filename);
      echo "done";
  }

  $query = "UPDATE `sections` SET `chapterId` = '".$chapterId."',`section_heading` = '".$section_heading."', `section_picture` = '".$section_picture."',`section_sound` = '".$section_sound."',`section_text` = '".$section_text."' WHERE sectionId=".$sectionId;
  mysql_query($query);
  //include "editlesson.php";

  header("Location:index.php");

  include("../webpage_files/includes/footer.php");



?>