<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");

$sectionId = $_POST["sectionId"];
?>
<?php

/*
  if ($_POST["new_lesson_name"]) {
    $section_name = $_POST["new_lesson_name"];
    include "addlesson.php";
  } else {
    //$section_name = $_POST["lesson_name"];
    $section_name = "test lesson name";
  }
*/

$query = "SELECT * FROM sections WHERE sectionId=".$sectionId;
$sections = mysql_query($query);

//$listoflessons = "<select>";

if (!$sections) {
    echo "Error: ".mysql_error();
    exit;
}

while($section = mysql_fetch_assoc($sections)){

  $sectionId=$section['sectionId'];
  $chapterId = $section['chapterId'];
  $lessonId = $section['lessonId'];
  $section_heading = $section['section_heading'];
  $section_picture = $section['section_picture'];
  $section_sound = $section['section_sound'];
  $textarea3 = $section['section_text'];
  $language = $section['language'];
//$language="Thai";
//$language="English";
?>
<h1>Edit <?php echo $language." "; ?>Section</h1>

<script type="text/javascript">
//WYSIWYG.attach('englishtextarea', english); 
//WYSIWYG.attach('thaitextarea', thai); 
</script>
<form action="submitsection.php" method="post" name="editsection" enctype="multipart/form-data">
<?php
  echo "<table id='editlesson' valign='top'>";
  echo "<input type='hidden' name='language' value='".$language."'/>";
  echo "<input type='hidden' name='lessonId' value='".$lessonId."'/>";
  echo "<input type='hidden' name='sectionId' value='".$sectionId."'/>";
  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";
  echo "<tr><td width='240'>Section Heading:  </td><td><input type='text' name='section_heading' value='".$section_heading."'/></td></tr>";
  echo "<tr><td>Section Picture:  </td><td><input type='file' name='section_i' value='".$section_picture."'/></td></tr>";
  echo "<tr><td>Section Sound:  </td><td><input type='file' name='section_s' value='".$section_sound."'/></td></tr>";

  echo "<tr><td valign='top' colspan='2' >Section Text:  ";
  /*
  echo "<select id='language' name='language' align='left' onchange='setFont()'><option>Select Language</option><option value='English'>English</option><option value='Thai'>Thai</option></select>";
  */
  //echo "<select id='language' name='language' align='right'><option>Insert Symbol</option><option>Thai - Phonic</option><option>Thai - Symbol</option></select><br/><br/>
  echo "<div id='textsection'>";
  
  //include "../webpage_files/includes/phonic.php";
  echo "";

  if ($language=="English") {
?>

<script type="text/javascript">
WYSIWYG.attach('englishtextarea', english); 
//WYSIWYG.attach('thaitextarea', thai); 
</script>

<?php

    echo "<textarea name='englishtextarea' id='englishtextarea'>".$textarea3."</textarea></div>";
  }
  if ($language=="Thai") {
?>

<script type="text/javascript">
//WYSIWYG.attach('englishtextarea', english); 
WYSIWYG.attach('thaitextarea', thai); 
</script>

<?php
    //echo "style='font-family:Isaana 2008-23' ";
    echo "<textarea name='thaitextarea' id='thaitextarea'>".$textarea3."</textarea></div>";
  }

  echo "</td></tr>";
  echo '<tr><td><br/></td><td align="left">';
  echo '<br/><div id="submitDiv" style="text-align:right;">';
  echo '<input type="submit" value="Update" class="buttons" style="width:60px" /></div></td></tr>';

  echo "</table><br/><br/>";
}

?>

</form>
<script language="JavaScript1.2" type="text/javascript">
   function clearForm() {
     if (document.getElementById("englishtextarea")) {
       document.getElementById("englishtextarea").innerHTML ="";
     }
     if (document.getElementById("thaitextarea")) {
       document.getElementById("thaitextarea").innerHTML ="";
     }
   }
</script>
<?php
//include("../webpage_files/includes/output_footer.php");
include("../webpage_files/includes/footer.php");

?>