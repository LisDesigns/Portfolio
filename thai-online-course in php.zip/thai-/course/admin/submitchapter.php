<?php

include("../webpage_files/includes/dbconn.php");
//include("../webpage_files/includes/header.php");


  $chapterId = $_POST['chapterId'];
  //echo $chapterId;
  //$chapterId = 2;
  //$chapter_name = $_POST['chapter_name'];
  $chapter_heading = $_POST['chapter_heading'];

  $query = "UPDATE `chapters` SET `chapter_heading` = '".$chapter_heading."' WHERE chapterId=".$chapterId;
  mysql_query($query);

  //$subtitle = "Done!";
  //$message = "Chapter heading has been updated.";
  //include("confirm.php");
  header("Location:index.php");

include("../webpage_files/includes/footer.php");

?>