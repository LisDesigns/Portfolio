<?php

  if (exists($_POST["new_chapter_name"])) {
    $chapter_name = $_POST["new_chapter_name"];
    include "addchapter.php";
  } else {
    $chapter_name = $_POST["chapter_name"];
  }

?>
<b>Select Lesson to Edit</b>
<form action="editlesson.php" method="post">

 <br/>lessons in  
<?php
  echo $chapter_name."<br/>";
  include "addlesson.php";
?>

<br/> or add new <input type="text" value="" name="new_lesson_name"/>
<br/>
<br/>
<input type="submit" value="Edit Lesson">
</form>