<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");
$lessonId=$_POST["lessonId"];
$chapterId=$_POST["chapterId"];
$language=$_POST["language"];
?>


<h1>Add New <?php echo $language." "; ?>Section</h1>

<script type="text/javascript">
//WYSIWYG.attach('englishtextarea', english); 
//WYSIWYG.attach('thaitextarea', thai); 
</script>

<form action="addsection.php" name="editsection" method="post" enctype="multipart/form-data">
<?php

  echo "<table id='editlesson'  valign='top'>";

  //echo "<input type='hidden' name='sectionId' value='".$sectionId."'/>"; 
  echo "<input type='hidden' name='lessonId' value='".$lessonId."'/>";
  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";

  echo "<input type='hidden' name='language' value='".$language."'/>";
  echo "<tr><td width='240'>Section Heading:  </td><td><input type='text' name='section_heading'/></td></tr>";
  echo "<tr><td>Section Picture:  </td><td><input type='file' name='section_i'/></td></tr>";
  echo "<tr><td>Section Sound:  </td><td><input type='file' name='section_s'/></td></tr>";

  echo "<tr><td valign='top' colspan='2' >Section Text:  <br/><br/>";
/*
  echo "<select id='language' name='language' align='left' onchange='setFont()'><option>Select Language</option><option value='English'>English</option><option value='Thai'>Thai</option></select><br/><br/>";
<select id='language' name='language' align='left'><option>Select Language</option><option>English</option><option>Thai - Phonic</option><option>Thai - Symbol</option></select>
  echo "<select id='language' name='language' align='right'><option>Insert Symbol</option><option>Thai - Phonic</option><option>Thai - Symbol</option></select><br/><br/><textarea name='section_text' id='section_text'></textarea></td></tr>";
*/

  //include "../webpage_files/includes/phonic.php";
  //echo "<textarea name='section_text' id='section_text'></textarea>";

  echo "<div id='textsection'>";
  
  //include "../webpage_files/includes/phonic.php";
  echo "";

  if ($language=="English") {
?>

<script type="text/javascript">
WYSIWYG.attach('englishtextarea', english); 
//WYSIWYG.attach('thaitextarea', thai); 
</script>

<?php

    echo "<textarea name='englishtextarea' id='englishtextarea'></textarea></div>";
  }
  if ($language=="Thai") {
?>

<script type="text/javascript">
//WYSIWYG.attach('englishtextarea', english); 
WYSIWYG.attach('thaitextarea', thai); 
</script>

<?php
    //echo "style='font-family:Isaana 2008-23' ";
    echo "<textarea name='thaitextarea' id='thaitextarea'></textarea></div>";
  }

  echo "</td></tr>";




  echo '<tr><td><br/><input type="reset" value="Clear" class="buttons" style="width:60px" /></td><td align="left">';
  echo '<br/><div id="submitDiv" style="text-align:right;">';
  echo '<input type="submit" value="Update" class="buttons" style="width:60px"/></div></td></tr>';

  echo "</table><br/><br/>";

?>
<script language="JavaScript1.2" type="text/javascript">
  function pastesymbol1(){
    //alert("test");

    isaanaSymbol1 = document.editsection.selectSymbol1.options[document.editsection.selectSymbol1.selectedIndex].value;
   //"<font face=Isaana 2008-23, serif>";

    appendSymbol1 = isaanaSymbol1;
    document.getElementById("section_text").innerHTML = document.getElementById("section_text").value + appendSymbol1;

   }

  function pastesymbol2(){

    //alert("test");
    isaanaSymbol2 = document.editsection.selectSymbol2.options[document.editsection.selectSymbol2.selectedIndex].value;
   //"<font face=Isaana 2008-23, serif>";

    appendSymbol2 = isaanaSymbol2;
    document.getElementById("section_text").innerHTML = document.getElementById("section_text").value + appendSymbol2;

   }

   function setFont() {
     lang = document.editsection.language.options[document.editsection.language.selectedIndex].value;
     
     if (lang == "English") {
       document.getElementById("section_text").style.fontFamily="Arial";
     }
     if (lang == "Thai") {
       document.getElementById("section_text").style.fontFamily="Isaana 2008-23";
     }
   }

</script>
<script language="JavaScript1.2" type="text/javascript">
   function clearForm() {
     document.getElementById("textsection").innerHTML ="<textarea name='thaitextarea' id='thaitextarea'></textarea></div>";
   }
</script>

</form>

<?php
//include("../webpage_files/includes/output_footer.php");
include("../webpage_files/includes/footer.php");

?>