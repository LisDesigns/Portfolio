<?php

include("../webpage_files/includes/dbconn.php");

$chapterId = $_POST["chapterId"];

$lessonId=$_POST[$chapterId];


$query = "DELETE FROM lessons WHERE lessonId=".$lessonId;
mysql_query($query);

$path="webpage_files/images/lessons/";
$filename=$lessonId.".jpg";

  if (file_exists($filename)) {
    unlink($path.$lessonId.".jpg");
  }

$path="webpage_files/sounds/lessons/";
$filename=$lessonId.".jpg";

  if (file_exists($filename)) {
    unlink($path.$lessonId.".mp3");
  }

header("Location:index.php");

?>