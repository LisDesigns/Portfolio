<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/header.php");

  $chapterId = $_POST['chapterId'];
  $lessonId = $_POST['lessonId'];
  $lesson_heading = $_POST['lesson_heading'];

  $query = "UPDATE `lessons` SET `chapterId` = '".$chapterId."', `lesson_heading` = '".$lesson_heading."' WHERE lessonId=".$lessonId;
  mysql_query($query);

  header("Location:index.php");

  include("../webpage_files/includes/footer.php");

?>