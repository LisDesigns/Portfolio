<?php

include("../webpage_files/includes/dbconn.php");
//include("../webpage_files/includes/header.php");


  //$sectionId=$_POST['sectionId'];
  $query_max1="SELECT sectionId FROM sections ORDER BY sectionId ASC";
  $sectionIds = mysql_query($query_max1);

  while($maxId = mysql_fetch_assoc($sectionIds)){
    $sectionId=$maxId["sectionId"];
  }

  $sectionId=$sectionId+1;
  $chapterId = $_POST['chapterId'];
  $lessonId = $_POST['lessonId'];
  $section_heading = $_POST['section_heading'];

  $section_picture = $_FILES['section_i'];
  $section_sound = $_FILES['section_s'];

//  $section_text = $_POST['section_text'];
  $language = $_POST['language'];
  if ($language=="English") {
    $section_text = $_POST['englishtextarea'];
  }
  if ($language=="Thai") {
    $section_text = $_POST['thaitextarea'];
  }

  $uploads = "../webpage_files/images/lessons/";
  $filename = $sectionId.".jpg";
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }
  if ($_FILES['section_i']["type"] == "image/pjpeg") {
      $_FILES['section_i']["name"]=$filename;
      move_uploaded_file($_FILES['section_i']["tmp_name"],$uploads.$filename);
      //echo "Image Uploaded.";
  }
  $section_picture=$filename;

  $uploads = "../webpage_files/sounds/lessons/";
  $filename = $sectionId.".mp3";
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }
  if ($_FILES['section_s']["type"] == "audio/mpeg") {
      $_FILES['section_s']["name"]=$filename;
      move_uploaded_file($_FILES['section_s']["tmp_name"],$uploads.$filename);
      //echo "<br/>Sound Uploaded.";
  }
  $section_sound=$filename;

  mysql_query("INSERT INTO `sections` (`chapterId`, `lessonId`, `section_heading`, `section_picture`, `section_sound`, `section_text`,`language`) VALUES ('$chapterId', '$lessonId', '$section_heading', '$section_picture', '$section_sound', '$section_text', '$language')");
  
  header("Location:index.php");

//include("../webpage_files/includes/footer.php");

?>