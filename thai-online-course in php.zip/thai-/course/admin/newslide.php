<?php

  $lessonId = $_POST['lessonId'];
  $chapterId = $_POST['chapterId'];

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/admin_header.php");

?>

<h1>Add New Slide</h1>
<form action="addslide.php" method="post" enctype="multipart/form-data">
<?php

  echo "<table id='editlesson'  valign='top'>";
  echo "<input type='hidden' name='lessonId' value='".$lessonId."'/>";
  echo "<input type='hidden' name='chapterId' value='".$chapterId."'/>";
  echo "<tr><td>Slide Picture:  </td><td><input type='file' name='slide_i'/></td></tr>";
  echo "<tr><td>Slide Sound:  </td><td><input type='file' name='slide_s'/></td></tr>";
  echo '<tr><td><br/><input type="reset" value="Clear" class="buttons" style="width:60px" /></td><td align="left">';
  echo '<br/><div id="submitDiv" style="text-align:right;">';
  echo '<input type="submit" value="Update" class="buttons" style="width:60px"/></div></td></tr>';

  echo "</table><br/><br/>";

?>


</form>

   
<?php
//include("../webpage_files/includes/output_footer.php");
include("../webpage_files/includes/footer.php");

?>