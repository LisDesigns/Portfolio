<?php

?>
<script language="JavaScript1.2" type="type/javascript">
  function insertSymbol(symbol) {
    document.getElementById
    // get entire list
    // select selected
    // copy and paste into textarea


    //Check if the 
  }
</script>
<form action="addlesson.php" method="post">
<input type="text" value="" name="subheading"/>
<?php
  include "../webpage_files/includes/symbols.php";
?>
<?php
  include "../webpage_files/includes/colours.php";
?>
<textarea id="textsection" >
<input type="submit"/>
</form>