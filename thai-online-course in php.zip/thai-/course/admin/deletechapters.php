<?php

include("../webpage_files/includes/dbconn.php");
include("../webpage_files/includes/header.php");

?>
<h1>Edit Chapters</h1>
 
<br/>Please select a chapter below to edit.<br/><br/>
<form action="../deletechapter.php" method="post">
<?php

  include "../viewchapters.php";

?>
 &nbsp;<input type="submit" value="GO"/>
</form>

<?php
  include("../webpage_files/includes/footer.php");
?>