<?php

include("../webpage_files/includes/dbconn.php");

  $query_max="SELECT slideId FROM slides ORDER BY slideId ASC";
  $slideIds = mysql_query($query_max);

  while($maxId = mysql_fetch_assoc($slideIds)){
    $slideId=$maxId["slideId"];
  }

  $slideId=$slideId+1;
  $chapterId = $_POST['chapterId'];
  $lessonId = $_POST['lessonId'];
  
  $slide_image = $slideId.".jpg";
  $slide_sound = $slideId.".jpg";
  mysql_query("INSERT INTO `slides`(`chapterId`,`lessonId`,`slide_image`,`slide_sound`) VALUES ('$chapterId','$lessonId', '$slide_image','$slide_sound')");

  $folder = "../images/slideshow/";
  $filename = $slideId.".jpg";
 
  $error ="";

  //unlink($folder.$filename);

  $uploads = "../webpage_files/images/slideshow/";
  $filename = $slideId.".jpg";

  //echo $uploads.$filename;
  echo $_FILES['slide_i']["type"];
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }
  if ($_FILES['slide_i']["type"] == "image/pjpeg") {
      $_FILES['slide_i']["name"]=$filename;
      move_uploaded_file($_FILES['slide_i']["tmp_name"],$uploads.$filename);
      echo "Image Uploaded.<br/><br/>";
  }

  $uploads = "../webpage_files/sounds/slideshow/";
  $filename = $slideId.".mp3";
  if (file_exists($uploads.$filename)) {
    unlink($uploads.$filename);
  }

  if ($_FILES['slide_s']["type"] == "audio/mpeg") {
      $_FILES['slide_s']["name"]=$filename;
      move_uploaded_file($_FILES['slide_s']["tmp_name"],$uploads.$filename);
      echo "<br/>Sound Uploaded.";
  }
  //echo $uploads.$filename;  
  $image = $filename;
  header("Location:index.php");
  include("../webpage_files/includes/footer.php");

?>