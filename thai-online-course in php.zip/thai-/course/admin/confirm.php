<?php

include "../webpage_files/includes/header.php";

echo "<h1>".$subtitle."</h1>";
echo "<p>".$message."</p>";
echo "<p><a href='index.php'>Return home</a></p>";

include "../webpage_files/includes/footer.php";

?>