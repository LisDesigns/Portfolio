<?php

if (!isset($_SESSION["section_tell"])) {
  session_start();
}

$section_tell=$_SESSION["section_tell"];
echo $section_tell[0];
echo $section_tell[1];
echo $section_tell[4];
/*
$section_cat=$_SESSION["section_cat"];
echo $section_cat[0];
echo $section_cat[1];
echo $section_cat[3];
*/
?>