<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>  
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>SharifWear Australia</title>
<meta name="description" content="Dancewear to take you in style from studio to street to stage."/>
<meta name="abstract" content="In styles to suit every body XS to XXL."/>
<meta name="keywords" content="sharifwear, dance, australia, bellydancing, bellydance, belly dance, dancewear, sharif, wear, order, lacy, pants, top, gypsy tops, tank tops, spaghetti strap tops, 
signature pants, stretch, creasefree, travelwear, small sizes, plus sizes, women, girls, xs, extra small, small, medium, large, extra large, xl, xxl, plain, gold, 
silver, sparkle, black, turquoise, red, silver, purple, tops, gold, white, fuschia, blue, burgandy, cotton, terracotta, burgundy, black"/>
<meta name="author" content="SharifWear Australia"/>
<meta name="identifier-url" content="http://www.sharifwear-aus.com.au/"/>
<meta name="copyright" content="Copyright 2010 SharifWear Australia. All rights reserved."/>
<meta name="distribution" content="global"/> 
<meta name="resource-type" content="document"/>
<meta name="googlebot" content="all"/>
<meta name="ROBOTS" content="all"/>
<meta name="owner" content="SharifWear Australia"/>
<meta name="revisit-after" content="4 Days"/>
<meta name="rating" content="Safe For Kids"/>
<link rel="stylesheet" type="text/css" href="styles/orderform.css" />
<style type="text/css">
.cost{width:30px;border-style:none;background-color:rgb(20,20,20);height:17px!important;line-height:17px:important;}
.cost2{width:30px;border-style:none;background-color:rgb(40,40,40);height:17px!important;line-height:17px:important;}
#entercolour{background-color:rgb(60,60,60);border-style:edge;border-width:1px}
</style>
<script language="JavaScript1.2" type="text/javascript">
    
  function validateDigits(digitStr) {
    digitPattern = new RegExp(/^\d+$/gi);
    return digitPattern.test(digitStr);   // true or false will be returned 
  }

function tally(val1,name1) {

  if (!validateDigits(val1)) {
    if (!((window.event.keyCode == 8) || (window.event.keyCode == 37) || (window.event.keyCode == 39) || (window.event.keyCode == 46)) ){

        alert("Error: Please enter only numbers in the quantity field.");
        eval("document.orderform"+"."+String(name1)+'.value="0"');
}
    } else {

sub215=document.orderform.qty215.value*document.orderform.cost215.value;
sub275=document.orderform.qty275.value*document.orderform.cost275.value;
sub284=document.orderform.qty284.value*document.orderform.cost284.value;
sub225=document.orderform.qty225.value*document.orderform.cost225.value;
sub293=document.orderform.qty293.value*document.orderform.cost293.value;
sub257=document.orderform.qty257.value*document.orderform.cost257.value;
sub295=document.orderform.qty295.value*document.orderform.cost295.value;
sub274=document.orderform.qty274.value*document.orderform.cost274.value;
sub2220=document.orderform.qty2220.value*document.orderform.cost2220.value;
sub291=document.orderform.qty291.value*document.orderform.cost291.value;
sub297=document.orderform.qty297.value*document.orderform.cost297.value;
sub297B=document.orderform.qty297B.value*document.orderform.cost297B.value;
sub298=document.orderform.qty298.value*document.orderform.cost298.value;
sub156=document.orderform.qty156.value*document.orderform.cost156.value;

sub150=document.orderform.qty150.value*document.orderform.cost150.value;
sub171=document.orderform.qty171.value*document.orderform.cost174.value;
sub174=document.orderform.qty174.value*document.orderform.cost174.value;
sub197=document.orderform.qty197.value*document.orderform.cost197.value;
sub158=document.orderform.qty158.value*document.orderform.cost158.value;
sub151=document.orderform.qty151.value*document.orderform.cost151.value;
sub176=document.orderform.qty176.value*document.orderform.cost176.value;
sub180=document.orderform.qty180.value*document.orderform.cost180.value;
sub827=document.orderform.qty827.value*document.orderform.cost827.value;
sub951=document.orderform.qty951.value*document.orderform.cost951.value;
sub952=document.orderform.qty952.value*document.orderform.cost952.value;
sub953=document.orderform.qty953.value*document.orderform.cost953.value;
sub170=document.orderform.qty170.value*document.orderform.cost170.value;
sub830=document.orderform.qty830.value*document.orderform.cost830.value;
sub163=document.orderform.qty163.value*document.orderform.cost163.value;
sub198S=document.orderform.qty198S.value*document.orderform.cost198S.value;
sub177=document.orderform.qty177.value*document.orderform.cost177.value;
sub198=document.orderform.qty198.value*document.orderform.cost198.value;
sub1140=document.orderform.qty1140.value*document.orderform.cost1140.value;
sub173=document.orderform.qty173.value*document.orderform.cost173.value;
sub226=document.orderform.qty226.value*document.orderform.cost226.value;
sub243=document.orderform.qty243.value*document.orderform.cost243.value;
sub2230=document.orderform.qty2230.value*document.orderform.cost2230.value;
sub258=document.orderform.qty258.value*document.orderform.cost258.value;
sub204=document.orderform.qty204.value*document.orderform.cost204.value;

costGV=document.orderform.costGV.value*1;

subtotal = sub163 + sub177 + sub173 + sub215 + sub275 + sub284 + sub225 + sub293 + sub257 + sub295 + sub274 + sub2220 + sub291 + sub297 + sub297B + sub298 + sub156 + sub150 + sub171 + sub174 + sub197 + sub158 + sub151 + sub176 + sub180 + sub827 + sub951 + sub952 + sub953 + sub170 + sub198S + sub198 + sub830 + sub1140 + sub226 + sub243 + sub2230 + sub258+ sub204+costGV;

document.orderform.subtotal.value="$"+subtotal.toFixed(2);
//alert(subtotal);
}



}
</script>

<script type="text/javascript" src="scripts/prototype.js"></script>
<script type="text/javascript" src="scripts/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="scripts/lightbox.js"></script>
<link rel="stylesheet" href="styles/lightbox.css" type="text/css" media="screen" />
</head>
<body>
<center>
<div style="width:850px;text-align:left">
<a href="index.html"><img src="images/logo1.png" border="0" alt="Return to SharifWear Australia" align="left"/></a><a href="index.html" style="margin-left:420px;font-size:12px;font-family:arial"><b>Home</b></a><br/><br/><br/><br/>

<noscript>
<font face="arial" size="2">
<br/><b>Please note:</b> Javascript is required to be enabled in your browser to order online. However, if you're not sure, you may also send your order via email to <a href="mailto:orders@sharifwear-aus.com.au">orders@sharifwear-aus.com.au</a>.
<br/>
</font>
</noscript>

<form name="orderform" action="orderform.php" method="post">

<table>
<tr><th colspan="7"><b>SharifWear Signature Style Pants</b></th></tr>

<tr class="row2" height="20"><td  width="100"><b>Style</b></td><td><b>ID</b></td><td><b>Description</b></td><td><b>Colour</b></td><td><b>Size</b></td><td style="width:50px!important"><b>Cost</b></td><td><b>Qty</b></td></tr>
<tr><td><a href="images/items/large/204.jpg" rel="lightbox" title="Velvet Palazzo Pants "><img src="images/items/thumbs/204.jpg" alt="" border="0" class="formimages"/></a></td><td>204</td><td><input class="itemnames" type="text" name="item204" value="Velvet Palazzo Pants" readonly /><br/>Stunning black velvet pant with flared leg and cheeky lace inset.</td><td><input type="hidden" name="opt1_204" value="Black" readonly>Black</select></td><td><select name="opt2_204"><option>Please select</option><option>S</option><option>M</option><option>L</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost204" value="125" readonly /></td><td><input class="qtyfields" type="text" name="qty204"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/215.jpg" rel="lightbox" title="Pants, black with Foldover waist"><img src="images/items/thumbs/215.jpg" alt="" border="0" class="formimages"/></a></td><td>215</td><td><input class="itemnames2" type="text" name="item215" value="Pants, black with Foldover waist" readonly /><br/>Comfortable style for daily wear, travel or dancewear.</td><td>Black</td><td><select name="opt2_215"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost215" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty215"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/275.jpg" rel="lightbox" title="Block letter Bellydancer on back Foldover waist Pants "><img src="images/items/thumbs/275.jpg" alt="" border="0" class="formimages"/></a></td><td>275</td><td><input class="itemnames" type="text" name="item275" value="Block letter Bellydancer on back Foldover waist " readonly /><br/>Pants. New! Turquoise/Silver in XS, S, M only.</td><td><select name="opt1_275"><option>Please select</option><option>Black/Silver</option><option>Turquoise/Silver</option></select></td><td><select name="opt2_275"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost275" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty275"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/284.jpg" rel="lightbox" title="Big B Bellydancer Pants Foldover waist"><img src="images/items/thumbs/284.jpg" alt="" border="0" class="formimages"/></a></td><td>284</td><td><input class="itemnames2" type="text" name="item284" value="Big B Bellydancer Pants Foldover waist" readonly /><br/>New! Purple/Silver in S, M, L only.</td><td><select name="opt1_284"><option>Please select</option><option>Black/Silver</option><option>Black/Gold</option><option>Purple/Silver</option></select></td><td><select name="opt2_284"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost284" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty284"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/225.jpg" rel="lightbox" title="Holiday sparkle pants  "><img src="images/items/thumbs/225.jpg" alt="" border="0" class="formimages"/></a></td><td>225</td><td><input class="itemnames" type="text" name="item225" value="Holiday sparkle pants  " readonly /><br/>(Tight weave - go up a size) <br/>Fitted pants with mesh inset studded with bling!</td><td>Black</td><td><select name="opt2_225"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost225" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty225"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/293.jpg" rel="lightbox" title="String Tribal Pants with ruched skirt "><img src="images/items/thumbs/293.jpg" alt="" border="0" class="formimages"/></a></td><td>293</td><td><input class="itemnames2" type="text" name="item293" value="String Tribal Pants with ruched skirt " readonly /><br/>Best selling style, comfortable & flattering, ruched skirt over flared legs with a dramatic split to the knee.</td><td><select name="opt1_293"><option>Please select</option><option>Black</option><option>Burgundy</option><option>Purple</option><option>Black pant with Burgundy skirt</option><option>Fuschia</option><option>Black pant with Purple skirt</option></select></td><td><select name="opt2_293"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost293" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty293"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/257.jpg" rel="lightbox" title="Chiffon Skirt pants"><img src="images/items/thumbs/257.jpg" alt="" border="0" class="formimages"/></a></td><td>257</td><td><input class="itemnames" type="text" name="item257" value="Chiffon Skirt pants" readonly /><br/>Long chiffon skirt tied at hip over the pants, suits dancewear or evening wear.</td><td></td><td><select name="opt2_257"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost257" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty257"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/295.jpg" rel="lightbox" title="Crochet Scarf Pants"><img src="images/items/thumbs/295.jpg" alt="" border="0" class="formimages"/></a></td><td>295</td><td><input class="itemnames2" type="text" name="item295" value="Crochet Scarf Pants" readonly /><br/>Stunning crochet scarf fitted at hip, suits dancewear or evening wear.</td><td></td><td><select name="opt2_295"><option>Please select</option><option>S</option><option>M</option><option>L</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost295" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty295"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/274.jpg" rel="lightbox" title="Salsa Ruffle pants "><img src="images/items/thumbs/274.jpg" alt="" border="0" class="formimages"/></a></td><td>274</td><td><input class="itemnames" type="text" name="item274" value="Salsa Ruffle pants " readonly /><br/>Slim pants with attractive ruffles on front lower leg.</td><td><select name="opt1_274"><option>Please select</option><option>Black</option><option>Red</option></select></td><td><select name="opt2_274"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost274" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty274"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/2220.jpg" rel="lightbox" title="Cotton String Tribal Pants"><img src="images/items/thumbs/2220.jpg" alt="" border="0" class="formimages"/></a></td><td>2220</td><td><input class="itemnames2" type="text" name="item2220" value="Cotton String Tribal Pants" readonly /><br/>Popular style now in comfortable cotton stretch fabric.</td><td><select name="opt1_2220"><option>Please select</option><option>Black</option><option>Purple</option><option>Turquoise</option><option>Green (Olive)</option></select></td><td><select name="opt2_2220"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost2220" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty2220"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/291.jpg" rel="lightbox" title="Iridescent Paillette Scarf pants"><img src="images/items/thumbs/291.jpg" alt="" border="0" class="formimages"/></a></td><td>291</td><td><input class="itemnames" type="text" name="item291" value="Iridescent Paillette Scarf pants" readonly /><br/>Slim pants with gorgeous coloured paillette scarf attached. *NEW*</td><td></td><td><select name="opt2_291"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost291" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty291"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/297.jpg" rel="lightbox" title="Gothic Pants with Asymmetric Skirt"><img src="images/items/thumbs/297.jpg" alt="" border="0" class="formimages"/></a></td><td>297</td><td><input class="itemnames2" type="text" name="item297" value="Gothic Pants with Asymmetric Skirt" readonly /><br/>Generous cut, wide flared pants.</td><td></td><td><select name="opt2_297"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost297" value="115" readonly /></td><td><input class="qtyfields" type="text" name="qty297"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/297B.jpg" rel="lightbox" title="Gothic Pants with Assuit Skirt"><img src="images/items/thumbs/297B.jpg" alt="" border="0" class="formimages"/></a></td><td>297B</td><td><input class="itemnames" type="text" name="item297B" value="Gothic Pants with Assuit Skirt" readonly /></td><td></td><td><select name="opt2_297B"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost297B" value="115" readonly /></td><td><input class="qtyfields" type="text" name="qty297B"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/298.jpg" rel="lightbox" title="Leopard Foldover Pants"><img src="images/items/thumbs/298.jpg" alt="" border="0" class="formimages"/></a></td><td>298</td><td><input class="itemnames2" type="text" name="item298" value="Leopard Foldover Pants" readonly /><br/>Folded waist pants with waist and insets on leg in leopard print.</td><td></td><td><select name="opt2_298"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost298" value="115" readonly /></td><td><input class="qtyfields" type="text" name="qty298"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr ><td><a href="images/items/large/226.jpg" rel="lightbox" title="Low Rise Split Leg Pants "><img src="images/items/thumbs/226.jpg" alt="" border="0" class="formimages"/></a></td><td>226</td><td><input class="itemnames" type="text" name="item226" value="Low Rise Split Leg Pants " readonly /></td><td><select name="opt1_226"><option>Please select</option><option value="Black">Black</option><option value="Red">Red</option><option value="Teal">Teal</option><option value="Cranberry">Cranberry</option></select></td><td><select name="opt2_226"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost226" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty226"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/243.jpg" rel="lightbox" title="Tribal Salsa Pants Pants with flared asymmetrical hemline"><img src="images/items/thumbs/243.jpg" alt="" border="0" class="formimages"/></a></td><td>243</td><td><input class="itemnames2" type="text" name="item243" value="Tribal Salsa Pants Pants" readonly /><br/>with flared asymmetrical hemline</td><td><select name="opt1_243"><option>Please select</option><option value="Black">Black</option><option value="Purple">Purple</option><option value="White">White</option><option value="Red">Red</option><option>Royal Blue</option></select></td><td><select name="opt2_243"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost243" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty243"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr ><td><a href="images/items/large/2230.jpg" rel="lightbox" title="Diva Mesh Pants "><img src="images/items/thumbs/2230.jpg" alt="" border="0" class="formimages"/></a></td><td>2230</td><td><input class="itemnames" type="text" name="item2230" value="Diva Mesh Pants " readonly /></td><td><input type="hidden" name="opt1_2230" value="Black"/>Black</td><td><select name="opt2_2230"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost2230" value="90" readonly /></td><td><input class="qtyfields" type="text" name="qty2230"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/297B.jpg" rel="lightbox" title="Assuit Foldover Pants "><img src="images/items/thumbs/297B.jpg" alt="" border="0" class="formimages"/></a></td><td>258</td><td><input class="itemnames2" type="text" name="item258" value="Assuit Foldover Pants " readonly /></td><td><input type="hidden" name="opt1_258" value="Black"/>Black</td><td><select name="opt2_258"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost258" value="115" readonly /></td><td><input class="qtyfields" type="text" name="qty258"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>

<tr><th colspan="7"><b>Spaghetti Strap Quality Stretch Fabric Top</b></th></tr>

<tr><td  width="100"><b>Style</b></td><td><b>ID</b></td><td><b>Description</b></td><td><b>Colour</b></td><td><b>Size</b></td><td><b>Cost</b></td><td><b>Qty</b></td></tr>
<tr class="row2"><td><a href="images/items/large/156.jpg" rel="lightbox" title="Big B Bellydancer spaghetti string top Unisize "><img src="images/items/thumbs/156.jpg" alt="" border="0" class="formimages"/></a></td><td>156</td><td><input class="itemnames2" type="text" name="item156" value="Big B Bellydancer spaghetti string top Unisize " readonly /><br/>(Contact us for currently available colours)</td><td><select name="opt1_156"><option>Please select</option><option>Black/Silver</option><option>Red/Gold</option><option>Black/Gold</option><option>Black/Silver</option><option>Purple/Silver</option><option>Turquoise/Silver</option><option>Fuschia/Silver</option></select></td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost156" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty156"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/150.jpg" rel="lightbox" title="Bellydancer Block letters, Spaghetti string top"><img src="images/items/thumbs/150.jpg" alt="" border="0" class="formimages"/></a></td><td>150</td><td><input class="itemnames" type="text" name="item150" value="Bellydancer Block letters, Spaghetti string top" readonly /></td><td><select name="opt1_150"><option>Please select</option><option>Black/Silver</option><option>Pink/Silver</option><option>Turquoise/Silver</option></select></td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost150" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty150"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/171.jpg" rel="lightbox" title="Tribal Dancer Spaghetti Strap top Unisize "><img src="images/items/thumbs/171.jpg" alt="" border="0" class="formimages"/></a></td><td>171</td><td><input class="itemnames2" type="text" name="item171" value="Tribal Dancer Spaghetti Strap top Unisize " readonly /></td><td>Black/Silver </td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost171" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty171"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr ><td><a href="images/items/large/174.jpg" rel="lightbox" title="Habibi Spaghetti Strap top "><img src="images/items/thumbs/174.jpg" alt="" border="0" class="formimages"/></a></td><td>174</td><td><input class="itemnames" type="text" name="item174" value="Habibi Spaghetti Strap top " readonly /></td><td>Silver on Black</td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost174" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty174"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/197.jpg" rel="lightbox" title="Belly Diva Spaghetti Strap Top "><img src="images/items/thumbs/197.jpg" alt="" border="0" class="formimages"/></a></td><td>197</td><td><input class="itemnames2" type="text" name="item197" value="Belly Diva Spaghetti Strap Top " readonly /></td><td><select name="opt1_197"><option>Please select</option><option>Fuschia with Turquoise print</option><option>Orange/Black</option><option>Red/Black</option><option>Yellow/Black</option><option>Black/Turquoise</option></select></td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost197" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty197"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr ><td><a href="images/items/large/163.jpg" rel="lightbox" title="Humza Spaghetti Strap top Unisize"><img src="images/items/thumbs/163.jpg" alt="" border="0" class="formimages"/></a></td><td>163</td><td><input class="itemnames" type="text" name="item163" value="Humza Spaghetti Strap top Unisize" readonly /></td><td><select name="opt1_163"><option>Please select</option><option>Black/Silver</option><option>Black/Blue</option><option>Red/Black</option><option>Turquoise/Black</option></select></td><td>One Size</td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost163" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty163"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/198S.jpg" rel="lightbox" title="Live Love Dance Spaghetti Strap Top Black with silver studded design"><img src="images/items/thumbs/198S.jpg" alt="" border="0" class="formimages"/></a></td><td>198S</td><td><input class="itemnames2" type="text" name="item198S" value="Live Love Dance Spaghetti Strap Top" readonly /><br/>Black with silver studded design</td><td><input type="hidden" name="opt1_198S" value="Black with silver"/>Black with silver</td><td><select name="opt2_198S"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost198S" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty198S"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>

<tr><th colspan="7"><b>Tank Tops Ribbed Cotton</b></th><tr>

<tr><td  width="100"><b>Style</b></td><td><b>ID</b></td><td><b>Description</b></td><td><b>Colour</b></td><td><b>Size</b></td><td><b>Cost</b></td><td><b>Qty</b></td></tr>
<tr class="row2"><td><a href="images/items/large/158.jpg" rel="lightbox" title="Big B Bellydance Tank Top "><img src="images/items/thumbs/158.jpg" alt="" border="0" class="formimages"/></a></td><td>158</td><td><input class="itemnames2" type="text" name="item158" value="Big B Bellydance Tank Top " readonly /></td><td><select name="opt1_158"><option>Please select</option><option>Black/Silver</option><option>Black/Gold</option></select></td><td><select name="opt2_158"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost158" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty158"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/151.jpg" rel="lightbox" title="Block letters Bellydance Tank Top "><img src="images/items/thumbs/151.jpg" alt="" border="0" class="formimages"/></a></td><td>151</td><td><input class="itemnames" type="text" name="item151" value="Block letters Bellydance Tank Top " readonly /></td><td></td><td><select name="opt2_151"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost151" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty151"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/176.jpg" rel="lightbox" title="Habibi Tank Top "><img src="images/items/thumbs/176.jpg" alt="" border="0" class="formimages"/></a></td><td>176</td><td><input class="itemnames2" type="text" name="item176" value="Habibi Tank Top " readonly /></td><td><select name="opt1_176"><option>Please select</option><option>Black</option><option>Turquoise</option></select></td><td><select name="opt2_176"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost176" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty176"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr ><td><a href="images/items/large/180.jpg" rel="lightbox" title="Humza Tank Top"><img src="images/items/thumbs/180.jpg" alt="" border="0" class="formimages"/></a></td><td>180</td><td><input class="itemnames" type="text" name="item180" value="Humza Tank Top" readonly /></td><td><select name="opt1_180"><option>Please select</option><option>Black/Gold</option><option>Turquoise/silver</option><option>Black/Silver</option></select></td><td><select name="opt2_180"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost180" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty180"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/171.jpg" rel="lightbox" title="Tribal Dancer Tank Top"><img src="images/items/thumbs/177.jpg" alt="" border="0" class="formimages"/></a></td><td>177</td><td><input class="itemnames2" type="text" name="item177" value="Tribal Dancer Tank Top" readonly /></td><td>Black/Silver</td><td><select name="opt2_177"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost177" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty177"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/198.jpg" rel="lightbox" title="Live Love Dance Tank Top"><img src="images/items/thumbs/198.jpg" alt="" border="0" class="formimages"/></a></td><td>198</td><td><input class="itemnames" type="text" name="item198" value="Live Love Dance Tank Top" readonly /><br/>Black with silver studded design</td><td><input type="hidden" name="opt1_198" value="Black with silver"/>Black with silver</td><td><select name="opt2_198"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost198" value="35" readonly /></td><td><input class="qtyfields" type="text" name="qty198"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>

<tr><th colspan="7"><b>"Gypsy" Tie Tops</b></th><tr>

<tr><td  width="100"><b>Style</b></td><td><b>ID</b></td><td><b>Description</b></td><td><b>Colour</b></td><td><b>Size</b></td><td><b>Cost</b></td><td><b>Qty</b></td></tr>
<tr class="row2"><td><a href="images/items/large/827.jpg" rel="lightbox" title="Assuit look Gypsy tie top "><img src="images/items/thumbs/827.jpg" alt="" border="0" class="formimages"/></a></td><td>827</td><td><input class="itemnames2" type="text" name="item827" value="Assuit look Gypsy tie top " readonly /></td><td><select name="opt1_827"><option>Please select</option><option>Black/Silver</option><option>Red/Silver</option></select></td><td><select name="opt2_827"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost827" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty827"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/951.jpg" rel="lightbox" title="Leopard print Gypsy tie top"><img src="images/items/thumbs/951.jpg" alt="" border="0" class="formimages"/></a></td><td>951</td><td><input class="itemnames" type="text" name="item951" value="Leopard print Gypsy tie top" readonly /></td><td></td><td><select name="opt2_951"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost951" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty951"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/952.jpg" rel="lightbox" title="Assorted Lacy Gypsy Tie Tops "><img src="images/items/thumbs/952.jpg" alt="" border="0" class="formimages"/></a></td><td></td><td><input class="itemnames2" type="text" name="item952" value="Assorted Lacy Gypsy Tie Tops " readonly /><br/>Range of gypsy tops available. Other colours dependant on stock and fabric availability.</td><td><select name="opt1_952"><option>Please select</option><option>Black</option><option>White</option><option>Burgundy</option><option>Terracotta</option></select></td><td><select name="opt2_952"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost952" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty952"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/953.jpg" rel="lightbox" title="Assorted Sheer/Non-Sheer Gypsy Tie Tops "><img src="images/items/thumbs/953.jpg" alt="" border="0" class="formimages"/></a></td><td></td><td><input class="itemnames" type="text" name="item953" value="Assorted Sheer/Non-Sheer Gypsy Tie Tops " readonly /><br/>(Fabrics vary. Indicate colour preference.)</td><td><input type="text" name="opt1_953" id="entercolour" value="Enter Colour:" /></td><td><select name="opt2_953"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost953" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty953"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr class="row2"><td><a href="images/items/large/170.jpg" rel="lightbox" title="Diva Long Sleeve Top Net "><img src="images/items/thumbs/170.jpg" alt="" border="0" class="formimages"/></a></td><td>170</td><td><input class="itemnames2" type="text" name="item170" value="Diva Long Sleeve Top Net " readonly /><br/>Large mesh makes this attractive layered over other tops.</td><td>Black</td><td><select name="opt2_170"><option>Please select</option><option>S</option><option>M</option><option>L</option><option>XL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost170" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty170"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><img src="images/items/thumbs/830.jpg" alt="" border="0" class="formimages"/>
<!--
<a href="images/items/large/830.jpg" rel="lightbox" title="Cotton Lycra Black Gypsy Tie Top "></a>
-->
</td><td>830</td><td><input class="itemnames" type="text" name="item830" value="Cotton Lycra Black Gypsy Tie Top " readonly /></td><td><input type="hidden" name="opt1_830" value="Black"/>Black</td><td><select name="opt2_830"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost830" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty830"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>


<tr class="row2"><td><a href="images/items/large/1140.jpg" rel="lightbox" title="Mambo Gypsy Tie Top  "><img src="images/items/thumbs/1140.jpg" alt="" border="0" class="formimages"/></a></td><td>1140</td><td><input class="itemnames2" type="text" name="item1140" value="Mambo Gypsy Tie Top" readonly /><br/>Cotton Lycra top with mesh sleeve</td><td><input type="hidden" name="opt1_1140" value="Black"/>Black</td><td><select name="opt2_1140"><option>Please select</option><option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option></select></td><td valign="middle"><input type="text" value="$" readonly class="dollar2"/><input class="cost2" type="text" name="cost1140" value="69" readonly /></td><td><input class="qtyfields" type="text" name="qty1140"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><td><a href="images/items/large/173.jpg" rel="lightbox" title="Rhinestone Zipper Top, Long sleeve"><img src="images/items/thumbs/173.jpg" alt="" border="0" class="formimages"/></a></td><td>173</td><td><input class="itemnames" type="text" name="item173" value="Rhinestone Zipper Top, Long sleeve " readonly /></td><td>Black</td><td><input type="hidden" name="opt2_173" value="One size M-L" readonly>One size M-L</td><td valign="middle"><input type="text" value="$" readonly class="dollar"/><input class="cost" type="text" name="cost173" value="125" readonly /></td><td><input class="qtyfields" type="text" name="qty173"  onkeyup="tally(this.value,this.name)" value="0"/></td></tr>
<tr><th colspan="7"><b>Order a Gift Voucher</b></th><tr>
<tr><td></td><td><b>ID</b></td><td><b>Style/Description</b></td><td></td><td></td><td colspan="2" valign="middle" ><b>Amount</b></td></tr>
<tr class="row2"><td><a href="images/items/large/GV.jpg" rel="lightbox" title="Gift Voucher"><img src="images/items/thumbs/GV.jpg" alt="" border="0" class="formimages"/></a></td><td>GV</td><td><input class="itemnames2" type="text" name="itemGV" value="Gift vouchers can be made out for any amount." readonly /></td><td></td><td></td><td colspan="2" valign="middle" ><input type="text" value="$" readonly class="dollar2"/><input class="cost3" type="text" name="costGV" value="0" onkeyup="tally(this.value,this.name)" /></td></tr>
</table>

<table>
<tr>
<td valign="top">
<br/><br/>
<h4>Shipping Details</h4>

<table>
<tr><td align="right" width="100">* First Name:</td><td><input type="text" name="firstname" class="shipping"/></td></tr>
<tr><td align="right">* Last Name:</td><td><input type="text" name="lastname" class="shipping"/></td></tr>
<tr><td align="right">* Phone:</td><td><input type="text" name="phone" class="shipping"/></td></tr>
<tr><td align="right"> &nbsp; &nbsp;Mobile:</td><td><input type="text" name="mobile" class="shipping"/></td></tr>
<tr><td align="right">* Email:</td><td><input type="text" name="email" class="shipping"/></td></tr>
<tr><td align="right">* Address:</td><td><input type="text" name="address" class="shipping"/></td></tr>
<tr><td align="right">* Suburb:</td><td><input type="text" name="suburb" class="shipping"/></td></tr>
<tr><td align="right">* State:</td><td><input type="text" name="state" class="shipping"/></td></tr>
<tr><td align="right">* Post Code:</td><td><input type="text" name="postcode" class="shipping"/></td></tr>
<tr><td align="right">* Country:</td><td><input type="text" name="country" class="shipping"/></td></tr>
</table>

</td>
<td width="6"></td>
<td valign="top" align="right" width="406">
<br/>

<script language="JavaScript 1.2" type="text/javascript">

if ((navigator.appName=="Microsoft Internet Explorer") && (parseInt(navigator.appVersion) >= 4)) {

document.writeln('<h4>Subtotal: <input type="text" value="$0.00" name="subtotal" readonly style="width:104px!important"></h4>');


}
</script>
<br/>
<p align="left" style="color:#d9518b">Please note: shipping will be calculated and confirmed with you, after checkout. Payment details will be provided while your order is being prepared.


<br/><br/>
</p>
<p align="left" >

<img src="
<?php
  echo "random_image_sample.php";
?>
">

<br/>Please enter the characters shown:
<br/><input name="number" type="text" id="number"/>
</p>
<br/>
<br/>
<p align="right"><input type="submit" value="Submit Order"/></p>
</td>
</tr>
</table>
<script language="JavaScript1.2" type="text/javascript">

function validate() {
FirstName = orderform.firstname.value;
LastName = orderform.lastname.value;
Address = orderform.address.value;
Suburb = orderform.suburb.value;
State = orderform.state.value;
PostCode = orderform.postcode.value;
Country = orderform.country.value;
PhoneNumber = orderform.phone.value;
Email = orderform.email.value;

if ((FirstName.length == 0) || 
    (LastName.length == 0) || 
    (Address.length == 0) || 
    (Suburb.length == 0) || 
    (State.length == 0) || 
    (Country.length == 0) || 
    (PostCode.length == 0) || 
    (PhoneNumber.length == 0) || 
    (Email.length == 0)) {

    alert("Please enter a value for all fields marked with an asterisk(*).");

} else {

orderform.submit();

}
}

</script>
<br/></td></tr>
</table>

</form>
</div>
</center>


</body>
</html>
