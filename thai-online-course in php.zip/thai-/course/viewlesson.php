<?php

  include "webpage_files/includes/dbconn.php";
  include "webpage_files/includes/header.php";

  $chapter_name = "";
  $lessonId = $_GET["lessonId"];

  $query = "SELECT * FROM lessons WHERE lessonId=".$lessonId;
  $lessons = mysql_query($query);

  if (!$lessons) {
    echo "Error: ".mysql_error();
    exit;
  }

  while($lesson = mysql_fetch_assoc($lessons)){

    $slideId=$lesson['slideId'];
    $chapterId = $lesson['chapterId'];
    $lessonId = $lesson['lessonId'];
    $lesson_heading = $lesson['lesson_heading'];
    $lesson_name = $lesson['lesson_name'];
  }

  $query = "SELECT * FROM chapters WHERE chapterId=".$chapterId;
  $chapters = mysql_query($query);
  if (!$chapters) {
    echo "Error: ".mysql_error();
    exit;
  }

  while($chapter = mysql_fetch_assoc($chapters)){
    $chapter_heading = $chapter['chapter_heading'];
  }

  echo "<br/><h1><font color=gray>".$chapter_heading." </font> ".$lesson_heading."</h1>";

  include "viewslideshow.php";
  //include "slideshow/slidescripts.php";

  if ($slide > 0) {
?>
  <div style="display:block;height:200px;width:300px;"><br/><br/><br/><br/><br/></div>
  <br/>
<?php
}
?>


<?php
  include "viewsections.php";
//  include "webpage_files/includes/pageindex.php";

  include "webpage_files/includes/dbconn.php";
?>
