<?php

  $message = "Hello,\n\r"."Your login details for are as follows:\n\r";
  $message .= "Username: admin";
  $message .= "\nPassword: pass";
  $message .="\n\rThank you,"."\n\n"."Lis Designs Web Support";

  $subject = "LearnSpeakThai - Password Reminder";
  //$to      = $sendtoEmail;
  $Email = 'lisa@lisdesigns.com.au';
  $to = 'learnspeakthai@gmail.com';

  $headers = 'From: '.$Email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();

  mail($to, $subject, $message, $headers);

  $subtitle ="Thank you";
  $message ="Your login details have been sent to your Email Address.";

  echo $message;
  echo "<br/><br/><a href='memberlogin.php'>Login</a>";
?>