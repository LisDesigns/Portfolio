
<?php 
  //include "../webpage_files/includes/header.php";
?>

      <h1 style="display:inline;padding-left:0px">Member Login</h1>
      <br/>
      <?php 
      //echo $error;
      //GET $viewaction
      $viewaction="";
      ?>
      <form name="login" method="post" action="../login/check.php">

      <?php 
        echo '<input type="hidden" name="viewaction" value="'.$viewaction.'"/>'; 
      ?>
   <!--
   <div id="errorMessageDiv" style="color:red; font-weight:normal;"></div>
   -->

   <form name="login" method="post" action="addmember.php">
    <table id="login">
      <tr><td width="130"><font color="gray">*</font> Username:</td><td><input type="text" name="Username"/></td></tr>
      <tr><td><font color="gray">*</font> Password:</td><td><input type="text" name="Password"/></td></tr>
      <tr><td><br/></td><td align="left">
          <br/><div id="submitDiv" style="text-align:right;">
      <input type="submit" value="Login" class="buttons" style="width:60px"/></div></td></tr>
    </table>
    <a href="../login/forgotpassword.php">Forgotten Password?</a>
    <br/>
    <br/>
    <br/>


<?php 
  //include "../webpage_files/includes/footer.php";
?>