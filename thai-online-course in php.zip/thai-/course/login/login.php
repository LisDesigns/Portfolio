<?php
include "webpage_files/includes/header.php";
if ($_GET["error"] == 1) {
  $errormessage = '<h1 style="display:inline;">Login</h1><br/><br/>Error: Please try again.';
} else if ($_GET["error"] == 2) {
  $errormessage = '<h1 style="display:inline;">Buh-bye</h1><br/><br/>You are now logged out.';
} else if ($_GET["error"] == 3) {
  $errormessage = '<h1 style="display:inline;">Error</h1><br/><br/>Please select a gallery.';
} else {
  $errormessage = '<h1 style="display:inline;">Login</h1><br/><br/>';
}
include "webpage_files/includes/dbconn.php";
$query  = "SELECT DISTINCT GalleryName FROM photogallery";
mysql_query($query);
?>
<center>
<br/><h2>Learning Course Admin</h2><br/><br/>
<div style="width:262px;text-align:left;background-color:#CCDDEE;padding:10px;height:196px;color:rgb(60,60,60);border: solid 1px rgb(200,200,200);">


<? 
echo $errormessage;
?>
<form name="login" method="post" action="editgallery.php">
<? echo '<input type="hidden" name="viewaction" value="'.$_GET["viewaction"].'"/>';  ?>

<table style="border-style:none;width:200px">
<tr><td style="border-style:none;height:20px;line-height:20px;text-align:left">Gallery: </td><td style="border-style:none;height:20px;line-height:20px;"> <select name="GalleryName">
<option value="Please select">Please select</option>
<?

while($row = mysql_fetch_assoc($result)){
  $GalleryName=$row['GalleryName'];
  echo '<option value="'.$GalleryName.'">'.$GalleryName.'</option>';
}

?>

<tr><td style="border-style:none;height:20px;line-height:20px;text-align:left">Username: </td><td style="border-style:none;height:20px;line-height:20px;"><input type="text" name="loginusername"/></td></tr>
<tr><td style="border-style:none;height:20px;line-height:20px;text-align:left">Password: </td><td style="border-style:none;height:20px;line-height:20px;"><input type="Password" name="loginPassword"/></td></tr>
<tr><td colspan="2" style="border-style:none;height:20px"><input type="submit" value="Login" class="buttons" style="margin-left:136px; width:70px"/></td></tr>
</table>
</form>
&nbsp; <a href="forgotPassword.php">Forgotten Password?</a>
</div>
</center>

</body>
</html>