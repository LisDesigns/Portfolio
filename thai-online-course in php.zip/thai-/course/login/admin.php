<?
   session_start();

    $_SESSION["user"];
    $_SESSION["pass"];
    $_SESSION["MemberId"];
    $_SESSION["paid"];

include "webpage_files/includes/dbconn.php";
mysql_select_db($databaseName,$connection) or die('Could not select the database: '.mysql_error());

$loginusername = $_POST["loginusername"];
$loginPassword = $_POST["loginPassword"];

$query  = "SELECT * FROM registration WHERE memberusername = '".$loginusername."' AND Password = '".$loginPassword."'";
mysql_query($query);
$i=0;
       while($row = mysql_fetch_assoc($result))
       {
        $i++;
        $MemberId = $row['MemberId'];
       }


$query = "SELECT * FROM registration WHERE paidJoiningFee = 'paid' AND MemberId='$MemberId'";

mysql_query($query);

$x=0;

while($row = mysql_fetch_assoc($result)) {
   $x++;
}
if ($i>=1) {
 $_SESSION["paid"] = "paid";
} 

if($i >= 1) {

    $_SESSION["user"] = $loginusername;
    $_SESSION["pass"] = $loginPassword;
    $_SESSION["MemberId"] = $MemberId;

    if($_REQUEST["viewaction"]=="edit"){
      header("location: editaccount.php");
    } else if($_REQUEST["viewaction"]=="post"){
      header("location: updateaccount.php");
    } else {
      header("location: viewchapters.php");
    }

} else  {
    $error = "<font color='#CC0000'>Error: The username and/or Password entered was incorrect.</font>";
    include("login.php");
}

mysql_close($connection);

?>