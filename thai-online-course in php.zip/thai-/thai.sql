-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2011 at 12:08 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `thai`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE IF NOT EXISTS `chapters` (
  `orderId` int(100) NOT NULL,
  `lessonId` int(100) NOT NULL,
  `chapterId` int(100) NOT NULL AUTO_INCREMENT,
  `chapter_name` varchar(200) NOT NULL,
  `chapter_heading` varchar(200) NOT NULL,
  PRIMARY KEY (`chapterId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`orderId`, `lessonId`, `chapterId`, `chapter_name`, `chapter_heading`) VALUES
(0, 0, 25, '', 'Chapter 1');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE IF NOT EXISTS `lessons` (
  `slideId` int(100) NOT NULL,
  `lessonId` int(100) NOT NULL AUTO_INCREMENT,
  `chapterId` int(100) NOT NULL,
  `lesson_heading` varchar(200) NOT NULL,
  `lesson_name` varchar(200) NOT NULL,
  PRIMARY KEY (`lessonId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`slideId`, `lessonId`, `chapterId`, `lesson_heading`, `lesson_name`) VALUES
(0, 40, 25, 'Lesson 1', '');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `MemberId` int(200) NOT NULL AUTO_INCREMENT,
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Suburb` varchar(200) NOT NULL,
  `State` varchar(200) NOT NULL,
  `Country` varchar(200) NOT NULL,
  `PostCode` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Mobile` varchar(100) NOT NULL,
  `Email` varchar(200) NOT NULL,
  PRIMARY KEY (`MemberId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `members`
--


-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `PaymentId` int(100) NOT NULL AUTO_INCREMENT,
  `DatePaid` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `PaymentAmount` float(10,2) DEFAULT NULL,
  `MembershipType` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`PaymentId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `payments`
--


-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE IF NOT EXISTS `sections` (
  `sectionId` int(100) NOT NULL AUTO_INCREMENT,
  `chapterId` int(100) DEFAULT NULL,
  `lessonId` int(11) DEFAULT NULL,
  `section_heading` varchar(200) DEFAULT NULL,
  `section_picture` varchar(200) DEFAULT NULL,
  `section_sound` varchar(200) NOT NULL,
  `section_text` varchar(1000) DEFAULT NULL,
  `language` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sectionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`sectionId`, `chapterId`, `lessonId`, `section_heading`, `section_picture`, `section_sound`, `section_text`, `language`) VALUES
(74, 25, 40, 'Test', '74.jpg', '74.mp3', '<FONT color=#993399>gfhg</FONT>f f<FONT color=#009999>ghgjhg</FONT>hgh<FONT color=#66ffcc> ghjgjhggh</FONT><FONT color=#cccc33> </FONT>jhghgjg', 'English'),
(73, 25, 40, 'Test', '73.jpg', '73.mp3', '<FONT color=#993399>gfhg</FONT>f f<FONT color=#009999>ghgjhg</FONT>hgh<FONT color=#66ffcc> ghjgjhggh</FONT><FONT color=#cccc33> </FONT>jhghgjg', 'English'),
(69, 25, 40, 'Test', 'Array', 'Array', '<FONT color=#993399>gfhg</FONT>f f<FONT color=#009999>ghgjhg</FONT>hgh<FONT color=#66ffcc> ghjgjhggh</FONT><FONT color=#cccc33> </FONT>jhghgjg', 'English'),
(68, 25, 40, 'Test', 'Array', 'Array', '<FONT color=#993399>gfhg</FONT>f f<FONT color=#009999>ghgjhg</FONT>hgh<FONT color=#66ffcc> ghjgjhggh</FONT><FONT color=#cccc33> </FONT>jhghgjg', 'English');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE IF NOT EXISTS `slides` (
  `slideId` int(100) NOT NULL AUTO_INCREMENT,
  `lessonId` int(100) NOT NULL,
  `chapterId` int(100) NOT NULL,
  `slide_image` varchar(100) NOT NULL,
  `slide_sound` varchar(100) NOT NULL,
  PRIMARY KEY (`slideId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`slideId`, `lessonId`, `chapterId`, `slide_image`, `slide_sound`) VALUES
(66, 0, 0, '1.jpg', '1.jpg'),
(67, 40, 0, '67.jpg', '67.jpg'),
(68, 40, 0, '', '');
